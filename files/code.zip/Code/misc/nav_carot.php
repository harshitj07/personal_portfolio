<style>
	header {
	  background-color: #2e3c73;
	  align-items: center;
	  padding-top: 2em;
	  padding-bottom: 2em;
	  font-size: 16px;
	  display: block;
	  justify-content: space-evenly;
	  text-align: center;
	  position: relative;
	  font-family: 'Nunito', sans-serif;
	}

	.navbar {
	  overflow: hidden;
	  font-family: 'Nunito', sans-serif;	/* https://fonts.google.com/ */	
	  align-items: center;
	  justify-content: space-evenly;
	  font-family: monospace;
	  display: flex;
	  text-align: center;
	  padding-right: 5%;
	  padding-left: 2.5%;
	  flex-direction: column;
	  gap: 2.5%;
	}

	/* Links inside the navbar */
	.navbar a {
	  align-items: center;
	  justify-content: center;
	  float: left;
	  font-size: 20px;
	  text-align: center;
	  padding: 7px 16px;
	  text-decoration: none;
	  font-family: monospace;
	  color: white;
	  font-family: 'Nunito', sans-serif;
	}

	/* The dropdown container */
	.dropdown {
	  float: left;
	  overflow: hidden;
	  text-align: center;
	  font-family: 'Nunito', sans-serif;
	}

	/* Dropdown button */
	.dropdown .dropbtn {
	  font-size: 20px;
	  border: none;
	  outline: none;
	  color: white;
	  padding: 7px 16px;
	  background-color: inherit;
	  font-family: inherit; /* Important for vertical align on mobile phones */
	  margin: 0; /* Important for vertical align on mobile phones */
	  font-family: monospace;
	  font-family: 'Nunito', sans-serif;
	}

	/* Add a background color to navbar links on hover */
	.navbar a:hover {
	  /* background-color: #4c79b5; */
	  font-family: 'Nunito', sans-serif;
	  border-radius: 5px;
	}

	.dropdown:hover .dropbtn {
		background-color: #4c79b5;
		font-family: 'Nunito', sans-serif;
		border-radius: 5px 5px 0 0;
	}

	/* Dropdown content (hidden by default) */
	.dropdown-content {
	  display: none;
	  position: absolute;
	  background-color: #f9f9f9;
	  min-width: 160px;
	  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
	  z-index: 1;
	  font-family: 'Nunito', sans-serif;
	  padding: 5px;
	}

	/* Links inside the dropdown */
	.dropdown-content a {
	  	float: none;
	  	color: black;
	  	padding: 12px 16px;
	  	text-decoration: none;
	  	display: block;
	  	text-align: left;
	  	font-family: 'Nunito', sans-serif;
	}

	/* Add a grey background color to dropdown links on hover */
	.dropdown-content a:hover {
	  	background-color: #4c79b5;
	  	font-family: 'Nunito', sans-serif;
	  	border-radius: 5px;
	}

	/* Show the dropdown menu on hover */
	.dropdown:hover .dropdown-content {
	    display: block;
	    font-family: 'Nunito', sans-serif;
	    border-radius: 0 5px 5px 5px;
	}

	h1.sitetitle {
		margin: 0;
		flex-basis: 30%;
		margin-bottom: 2.5%;
		margin-top: 1%;
	}

	.hoverlink {

	}

	/*
	.navlink {
		display: flex;
		justify-content: space-around;
		align-items: center;
		flex-basis: 50%;
		width: 100%;
	} 
	*/

	.hoverlink {
		position: relative;	
	}

	.hoverlink:after {
		position: absolute;
		bottom: 0;
		left: 0;
		right: 0;
		margin: auto;
		width: 0%;
		content: '.';
		color: transparent;
		background: #4c79b5;
		height: 1px;
	}

	.hoverlink {
		transition: all 2s;
	}

	.hoverlink:after {
		text-align: left;
		content: '.';
		margin: 0;
		opacity: 0;
	}

	.hoverlink:hover {
		color: #ffffff;
		z-index: 1;
	}

	.hoverlink:hover:after {
		z-index: -10;
		animation: fill 1s forwards;
		-webkit-animation: fill 1s forwards;
		-moz-animation: fill 1s forwards;
		opacity: 1;
	}

	.links {
		width: 100%;
		display: flex;
		justify-content: space-around;
	}

	.dropbtn {
		display: flex;
		justify-content: center;
		align-items: center;
	}

	/* Keyframes */
	@-webkit-keyframes fill {
		0% {
			width: 0%;
			height: 1px;
		}

		50% {
			width: 100%;
			height: 1px;
		}

		100% {
			width: 100%;
			height: 100%;
			background: #4c79b5;
			border-radius: 5px;
		}
	}

	.caret {
		width: 0;
		height: 0;
		border-left: 5px solid transparent;
		border-right: 5px solid transparent;
		border-top: 6px solid #ffffff;
		transition: 0.3s;
		margin: 5px;
	}

	.caret-rotate {
		transform: rotate(180deg);
	}

	.caret:hover{
		transform: rotate(180deg);
	}
</style>

<header>
	<nav class="navbar">
		<h1 class="sitetitle">Harshit Jain - ICS3UO-02</h1>
		<div class="links">
			<a class="navlink hoverlink" href="https://hdsb.elearningontario.ca/d2l/home/22896061">Brightspace</a>
			<a class="navlink hoverlink" href="https://icsprogramming.ca/index.php">Class Website</a>
			<div class="dropdown navlink">
				<button class="dropbtn">Activities<span class="caret"></span></button>
				<div class="dropdown-content">
					<a class="activity" href="basics/">BASICS (First Activity)</a>
					<a class="activity" href="activity-1-1.php">Activity 1.1</a>
					<a class="activity" href="activity-1.2.php">Activity-1-2</a>
					<a class="activity" href="activity-1-3.php">Activity-1-3</a>
					<a class="activity" href="activity-1-4.php">Activity-1-4</a>
					<a class="activity" href="activity-1-5.php">Activity-1-5</a>
					<a class="activity" href="activity-1-6.php">Activity-1-6</a>
				</div>
			</div>
		</div>
	</nav>
</header>


