<!-- Javascript -->	
<script>
	// This measure has been taken due to copying of source code from my website. 
	// Source: https://billypentester.medium.com/how-to-hide-the-source-code-of-an-html-web-page-59a3c2e877b4

	// Used to prevent right click on the webpage
	document.addEventListener('contextmenu', 
 		event => event.preventDefault()
	);

	// Used to prevent Ctrl and F12 key on the webpage
	document.addEventListener("keydown", function (event){
		if (event.ctrlKey){
    		event.preventDefault();
		}
		if(event.keyCode == 123){
   			event.preventDefault();
		}
	});
</script>