<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.6a - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.6a">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.6a"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--denim);
			text-align: center;
		}

		img {
            height: 60%;
            width: 85%;
            border-radius: 10px;
        }

        img.formula {
            height: 70%;
            width: 60%;
            border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<h2>Introduction</h2>
	<div class="grid">
		<div class="col-span-6">
			<div class="card">
				<h3>Overview</h3>
				<br />
				<p>The common field cricket is known to produce chirping sounds that are directly proportional to the current temperature. By measuring the chirps per minute of the cricket, it is possible to determine the temperature in degrees Celsius. This phenomenon can be leveraged to perform basic weather forecasting, especially in areas where other meteorological instruments may not be available.

				To calculate the temperature in degrees Celsius, you can divide the number of chirps per minute by 7.2 and then add 4. For instance, if the cricket chirps 60 times per minute, the temperature can be estimated as follows: 60/7.2 + 4 = 12.33°C.</p>
			</div>
		</div>
		<div class="col-span-6">
			<div class="card">
				<h3>Formula</h3>
				<br />
				<img class="formula" src="../images/chirpformula.png">
			</div>
		</div>
	</div>
	<br />

	<h2>Temperature Calculator</h2>
	<div class="grid">
		<div class="col-span-6">
			<div class="card">
				<h2>Fill in the Following</h2>
                <form name="functionsUserInput" action="activity_2-6a-chirp-chirp.php" method="post">
                    <h3>Chirps Per Minute</h3>
                    <input type="number" name="chirps" autocomplete="off" placeholder="5" value="" class="frmInput"></input>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <br />
                </form>
			</div>
		</div>
		<div class="col-span-6">
			<div class="card">
				<?php
					if ($_POST['subButton'] == 'Submit') {
                        
                        // Define Variable
                        $chirps = $_POST['chirps'];

                        // Error Statements
                        $error = "false";

                        // Checks if any of the boxes are left empty
                        if ($chirps == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must fill out the required components.</h3>";
                        }

                        // Checks if the number is greater than or equal to 0
                        if ($chirps <= "0") {
                            $error = "true";
                            $errorMessage = "<h3>Error: Your number must be greater than 0.</h3>";
                        }

                        function calculateTemperature($chirps) {
							$temperature = $chirps / 7.2 + 4;
							return round($temperature, 2);
						}

                        // Output Message
                        if ($error == "false") {
                            $temperature = calculateTemperature($chirps);
                            echo "<p>The temperature is $temperature &deg;C</p>";

                            if ($temperature > 43) {
                            	echo "<img src='https://live.staticflickr.com/3113/3165297462_e6afa6dbf8_b.jpg'>";
								echo "<p style='color: #d9190b;'>Dead Cricket. :(</p>";
							} else if ($temperature > 27) {
								echo "<img src='https://www.biltmorecounseling.com/wp-content/uploads/2018/07/Heat-thermometer-.jpg'>";
								echo "<p style='color: #eb881e;'>Whew, it is hot!</p>";
							} else if ($temperature > 7) {
								echo "<img src='https://www.rjonesinsurance.com/wp-content/uploads/2018/03/flood-insurance-e1521214694329.jpg'>";
								echo "<p style='color: #fad414;'>Ahhhh, comfortable.</p>";
							} else {
								echo "<img src='https://hips.hearstapps.com/hmg-prod/images/articles/2017/01/cold-weather-makes-you-sick-2-jpg-1488906723.jpeg'>";
								echo "<p style='color: #1492cc;'>Brrrr!</p>";
							}
					    } else {
		                    echo $errorMessage;
	                    }
                    }
				?>
			</div>
		</div>
	</div>

	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
