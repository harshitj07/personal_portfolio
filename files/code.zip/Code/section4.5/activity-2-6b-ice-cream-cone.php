<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.6b - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.6b">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.6b"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--denim);
			text-align: center;
		}

		img {
            height: 50%;
            width: 50%;
            border-radius: 10px;
        }

        img.formula {
            height: 70%;
            width: 70%;
            border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<h2>Introduction</h2>
	<div class="grid">
		<div class="col-span-4">
			<div class="card">
				<h3>Volume Formula</h3>
				<br />
				<img class="formula" src="../images/isformula1.png">
			</div>
		</div>
		<div class="col-span-4">
			<div class="card">
				<h3>Overview</h3>
				<br />
				<p>This program helps calculate the total volume of an ice-cream cone and its mass. The site displays an input form which allows the user to input the radius of the cone/sphere, the height of the cone, and the number of scoops. Using this information, the function will display a result to the user. The functionality behind this is quite simple. The volume of an ice cream cone can be approximated by finding the total volume of a cone and half a circle and the result will be returned through the use of a function. The mass of an ice cream cone can be approximated by taking the total volume and multiplying it by 0.65 which is the average density in grams for an ice cream cone and ice cream scoop.</p>
			</div>
		</div>
		<div class="col-span-4">
			<div class="card">
				<h3>Mass Formula</h3>
				<br />
				<img class="formula" src="../images/isformula2.png">
			</div>
		</div>
	</div>
	<br />

	<h2>Ice Cream Calculator</h2>
	<div class="grid">
		<div class="col-span-6">
			<div class="card">
				<h2>Fill in the Following</h2>
                <form name="functionsUserInput" action="activity-2-6b-ice-cream-cone.php" method="post"> 
                    <h3>Cone Height</h3>
                    <input type="number" name="height" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <h3>Cone Radius</h3>
                    <input type="number" name="radius" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <h3>Number of Scoops</h3>
                    <input type="number" name="scoops" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <br />
                </form>
			</div>
		</div>
		<div class="col-span-6">
			<div class="card">
				<?php
					if ($_POST['subButton'] == 'Submit') {
                        
                        // Define Variable
                        $height = $_POST['height'];
                        $radius = $_POST['radius'];
                        $scoops = $_POST['scoops'];

                        // Error Statements
                        $error = "false";

                        // Checks if any of the boxes are left empty
                        if ($height == "" OR $radius == "" OR $scoops == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must fill out the required components.</h3>";
                        }

                        // Checks if the number is greater than or equal to 0
                        if ($height <= "0" OR $radius <= "0" OR $scoops <= "0") {
                            $error = "true";
                            $errorMessage = "<h3>Error: Your inputs must be greater than 0.</h3>";
                        }

                        // Checks if the height or radius is greater than 20
                        if ($height > "20" OR $radius > "20") {
                            $error = "true";
                            $errorMessage = "<h3>Error: The height and radius must be equal to or less than 20.</h3>";
                        }

                        // Checks if the number of scoops is greater than 5
                        if ($scoops > "5") {
                            $error = "true";
                            $errorMessage = "<h3>Error: The number of scoops must be equal to or less than 10.</h3>";
                        }

                        // Function calculates the volume of the ice cream
                        function calculateVolume($height, $radius, $scoops) {
						    $cone_volume = ($height * pi() * pow($radius, 2)) / 3;
						    $sphere_volume = 4 * (pi() * pow($radius, 3)) / 3;
						    $half_sphere_volume = 4 * (pi() * pow($radius, 3)) / 6;

						    if ($scoops == "1") {
						        $total_volume = ($cone_volume + $half_sphere_volume);
						    } else {
						        $total_volume = ($cone_volume + $half_sphere_volume + (($scoops - 1) * $sphere_volume));
						    }

						    return round($total_volume, 2);
						}

						// Function calculates the weight of the ice cream cone
					    function calculateWeight($height, $radius, $scoops) {
					        $volume = calculateVolume($height, $radius, $scoops);
					        $density = 0.65; // density of ice cream in g/cm^3
					        $weight = $volume * $density;
					        return round($weight, 2);
					    }

					    // Output Message
					    if ($error == "false") {
					        $result = calculateVolume($height, $radius, $scoops);
							$weight = calculateWeight($height, $radius, $scoops);


							if ($scoops == "1") {
								echo "<img src='../images/scoop1.png'><br />";
							} else if ($scoops == "2") {
								echo "<img src='../images/scoop2.png'><br />";
							} else if ($scoops == "3") {
								 echo "<img src='../images/scoop3.png'><br />";
							} else if ($scoops == "4") {
								echo "<img src='../images/scoop4.png'><br />";
							} else if ($scoops == "5") {
								echo "<img src='../images/scoop5.png'><br />";
							}

					        echo "
					        	<h3>Total Volume: " . $result . " cubic units.</h3>
					        	<h3>Total Weight: " . $weight . " grams.</h3>
					        	";
					    } else {
					        echo $errorMessage;
					    }
                    }
				?>
			</div>
		</div>
	</div>

	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
