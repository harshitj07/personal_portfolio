<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.6d - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.6d">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.6d"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--denim);
			text-align: center;
		}

		img {
            height: 30%;
            width: 25%;
            border-radius: 10px;
        }

        img.formula {
            height: 60%;
            width: 90%;
            border-radius: 10px;
        }

        iframe {
        	border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 8%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<h2>Introduction</h2>
	<div class="grid">
		<div class="col-span-4">
            <div class="card">
                <h3>Videos</h3>
				<iframe width="350" height="200" src="https://www.youtube.com/embed/2nwByhuebo4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <br />
                <iframe width="350" height="200" src="https://www.youtube.com/embed/OEzsVR5PQyo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
        </div>
		<div class="col-span-4">
			<div class="card">
				<h3>Overview</h3>
				<br />
				<p>Gas mileage, also known as fuel efficiency, is a critical factor in today's world. With the rising costs of fuel and increasing environmental concerns, more and more people are prioritizing fuel efficiency when purchasing a vehicle. Thankfully, modern car manufacturers are constantly iterating their vehicles' gas mileage, and consumers have more options than ever before. Today's cars often come equipped with advanced technologies, such as hybrid or electric powertrains, regenerative braking, and start-stop systems, which help to maximize fuel efficiency. Also, governments around the world are setting better fuel economy standards, which are forcing car manufacturers to develop more fuel-efficient vehicles. These standards are improving air quality in cities and reducing carbon emissions.</p>
				<p>Read more about fuel consumption here: <a class="link" href="https://www.nrcan.gc.ca/energy-efficiency/transportation-alternative-fuels/fuel-consumption-guide/21002">nrcan.gc.ca</a>.</p>
			</div>
		</div>
		<div class="col-span-4">
			<div class="card">
				<h3>Formula</h3>
				<br />
				<img class="formula" src="../images/feformula.png">
			</div>
		</div>
	</div>
	<br />

	<h2>Fuel Efficiency Calculator</h2>
	<div class="grid">
		<div class="col-span-6">
			<div class="card">
				<h2>Fill in the Following</h2>
                <form name="functionsUserInput" action="activity-2-6d-gas-mileage.php" method="post"> 
                    <h3>Fuel Used in Litres</h3>
                    <input type="number" name="fuel" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <h3>Number of Kilometers Driven</h3>
                    <input type="number" name="km" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <br />
                </form>
			</div>
		</div>
		<div class="col-span-6">
			<div class="card">
				<?php
					if ($_POST['subButton'] == 'Submit') {
                        
                        // Define Variable
                        $fuel = $_POST['fuel'];
                        $km = $_POST['km'];

                        // Error Statements
                        $error = "false";

                        // Checks if any of the boxes are left empty
                        if ($fuel == "" OR $km == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must fill out the required components.</h3>";
                        }

                        // Checks if the number is greater than or equal to 0
                        if ($fuel <= "0" OR $km <= "0") {
                            $error = "true";
                            $errorMessage = "<h3>Error: Your inputs must be greater than 0.</h3>";
                        }

                        // Function calculates the terminal velocity
                        function fuelEfficiency($fuel, $km) {
        					$fuelE = ($fuel/$km) * 100;
        					return $fuelE;
    					}

					    // Output Message
					    if ($error == "false") {
					        $result = fuelEfficiency($fuel, $km);

					        echo "<h3>Fuel Efficiency: " . round($result, 2) . "L/100km</h3>";

					        if ("4" > $result AND $result > "0") {
						        echo "
						        	<img src='../images/gas1.png'><br />
						        	<p style='color: #02fa44;'>Extremely Good</p>
						        	<p>Your car is amazing; among the top in the world!</p>
						        	";
						    } else if ("6" > $result AND $result >= "4") {
						        echo "
						        	<img src='../images/gas2.png'><br />
						        	<p style='color: #49a80a'>Very Good</p>
						        	<p>Your car is performing well above average and is considered highly efficient.</p>
						        	";
						    } else if ("8" > $result AND $result >= "6") {
						        echo "
						        	<img src='../images/gas3.png'><br />
						        	<p style='color: #cede1f;'>Good</p>
						        	<p>Your car is performing at an average level of efficiency.</p>
						        	";
						    } else if ("12" > $result AND $result >= "8") {
						        echo "
						        	<img src='../images/gas4.png'><br />
						        	<p style='color: #f2eb1d;'>Fair</p>
						        	<p>Your cars' fuel efficiency could be improved, but it's still within an acceptable range.</p>
						        	";
						    } else if ("15" > $result AND $result >= "12") {
						        echo "
						        	<img src='../images/gas5.png'><br />
						        	<p style='color: #f2cb1d;'>Poor</p>
						        	<p>Your car is not very fuel efficient and may require more frequent refueling.</p>
						        	";
						    } else if ("20" > $result AND $result >= "15") {
						        echo "
						        	<img src='../images/gas6.png'><br />
						        	<p style='color: #f2a11d;'>Very Poor</p>
						        	<p>Your cars' fuel efficiency is significantly below average and may result in high fuel costs.</p>
						        	";
						    } else if ($result > "20") {
						        echo "
						        	<img src='../images/gas7.png'><br />
						        	<p style='color: #c21104;'>Bad</p>
						        	<p>Your car is single-handedly destroying the environment. Consider upgrading to a more fuel-efficient vehicle to reduce your carbon footprint and save money on fuel costs.</p>
						        	";
						    } else {
						        $error = "true";
						        $errorMessage = "<h3>Error: Invalid inputs.</h3>";
						    }
					    } else {
					        echo $errorMessage;
					    }
                    }
				?>
			</div>
		</div>
	</div>

	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
