<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.6c - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.6c">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.6c"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--denim);
			text-align: center;
		}

		img {
            height: 20%;
            width: 25%;
            border-radius: 10px;
        }

        img.formula {
            height: 60%;
            width: 70%;
            border-radius: 10px;
        }

        iframe {
        	border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<h2>Introduction</h2>
	<div class="grid">
		<div class="col-span-4">
            <div class="card">
                <h3>Videos</h3>
                <iframe width="350" height="200" src="https://www.youtube.com/embed/cCDfNkcGhDM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <br />
                <iframe width="350" height="200" src="https://www.youtube.com/embed/CR0ihuP-V8w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
        </div>
		<div class="col-span-4">
			<div class="card">
				<h3>Overview</h3>
				<br />
				<p>The terminal velocity of an object is the maximum speed at which an object will fall through a fluid at. Objects initially accelerate when falling in a fluid and as the object accelerates, the upward resistive force of the fluid eventually equals the downward force of gravity causing the object to stop accelerating and to reach its terminal (maximum) speed. Terminal velocity is dependent on the gravity, mass of the object, drag coefficient, frontal surface area and density of the gas. This concept is important in understanding the behavior of objects in fluid environments, including skydivers, parachutes, and falling raindrops.</p>
			</div>
		</div>
		<div class="col-span-4">
			<div class="card">
				<h3>Formula</h3>
				<br />
				<img class="formula" src="../images/tvformula.png">
				<br />
				<p>g = gravity | m = mass | Cd = drag coefficient | A = frontal area | p = gas density</p>
			</div>
		</div>
	</div>
	<br />

	<h2>Terminal Velocity Calculator</h2>
	<div class="grid">
		<div class="col-span-6">
			<div class="card">
				<h2>Fill in the Following</h2>
                <form name="functionsUserInput" action="activity-2-6c-terminal-velocity.php" method="post"> 
                    <h3>Object Mass [m]</h3>
                    <input type="number" name="mass" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <h3>Frontal Area (m^3) [a]</h3>
                    <input type="number" name="area" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <h3>Object Shape [Cd]</h3>
                    <select name="coefficient" class="frmInput">
						<option value="Flat Plate" name="shape" class="option">Flat Plate</option>
						<option value="Prism" name="shape" class="option">Prism</option>
						<option value="Bullet Shape" name="shape" class="option">Bullet Shape</option>
						<option value="Sphere" name="shape" class="option">Sphere</option>
						<option value="Airfoil" name="shape" class="option">Airfoil</option>
					</select>
                    <br />
                    <h3>Environment [p]</h3>
                    <select name="density" class="frmInput">
						<option value="Air" name="environment" class="option">Air</option>
						<option value="Fresh Water" name="environment" class="option">Fresh Water</option>
						<option value="Salt Water" name="environment" class="option">Salt Water</option>
					</select>
                    <br />
                    <h3>Planet [g]</h3>
                    <select name="gravity" class="frmInput">
						<option value="Earth" name="planet" class="option">Earth</option>
						<option value="Mars" name="planet" class="option">Mars</option>
						<option value="Venus" name="planet" class="option">Venus</option>
						<option value="Jupiter" name="planet" class="option">Jupiter</option>
					</select>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <br />
                </form>
			</div>
		</div>
		<div class="col-span-6">
			<div class="card">
				<?php
					if ($_POST['subButton'] == 'Submit') {
                        
                        // Define Variable
                        $mass = $_POST['mass'];
                        $area = $_POST['area'];
                        $shape = $_POST['coefficient'];
                        $environment = $_POST['density'];
                        $gravity = $_POST['gravity'];

                        // Error Statements
                        $error = "false";

                        // Checks if any of the boxes are left empty
                        if ($mass == "" OR $area == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must fill out the required components.</h3>";
                        }

                        // Checks if the number is greater than or equal to 0
                        if ($mass <= "0" OR $area <= "0") {
                            $error = "true";
                            $errorMessage = "<h3>Error: Your inputs must be greater than 0.</h3>";
                        }

                        // Initialize drag coefficient based on shape
					    if ($shape == "Flat Plate") {
					        $Cd = 1.28;
					    } else if ($shape == "Prism") {
					        $Cd = 1.14;
					    } else if ($shape == "Bullet Shape") {
					        $Cd = 0.3;
					    } else if ($shape == "Sphere") {
					        $Cd = 0.1;
					    } else if ($shape == "Airfoil") {
					        $Cd = 0.05;
					    } else {
					        $error = "true";
					        $errorMessage = "<h3>Error: Invalid shape selected.</h3>";
					    }

					    // Initialize gas density based on environment
					    if ($environment == "Air") {
					        $p = 1.229;
					    } else if ($environment == "Fresh Water") {
					        $p = 1000;
					    } else if ($environment == "Salt Water") {
					        $p = 1025;
					    } else {
					        $error = "true";
					        $errorMessage = "<h3>Error: Invalid environment selected.</h3>";
					    }

					    // Initialize gravity based on planet
					    if ($gravity == "Earth") {
					        $g = 9.8;
					    } else if ($gravity == "Mars") {
					        $g = 3.7;
					    } else if ($gravity == "Venus") {
					        $g = 8.87;
					    } else if ($gravity == "Jupiter") {
					        $g = 24.5;
					    } else {
					        $error = "true";
					        $errorMessage = "<h3>Error: Invalid planet selected.</h3>";
					    }

                        // Function calculates the terminal velocity
                        function terminalVelocity($mass, $Cd, $p, $g, $area) {
        					$V = sqrt((2 * $mass * $g) / ($p * $area * $Cd ));
        					return $V;
    					}

					    // Output Message
					    if ($error == "false") {
					        $result = terminalVelocity($mass, $Cd, $p, $g, $area);

					        if ($gravity == "Earth") {
						        echo "<img src='../images/earth.png'><br />";
						    } else if ($gravity == "Mars") {
						        echo "<img src='../images/mars.png'><br />";
						    } else if ($gravity == "Venus") {
						        echo "<img src='../images/venus.png'><br />";
						    } else if ($gravity == "Jupiter") {
						        echo "<img src='../images/jupiter.png'><br />";
						    } else {
						        $error = "true";
						        $errorMessage = "<h3>Error: Invalid planet selected.</h3>";
						    }

					        echo "
					        	<p>Object Mass: " . $mass ."</p>
					        	<p>Frontal Area: " . $area ."</p>
					        	<p>Shape: " . $shape ."</p>
					        	<p>Environment: " . $environment ."</p>
					        	<p>Planet: " . $gravity ."</p>
					        	
					        	<h3>Terminal Velocity: " . round($result, 3) ." m/s</h3>
					        	";
					    } else {
					        echo $errorMessage;
					    }
                    }
				?>
			</div>
		</div>
	</div>

	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
