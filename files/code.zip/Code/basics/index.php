<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title id="page-title">Loading...</title>    
    <meta name="description" content="The basics of creating an HTML5 page">
    <meta name="author" content="HTML Basics">    

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@100&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=GFS+Didot&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">
    
    <!-- Linking the stylesheet -->
    <link rel="stylesheet" href="styles.css">
    <script defer src="script.js"></script>
</head>
<body>
    <!-- Navbar Element -->
    <nav id="navbar"></nav>

    <!-- main content -->
    </br>
    </br>

    <!-- About Me -->
    <h2>About Me</h2>
    <p class="fancy">Hi! My name is Harshit Jain and I am a 10th-grade student who currently goes to Aldershot High School. I come from an Indian family and I was born in New Dehli, India in the year 2007. From the age of 3.5, I have been living in Canada. Initially, I resided in Vancouver, on the other side of Canada, but since 2015, I have been residing in the Greater Toronto Area (GTA). I have lived for a year in Mississauga, a year in Oakville, and 5+ years in Burlington. I have a strong passion for math, science, computers, and technology. In the future, I would like to pursue a career in the field of Engineering or Computers whether this is Computer Engineering or Computer Science.</p>

    <div class="about">
        <ul>
            <p><span class="me">Skillset</span></p>
            <p class="list">Technological Mindset</p></br>
            <p class="list">Problem Solving</p></br>
            <p class="list">Leadership</p></br>
            <p class="list">Collaboration</p></br>
            <p class="list">Organization</p></br>
        </ul>
        <ul>
            <p><span class="me">Languages</span></p>
            <p class="list">English</p></br>
            <p class="list">Hindi</p></br>
            <p class="list">French</p></br>
        </ul>
        <ul>
            <p><span class="me">Hobbies</span></p>
            <p class="list">Playing Soccer</p></br>
            <p class="list">Computer Programming</p></br>
            <p class="list">Mathematics</p></br>
            <p class="list">Reading Books</p></br>
            <p class="list">Photography</p></br>
            <p class="list">Playing Video Games</p></br>
        </ul>
    </div>

    <!-- Images that show who I am -->
    <div class="imgme">
        <img class="me" src="https://media.newyorker.com/photos/63a0b8e018f0244bba9fd613/master/w_2560%2Cc_limit/Mochkofsky-Messi.jpg" alt="Image of Messi">
        <img class="me" src="https://images.ctfassets.net/usf1vwtuqyxm/ZYMcLjGl6Gh3FicESY9q3/dcc6bce1f3d9c52fd2fce3bc1098682a/Harry-Potter-2023-Paperbacks-Assets_Purple.jpg" alt="Image of Harry Potter book">
        <img class="me" src="https://images.squarespace-cdn.com/content/v1/5e949a92e17d55230cd1d44f/b9cea5b4-a6ab-4dd8-9850-0f97787b1bc2/2021productcomparison+2.png" alt="Image of product comparison">
    </div>
    <div class="imgme">
        <img class="me" src="https://media.iatiseguros.com/wp-content/uploads/2019/07/04011649/que-ver-india-2.jpg" alt="Image of India">
        <img class="me" src="https://dvyvvujm9h0uq.cloudfront.net/com/articles/1543483387-reinhart-julian-1145947-unsplash.jpg" alt="Image of a beautiful landscape">
        <img class="me" src="https://a.cdn-hotels.com/gdcs/production23/d1075/4afaf5b7-161e-4ca5-8aff-c6f882d2ee64.jpg" alt="Image of a hotel">
    </div>

    <ul>
        <p><span class="me">Awards and Recognition</span></p>
        <p class="list">Grade 8 Graduation - STEM Award</p></br>
        <p class="list">Grade 8 Graduation - Math Award</p></br>
        <p class="list">BASEF - Nikola Tesla Honourable Mention Award 2021</p></br>
        <p class="list">BASEF - Electrical Construction Association of Hamilton Award 2021</p></br>
        <p class="list">Kumon - 2021 Advanced Honour Roll Math - Platinum</p></br>
        <p class="list">Lifesaving Society - Bronze Star</p></br>
        <p class="list">Kumon - 2020 International Standard Math - Bronze</p></br>
        <p class="list">Junior Soccer Team - H.S.S.A.A. Finalist</p></br>
    </ul>
    <br />
    <br />

    <!-- Grade 9 I-STEM Projects -->
    <h2>Grade 9: I-STEM Projects</h2>

    <!-- Introduction -->
    <p class="fancy">In Grade 9, we explored and developed innovation skills that related to engineering and design thinking. We invented, designed, and built things to help solve real-world problems for the community and for people. These designs and ideas helped us develop a mindset geared toward creativity, critical thinking, and project management.</p>

    <div class="project">
        <!-- Project 1 -->
        <p class="fancy">
            <span class="project">Project 01 - Bottle Rocket Project</span>
            </br>
            </br>
            <img src="https://static.wixstatic.com/media/982473_5fee56e845414da09660fefd68fb534d~mv2.jpeg/v1/crop/x_119,y_0,w_1567,h_1843/fill/w_686,h_808,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/IMG_3384.jpeg" class="rounded-corner" style="height: 55%; width: 55%;" alt="Bottle Rocket Project">
            <br />
            <br />
            This was our first major project of the Grade 9 year. This project encompassed many areas of science as we were to build bottle and model rockets. From this project, we were given an introduction to the I-STEM program and got a bit more at ease with the toolkit and all of the requirements. We also learnt key information related to building rockets such as having the correct fins and optimal placement of parts.
        </p>

        <!-- Project 2 -->
        <p class="fancy">
            <span class="project">Project 02 - Local Issue Project</span>
            </br>
            </br>
            <img src="https://static.wixstatic.com/media/982473_3d79968a04db49f2b967976763eb01a6~mv2.jpeg/v1/fill/w_464,h_618,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/982473_3d79968a04db49f2b967976763eb01a6~mv2.jpeg" class="rounded-corner" style="height: 31%; width: 31%;" alt="Local Issue Project">
            <img src="https://static.wixstatic.com/media/982473_abb764042e7d4b1ba196cea963b13009~mv2.jpeg/v1/crop/x_0,y_119,w_3024,h_3794/fill/w_460,h_576,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/IMG_3562.jpeg" class="rounded-corner two" style="height: 31%; width: 31%;" alt="Local Issue Project">
            <br />
            <br />
            The Local Issue Project was our first project that regarded an issue that occurred within the community. Our job was to analyze and choose an issue to solve at Hamilton Harbor. My group and I researched the problems that occurred within the sewer systems of Hamilton and realized a major issue that could be fixed. After determining the issue, we decided to create a few design builds that helped us understand the functionality of our model and how it would help the harbour. Our prototype was an advanced sewer system design that could help reduce water flow in the sewer systems to help the water get filtered before going into Hamilton Harbor. We learnt key information from this project regarding run-off, the geographics of a city, and how certain chemicals react when being in open waters.
        </p>
    </div>

    <div class="project">
        <!-- Project 3 -->
        <p class="fancy">
            <span class="project">Project 03 - McMaster Human Centered Design Project</span>
            </br>
            </br>
            <img src="https://static.wixstatic.com/media/982473_940bc216907b4bdd92614a3fa8e7df18~mv2.jpg/v1/crop/x_0,y_60,w_1512,h_1896/fill/w_386,h_480,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/IMG_5458_JPG.jpg" class="rounded-corner" style="height: 31%; width: 31%;" alt="McMaster Human Centered Design Project">
            <img src="https://static.wixstatic.com/media/982473_694e3dc206964564a1452ae8265e0f05~mv2.jpeg/v1/fill/w_388,h_516,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/982473_694e3dc206964564a1452ae8265e0f05~mv2.jpeg" class="rounded-corner" style="height: 31%; width: 31%;" alt="McMaster Human Centered Design Project">
            <br />
            <br />
            This project was very interesting for us as we were given the task to help an elderly man who suffered from many disabilities. This project is the same project given to 1st year McMaster University students. For this project, my group determined a key issue that the man was suffering from and we decided to help his issues with that. We chose the ability to play board games with his son as we felt empathy towards the problem. Our group constructed a robot that was functional and could move board game pieces and roll interactive dice. This project helped us develop key designing skills and we were able to also learn more about the diseases and disabilities the man was suffering from.
        </p>

        <!-- Project 4 -->
        <p class="fancy">
            <span class="project">Project 04 - Innovation Project</span>
            </br>
            </br>
            <img src="https://static.wixstatic.com/media/982473_a8aa122389c0493e803da0aaddec9490~mv2.jpeg/v1/fill/w_482,h_640,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/982473_a8aa122389c0493e803da0aaddec9490~mv2.jpeg" class="rounded-corner" style="height: 31%; width: 31%;" alt="Innovation Project">
            <img src="https://static.wixstatic.com/media/982473_365849d2a69643f188e3314c771b0ddb~mv2.jpeg/v1/crop/x_0,y_125,w_3024,h_3782/fill/w_482,h_602,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/IMG_0456.jpeg" class="rounded-corner" style="height: 31%; width: 31%;" alt="Innovation Project">
            <br />
            <br />
            Within this project, we were given the flexibility to work with anyone we wanted and build anything we wanted to help solve an issue in the world. My group and I decided to innovate the functionality of a whiteboard eraser. Although this seems like a very effective and useful product, we decided to implement storage for markers, a replaceable cloth, and a built-in spray on our model. We 3D printed our design and our model worked very effectively which was fantastic. In fact, we were also nominated for the top 8 projects in the entire grade which was amazing. This project allowed us to utilize all the information we learnt throughout the year and use the I-STEM toolkit to show our learning and thinking process.
        </p>
    </div>

    <!-- I-STEM Link -->
    <p class="fancy">This <a class="link" href="https://www.hdsb.ca/learning-and-resources/Pages/Secondary%20Education%20and%20Pathways/I-STEM.aspx">link</a> talks more about the I-STEM Program.</p>
    </br>
    </br>
    </br>

    <!-- footer -->
    <footer>
        <p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
    </footer>

    <!-- turn work in widget -->
    <div id="turn-work-in"></div>
</body>
</html>
