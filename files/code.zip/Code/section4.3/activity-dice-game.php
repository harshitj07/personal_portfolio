<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.4d - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Dice Game">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.4d - Dice Game"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--denim);
			text-align: center;
		}

		img {
			height: 125px;
			width: 125px;
		}

		.card {
			position: relative;
			width: 100%;
			height: 470px; 
			padding: 2%; 
			background: rgba(0,0,0,0.4);
			border-radius: 0.5em; 
			display: inline-flex;
			box-sizing: border-box;
			align-items: center; 
			justify-content: center; 	
			align-content: center;
			justify-items: center;
			flex-direction: column;
		}

		.php {
			font-size: 20px; 
			align-items: center; 
			justify-content: center; 
			display: flex; 
			padding: 50px
		}

		.grid {
			padding: 0 5vw 0 5vw;
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.submit {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;

		    width: 100px;
		    height: 65px;

		    margin-left: 20px;
		}

		.submit:hover,
		.submit:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.submit:active {
		    background: var(--color);
		    color: #333;
		}

		/* Input box styling */
		select.frmInput {
			border: 3px solid var(--denim);
			border-radius: 5px;
			margin: 10px;
			height: 50px;
			width: 100px;
			text-align: center;
		}	

		select.frmInput:hover,
		select.frmInput:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: black;
		}

		select.frmInput:active {
		    background: var(--denim);
		    color: black;
		}

		::placeholder, option, textarea, input, select {
			font-family: 'Nunito', sans-serif;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->

	<p>Try and guess the number! If you get it right, you earn credits! If you get it wrong too many times, you lose!</p>
	<hr style='width:600px;'>
	<br />

	<div class="grid">
		<div class="col-span-6">
			<div class="card">
				<?php
					// create variables

					// rand() function randomly picks a number between 1 and 6 and assigns it to the variable $roll
						$roll = rand(1,6); 
						$number = $_POST['number'];
						$credit = $_POST['credit'];

					// initialize wins and losses
					if ($_SESSION['wins'] == "") { 
						$_SESSION['wins'] = 0;
					}
					
					if ($_SESSION['losses'] == "") { 
						$_SESSION['losses'] = 0;
					}

					// check for balance 
					if ($_SESSION['balance'] == "") {
						$_SESSION['balance'] = 15;
					}

					// check for reset 
					if ($_POST['resButton'] == "Reset") {
						$_SESSION['wins'] = 0;
						$_SESSION['losses'] = 0;
						$_SESSION['balance'] = 15;
						$_SESSION['total']  = 0;
						echo "<p>The game has been reset.</p>";
					}

					if ($_POST['subButton'] == 'Submit') {
						// increase the total amount of rolls
						$_SESSION['total']  = $_SESSION['total']  + 1;

						// roll the dice
						echo "<h3>You rolled a " . $roll . ". </h3>";
						echo "<img src=\"../images/die" . $roll . ".png\" alt=\"Die Image\" class=\"animate__animated animate__rotateIn\">";

						// your guess
						echo "<h3>You guessed " . $number . ". </h3>";
						
						// increase or decrease number of credits and output an echo statment
						if ($number == $roll AND $credit != "1") {
							$_SESSION['wins']++;
							$_SESSION['balance'] += $credit;
							echo "<p>You guessed right! You win " . $credit . " credits.</p>";
						} else if ($number == $roll AND $credit == "1") {
							$_SESSION['wins']++;
							$_SESSION['balance'] += $credit;
							echo "<p>You guessed right! You win " . $credit . " credit.</p>";
						} else if ($number != $roll AND $credit != "1") {
							$_SESSION['losses']++;
							$_SESSION['balance'] -= $credit;
							echo "<p>You guessed wrong! You lose " . $credit . " credits.</p>";
						} else if ($number != $roll AND $credit == "1") {
							$_SESSION['losses']++;
							$_SESSION['balance'] -= $credit;
							echo "<p>You guessed wrong! You lose " . $credit . " credit.</p>";
						}

						// check if balance is 0
						if ($_SESSION['balance'] <= "0") {
							echo "<h3>Game has been reset! You lost all of your credits!</h3>";
							$_SESSION['wins'] = 0;
							$_SESSION['losses'] = 0;
							$_SESSION['balance'] = 15;
							$_SESSION['total']  = 0;
						}
					}
				?>
			</div>
		</div>
		<div class="col-span-6">
			<div class="card">
				<form name="form1" action="activity-dice-game.php" method="post">
				
				<tr>
					<td align='center' valign='center'>

						<!-- simple drop-down lists for numbers -->
						<select name="number" class="frmInput">
							<option value="1" name="number" class="option">1</option>
							<option value="2" name="number" class="option">2</option>
							<option value="3" name="number" class="option">3</option>
							<option value="4" name="number" class="option">4</option>
							<option value="5" name="number" class="option">5</option>
							<option value="6" name="number" class="option">6</option>
						</select>
					</td>

					<td align='center' valign='center'>	
					<!-- drop-down lists for credits -->
						<?
							if($_SESSION['balance'] > 0) {
								echo "<select name='credit' class='frmInput'>";
								for ($i = 0; $i < $_SESSION['balance']; $i++) {
									if ($i == 0) {
										echo "<option value='".($i + 1)."' name='credit' class='option' selected>".($i + 1)." Credit</option><br />";
									} else {
										echo "<option value='".($i + 1)."' name='credit' class='option'>".($i + 1)." Credit</option><br />";
									}
								}
								echo "</select>";
							} 
						?>
					</td>

					<td align='center' valign='center'>

						<!-- submit button -->
						<input type="submit" name="subButton" value="Submit" class="submit"></input>
					</td>

					<td align='center' valign='center'>

						<!-- reset button -->
						<input type="submit" name="resButton" value="Reset" class="submit"></input>
					</td>
				</tr>
				<br />
				<br />
			</form>

			<?php

				// displaying statistics
				echo "<p>Wins: " . $_SESSION['wins'] . "</p>";
				echo "<p>Losses: " . $_SESSION['losses'] . "</p>";

				if ($_SESSION['wins'] != '' AND $_SESSION['losses'] != '') {
					echo "<p>Win %: " . ($_SESSION['wins'] / $_SESSION['total']) * 100 . "</p>";
				} else if ($_SESSION['wins'] == '1') {
					echo "<p>Win %: 100</p>";
				} else {
					echo "<p>Win %: 0</p>";
				}
				
				echo "<p>Total Rolls: " . $_SESSION['total'] . "</p>";
				echo "<p>Credit Balance: " . $_SESSION['balance'] . "</p>";
			?>

			</div>
		</div>
	</div>

	<!-- end main content -->
	<br />
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
