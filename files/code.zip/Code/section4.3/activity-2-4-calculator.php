<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.4 - Harshit Jain") ?></title>	

	<meta name="description" content="This page is a simple calculator">
	<meta name="author" content="Harshit Jain">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.4 - Calculator"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--snow);
			text-align: center;
		}

		.card {
			position: relative;
			width: 100%;
			height: 470px; 
			padding: 2%; 
			background: rgba(0,0,0,0.4);
			border-radius: 0.5em; 
			display: inline-block;
			box-sizing: border-box;
		}

		.php {
			font-size: 20px; 
			align-items: center; 
			justify-content: center; 
			display: flex; 
			padding: 50px
		}

		.grid {
			padding: 0 5vw 0 5vw;
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.inputField {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;

		    margin: 25px;
		    padding: 20px;

		    width: 125px;
		    height: 65px;

		    text-decoration: none;
		    font-family: 'Nunito', sans-serif;
		}

		.inputField:hover,
		.inputField:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.inputField:active {
		    background: var(--color);
		    color: black;
		}

		/* Input box styling */
		input.numInput {
			border: 3px solid var(--denim);
			border-radius: 5px;
			margin: 10px;
			height: 30px;
			width: 120px;
			text-align: center;
		}	

		input.numInput:hover,
		input.numInput:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: black;
		}

		input.numInput:active {
		    background: var(--denim);
		    color: black;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<p>Simple Calculator Form</p>
	<hr style="color: var(--snow); width: 200px;">
	<br />
	<br />

	<div class="grid">
		<div class="col-span-4">
			<div class="card">
				<form name="form1" action="activity-2-4-calculator.php" method="post">
					<br />
					<input type="number" name="num1" value="" step="any" class="numInput"></input>
					<br />
					<br />
					<input type="radio" name="operation" value="mul" class="radioInput">Multiplication</input>
					<br />
					<br />
					<input type="radio" name="operation" value="div" class="radioInput">Division</input>
					<br />
					<br />
					<input type="radio" name="operation" value="sub" class="radioInput">Subtraction</input>
					<br />
					<br />
					<input type="radio" name="operation" value="add" class="radioInput" checked>Addition</input>
					<br />
					<br />
					<input type="number" name="num2" value="" step="any" class="numInput"></input>
					<br />
					<input type="submit" value="Submit" name="submit1" class="inputField"></input>
					<br />
				</form>
			</div>
		</div>
		<div class="col-span-4">
			<div class="card php">
				<?php
					$operation = $_POST['operation'];
					$numOne = $_POST['num1'];
					$numTwo = $_POST['num2'];
					$numThree = $_POST['num3'];
					$result1;
					$result2;

					// Mathematical Syntax

					// Multiplication -> *
					// Division -> /
					// Subtraction -> -
					// Addition -> +
					// Sine -> sin(deg2rad($var))
					// Cosine -> cos(deg2rad($var))
					// Tangent -> tan(deg2rad($var))
					// Squareroot -> sqrt($var)
					// Square -> pow(2, $var)
					// Cube -> pow(3, $var)

					if ($_POST['submit1']) {
						if ($operation == "mul") {
							$result1 = $numOne * $numTwo;
							echo "<p>$numOne x $numTwo = $result1</p>";
						}

						if ($operation == "div") {
							if ($numTwo == "0") {
								echo "<p style='color: var(--denim);'>Error, please give a valid input for Number 2!</p>";
							}
							
							else {
								$result1 = $numOne / $numTwo;
								echo "<p>$numOne ÷ $numTwo = $result1</p>";
							}
						}

						if ($operation == "sub") {
							$result1 = $numOne - $numTwo;
							echo "<p>$numOne - $numTwo = $result1</p>";
						}

						if ($operation == "add") {
							$result1 = $numOne + $numTwo;
							echo "<p>$numOne + $numTwo = $result1</p>";
						}

						if ($numOne == "") {
							echo "<p style='color: var(--denim);'>Error, please give a valid input for Number 1!</p>";
						}

						if ($numTwo == "") {
							echo "<p style='color: var(--denim);'>Error, please give a valid input for Number 2!</p>";
						}
					}

					if ($_POST['submit2']) {
						if ($operation == "sin") {
							$result2 = sin(deg2rad($numThree));
							echo "<p>Sine of $numThree = $result2</p>";
						}

						if ($operation == "cos") {
							$result2 = cos(deg2rad($numThree));
							echo "<p>Cosine of $numThree = $result2</p>";
						}

						if ($operation == "tan") {
							$result2 = tan(deg2rad($numThree));
							echo "<p>Tangent of $numThree = $result2</p>";
						}

						if ($operation == "srt") {
							$result2 = sqrt($numThree);
							echo "<p>Squareroot of $numThree = $result2</p>";
						}

						if ($operation == "sqr") {
							$result2 = pow(2, $numThree);
							echo "<p>Square of $numThree = $result2</p>";
						}

						if ($operation == "cub") {
							$result2 = pow(3, $numThree);
							echo "<p>Cube of $numThree = $result2</p>";
						}

						if ($numThree == "") {
							echo "<p style='color: var(--denim);'>Error, please give a valid input for Number 3!</p>";
						}
					}
				?>
			</div>
		</div>
		<div class="col-span-4">
			<div class="card">
				<form name="form2" action="activity-2-4-calculator.php" method="post">
					<br />
					<input type="number" name="num3" value="" step="any" class="numInput"></input>
					<br />
					<br />
					<input type="radio" name="operation" value="sin" class="radioInput">Sine</input>
					<br />
					<br />
					<input type="radio" name="operation" value="cos" class="radioInput">Cosine</input>
					<br />
					<br />
					<input type="radio" name="operation" value="tan" class="radioInput">Tangent</input>
					<br />
					<br />
					<input type="radio" name="operation" value="srt" class="radioInput">Square Root</input>
					<br />
					<br />
					<input type="radio" name="operation" value="sqr" class="radioInput" >Squared</input>
					<br />
					<br />
					<input type="radio" name="operation" value="cub" class="radioInput" checked>Cubed</input>
					<br />
					<input type="submit" value="Submit" name="submit2" class="inputField"></input>
					<br />
				</form>
			</div>
		</div>
	</div>

	<!-- end main content -->
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
