<?php if (!isset($_SESSION)) { session_start(); } ?>
<?php session_start(); ?>

<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "PHP Sessions - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="PUT YOUR PAGE DESCRIPTION HERE">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "PHP Sessions"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--snow);
			text-align: center;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />

	<!-- main content -->

	<?php 
		// initialize wins and losses
		if ($_SESSION['wins'] == "") { 
			$_SESSION['wins'] = 0;
		}
		
		if ($_SESSION['losses'] == "") { 
			$_SESSION['losses'] = 0;
		}

		// check for reset 
		if ($_GET['reset'] == "yes") {
			$_SESSION['wins'] = 0;
			$_SESSION['losses'] = 0;
			$_SESSION['total'] = 0;
			echo "<p>The game has been reset.</p>";
		} 

		else {
			// create a random number between 1 and 5.
			$randNum = rand(1,5);

			// show the random number
			echo "<p>The random number is <b>" . $randNum . "</b></p>";

			if ($randNum == 3) {
				echo "<p>The number equalled 3. YOU WIN!</p>";
				$_SESSION['wins']  = $_SESSION['wins']  + 1;
				$_SESSION['total']  = $_SESSION['total']  + 1;
			} 

			else {
				echo "<p>The number did NOT equal 3. YOU LOSE!</p>";
				$_SESSION['losses']  = $_SESSION['losses']  + 1;
				$_SESSION['total']  = $_SESSION['total']  + 1;
			}
		}

		echo "<p>WINS: " . $_SESSION['wins'] . " |  LOSSES: " . $_SESSION['losses'] . "</p>";

		if ($_SESSION['wins'] != '' AND $_SESSION['losses'] != '') {
			echo "<p>WIN %: " . ($_SESSION['wins'] / $_SESSION['losses']) * 100 . "</p>";
		}

		else if ($_SESSION['wins'] == '1') {
			echo "<p>WIN %: 100</p>";
		}

		else {
			echo "<p>WIN %: 0</p>";
		}
		
		echo "<p>TOTAL ROLLS: " . $_SESSION['total'] . "</p>";
		echo "<p><a href='playing-with-sessions.php'>ROLL AGAIN</a> | <a href='playing-with-sessions.php?reset=yes'>RESET</a></p>";
	?>


	<!-- load jquery -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>

	<!-- end main content -->
	<br />
	<br />
	<br />
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>