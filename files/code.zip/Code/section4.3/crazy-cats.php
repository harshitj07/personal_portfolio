<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.4b - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Crazy Cats Page">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.4b - Crazy Cats"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--snow);
			text-align: center;
		}

		img {
			border-radius: 5px;
			width: 200;
			height: 200px;
		}

		.card {
			position: relative;
			width: 90%;
			height: 475px; 
			padding: 2%; 
			background: rgba(0,0,0,0.4);
			border-radius: 0.5em; 
			display: inline-block;
			box-sizing: border-box;
			margin: 30px;
			text-align: center;
		}

		.php {
			font-size: 20px; 
			align-items: center; 
			padding: 50px
		}

		.grid {
			padding: 0 5vw 0 5vw;
		}

		::placeholder, option {
			font-family: 'Nunito', sans-serif;
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.submit {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;

		    margin: 25px;
		    padding: 20px;

		    width: 125px;
		    height: 65px;

		    text-decoration: none;
		    font-family: 'Nunito', sans-serif;
		}

		.submit:hover,
		.submit:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.submit:active {
		    background: var(--color);
		    color: black;
		}

		/* Input box + Dropdown styling */
		.ipt {
			border: 3px solid var(--denim);
			border-radius: 5px;
			margin: 10px;
			height: 30px;
			width: 120px;
			text-align: center;
		}	

		.ipt:hover,
		.ipt:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: black;
		  	height: 40px;
		  	width: 140px;
		  	transition-duration: 1.5s;
		}

		.ipt:active {
		    background: #e6f1fc;
		    color: black;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<div class="grid">
		<div class="col-span-6">
			<div class="card">
				<form method="post">
					<p style="color: var(--denim);">What Colour is Your Cat?</p>
					<select name="color" value="" class="ipt">
						<option value="">Pick a Colour</option>
						<option value="black">Black</option>
						<option value="white">White</option>
						<option value="orange">Orange</option>
						<option value="brown">Brown</option>
						<option value="blacknwhite">Black and White</option>
						<option value="grey">Grey</option>
						<option value="other">Other</option>
					</select>
					<br/>
					<p style="color: var(--denim);">How Much Does Your Cat Weigh (Kg)?</p>
					<input type="text" name="weight" value="" class="ipt" placeholder="20"></input>
					<br/>
					<p style="color: var(--denim);">What Is Your Cat's Name?</p>
					<input type="text" name="name" value="" class="ipt" placeholder="Garfield"></input>
					<br/>
					<input type="submit" name="subButton" value="Submit" method="post" class="submit"></input>  
				</form>
			</div>
		</div>
		<div class="col-span-6">
			<div class="card php">
				<?php
					// Declare Variables
					$name  = $_POST['name'];
					$weight = $_POST['weight'];
					$color = $_POST['color'];

					// Conditional Statements
					if ($_POST['subButton']) {

						// Error Checking
						if ($weight <= "0" OR $name == "" OR $color == "") {
							echo "
									<br />
									<br />
									<br />
									<br />
									<br />
									<br />
									<p style='color: var(--denim);'>Invalid!!!</p>
									<br />
									<br />
								";
						}

						// Image Conditional Statements
						if ($color == "black" AND $weight <= "20") {
							echo "
									<h2 style='color: var(--denim);'>$name</h2>
									<img src='https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F47%2F2020%2F06%2F26%2Fblack-cat-on-tree-stump-588278854-2000.jpg'>
									<br />
								";
						}

						if ($color == "white") {
							echo "
									<h2 style='color: var(--denim);'>$name</h2>
									<img src='https://a-z-animals.com/media/2022/10/iStock-1205113979-1024x683.jpg'>
									<br />
								";
						}

						if ($color == "orange") {
							echo "
									<h2 style='color: var(--denim);'>$name</h2>
									<img src='https://cdn.mos.cms.futurecdn.net/2QPcHVvuSQ3DkaTbzyfwA9.jpg'>
									<br />
								";
						}

						if ($color == "brown") {
							echo "
									<h2 style='color: var(--denim);'>$name</h2>
									<img src='https://cat-world.com/wp-content/uploads/2022/05/brown-kitten.jpg'>
									<br />
								";
						}

						if ($color == "blacknwhite") {
							echo "
									<h2 style='color: var(--denim);'>$name</h2>
									<img src='https://www.thesprucepets.com/thmb/vgvK9_iqmLpIHezaqZ_Mi5evmQM=/1600x0/filters:no_upscale():strip_icc()/black-and-white-cat-breeds-4843190-hero-8ea9ae92c05c46fb9495f789ca595f37.jpg'>
									<br />
								";
						}

						if ($color == "grey") {
							echo "
									<h2 style='color: var(--denim);'>$name</h2>
									<img src='https://hips.hearstapps.com/hmg-prod/images/cute-grey-cat-royalty-free-image-1658452916.jpg'>
									<br />
								";
						}

						if ($color == "other") {
							echo "
									<h2 style='color: var(--denim);'>$name</h2>
									<img src='https://cdn.unifiedcommerce.com/content/product/large/796780609341.jpg'>
									<br />
								";
						}

						// Weight Conditional Statements
						if ($weight > "0" AND $weight <= "2.5") {
							echo "
									<p style='color: var(--denim);'>$weight Kg</p>
									<p>Skin and bones!!!</p>
									<br />
								";
						}

						if ($weight > "2.5" AND $weight <= "5") {
							echo "
									<p style='color: var(--denim);'>$weight Kg</p>
									<p>Small, but healthy...</p>
									<br />
								";
						}
						
						if ($weight > "5" AND $weight <= "10") {
							echo "
									<p style='color: var(--denim);'>$weight Kg</p>
									<p>Getting a little heavy I think!</p>
									<br />
								";
						}

						if ($weight > "10" AND $weight <= "15") {
							echo "
									<p style='color: var(--denim);'>$weight Kg</p>
									<p>You may wanna hide the food..</p>
									<br />
								";
						}

						if ($weight > "15" AND $weight <= "20") {
							echo "
									<p style='color: var(--denim);'>$weight Kg</p>
									<p>Are you sure this is a cat????</p>
									<br />
								";  
						}

						if ($color != "black" AND $weight > "20") {
							echo "
									<p style='color: var(--denim);'>$weight Kg</p>
									<p>You’re going to need another job to feed this thing!</p>
									<br />
								"; 
						}	

						if ($color == "black" AND $weight > "20") {
							echo "
									<h2 style='color: var(--denim);'>$name</h2>
									<img src='https://pumawatch.co.uk/wp-content/uploads/2022/01/black-puma-1024x867.jpg'>
									<br />
									<p style='color: var(--denim);'>$weight Kg</p>
									<p>This is outrageous!!!</p>
									<br />
								";  
						}
					}
				?>
			</div>
		</div>
	</div>

	<!-- end main content -->
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
