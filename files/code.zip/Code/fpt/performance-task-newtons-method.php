<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Newton's Method - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Newton's Method - FPT">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Newton's Method - FPT"; ?>

	<style>
		body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        img {
            height: 50%;
            width: 100%;
            border-radius: 10px;
        }

        img.icon {
            height: 150px;
            width: 150px;
            border-radius: 10px;
        }

        iframe {
            width: 300px;
            height: 175px;
            border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .card2 {
            position: relative;
            width: 70%;
            padding: 10%;
            background: var(--navy);
            border-radius: 0.5em;
            display: inline-flex;
            box-sizing: border-box;
            align-items: center;
            justify-content: center;
            align-content: center;
            justify-items: center;
            flex-direction: column;
            margin: 3%;
        }

        .output-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .output-item {
            flex: 1;
        }

        .score-container {
            display: flex;
            justify-content: center; 
        }

        .score-item {
            flex: 1;
        }

        .result {
            margin-top: 20px;
            text-align: center;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
            margin: auto 0;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        /* Input box styling */
        select.frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 50px;
            width: 200px;
            text-align: center;
        }   

        select.frmInput:hover,
        select.frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
        }

        select.frmInput:active {
            background: var(--denim);
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
    <h2>Introduction</h2>
    <div class="grid">
        <div class="col-span-3">
            <br />
            <br />
            <img class="img" src="../images/fpt2flowchart.png">
            <br />
            <br />
            <iframe src="https://www.youtube.com/embed/-5e2cULI3H8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <div class="col-span-6">
            <div class="card">
                <p>This performance task focuses around the Newton's Method. The Newton's Method is a very old recursive algorithm dating back 1000s of years and it can be used to quickly calculate the square root of a number to a high degree of accuracy without using a calculator.</p>
                <p>"A recursive algorithm is an algorithm which calls itself with "smaller (or simpler)" input values, and which obtains the result for the current input by applying simple operations to the returned value for the smaller (or simpler) input."</p>
                <p>The program that has been created allows the user to input a number that they would like to find the square root of. The user can also enter the number of iterations they would like. From this, the application will run the calculation as a loop for the desired number of iterations and output the value each time in a table.</p>
                <br />
                <a class="link" href="https://en.wikipedia.org/wiki/Newton%27s_method">en.wikipedia.org</a>
            </div>
        </div>
        <div class="col-span-3">
            <br />
            <br />
            <img class="img" src="../images/fpt2formula.png">
            <br />
            <br />
            <iframe src="https://www.youtube.com/embed/W7S94pq5Xuo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
    </div>
    <br />

    <h2>Newton's Method - Recursive Algorithm</h2>
    <br />
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h2>Select</h2>
                <form name="functionsUserInput" action="performance-task-newtons-method.php" method="post">
                    <h3>Number #</h3>
                    <input type="number" name="num" class="frmInput"></input>
                    <br />
                    <h3>Number of Recursions</h3>
                    <input type="number" name="rec" class="frmInput"></input>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <br />
                </form>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <?php
                    if ($_POST['subButton']) {
                        
                        // Setting variables
                        $number = $_POST['num'];
                        $iterations = $_POST['rec'];

                        // Setting up error statements
                        $error = "false";
                        $errorMessage = "";

                        // Check if player choice is empty
                        if ($number == "" OR $iterations == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must fill out the input boxes.</h3>";
                        }

                        // Check if player choice is empty
                        if ($iterations > "20") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must iterate 20 or less times.</h3>";
                        }
                        
                        // Runs if the error is false
                        if ($error == "false") {

                            // Setting a function for Newton's Method
                            function newtonsMethod($number, $guess, $iterations) {

                                // Conditional statement for calculations
                                if ($iterations == 0) {
                                    return $guess;
                                } else {
                                    $guess = 1/2 * ($guess + ($number / $guess));
                                    // echo "<p>Iteration " . ($iterations) . ": " . $guess . "</p>";
                                    return newtonsMethod($number, $guess, $iterations - 1);
                                }
                            }
                            
                            // Displaying statements after the calculation
                            echo "<h2>Approximation</h2>";
                            echo "<p>Starting #: " . $number . "</p>";
                            echo "<p>Number of Iterations: " . $iterations . "</p>";
                            echo "<h3>Iterations:</h3>";

                            // Creating a table to display iterations and values
                            echo "<table>";
                            for ($i = 0; $i <= $iterations; $i++) {
                                echo "<tr>";
                                echo "<th>x<sup>" . $i . "</sup></th>";
                                echo "<td>" . newtonsMethod($number, $number, $i) . "</td>";
                                echo "</tr>";
                            }
                            $estimatedSqrt = newtonsMethod($number, $number, $iterations);
                            echo "</table>";
                        
                            $phpSqrt = sqrt($number);
                            
                            // Comparison statements
                            echo "<h2>Comparison</h2>";
                            echo "<p>Estimated Square Root: " . $estimatedSqrt . "</p>";
                            echo "<p>PHP sqrt() Result: " . $phpSqrt . "</p>";
                            echo "<p>Comparison: ";
                            if ($estimatedSqrt == $phpSqrt) {
                                echo "Match";
                            } else {
                                echo "Mismatch";
                            }
                            echo "</p>";

                            $difference = abs($phpSqrt - $estimatedSqrt);
                            echo "<p>Difference: " . $difference ."</p>";
                        } else {
                            echo $errorMessage;
                        }
                    }
                ?>
            </div>
        </div>
    </div>

	<!-- end main content -->
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
