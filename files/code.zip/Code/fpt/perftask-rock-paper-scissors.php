<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "RPSSL - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Rock, Paper, Scissors, Spock, Lizard - FPT">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Rock, Paper, Scissors, Spock, Lizard - FPT"; ?>


	<style>
		body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        img {
            height: 70%;
            width: 80%;
            border-radius: 10px;
        }

        img.icon {
            height: 150px;
            width: 150px;
            border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .card2 {
            position: relative;
            width: 70%;
            padding: 10%;
            background: var(--navy);
            border-radius: 0.5em;
            display: inline-flex;
            box-sizing: border-box;
            align-items: center;
            justify-content: center;
            align-content: center;
            justify-items: center;
            flex-direction: column;
            margin: 3%;
        }

        .output-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .output-item {
            flex: 1;
        }

        .score-container {
            display: flex;
            justify-content: center; 
        }

        .score-item {
            flex: 1;
        }

        .result {
            margin-top: 20px;
            text-align: center;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
            margin: auto 0;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        /* Input box styling */
        select.frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 50px;
            width: 200px;
            text-align: center;
        }   

        select.frmInput:hover,
        select.frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
        }

        select.frmInput:active {
            background: var(--denim);
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
    <h2>Introduction</h2>
    <div class="grid">
        <div class="col-span-3">
            <br />
            <br />
            <img class="img" src="https://puzzlewocky.com/wp-content/uploads/2016/10/RockPaperScissorsLizardSpock.jpg">
        </div>
        <div class="col-span-6">
            <div class="card">
                <p>This performance task is a rock, paper, scissors, spock, lizard game. The user is required to make a selection using a radio button type input form. Upon the submission, the computer randomly generates either of the 5 choices and battles the player's choice. Conditions and decisions determine the winner for the games played.</p>
            </div>
        </div>
        <div class="col-span-3">
            <br />
            <br />
            <img class="img" src="https://media-cldnry.s-nbcnews.com/image/upload/newscms/2016_11/1016196/rock-paper-scissors-today-tease-160317.jpg">
        </div>
    </div>
    <br />

    <h2>RPSSL Game</h2>
    <p>Best Out Of 7</p>
    <br />
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h2>Select</h2>
                <form name="functionsUserInput" action="perftask-rock-paper-scissors.php" method="post">
                    <h3 style="color: var(--snow);"><input type="radio" value="rock" name="game" class="radio" selected> Rock <i class="fa-solid fa-hand-back-fist"></i></h3>
                    <br />
                    <h3 style="color: var(--snow);"><input type="radio" value="paper" name="game" class="radio"> Paper <i class="fa-sharp fa-solid fa-hand"></i></h3>
                    <br />
                    <h3 style="color: var(--snow);"><input type="radio" value="scissors" name="game" class="radio"> Scissors <i class="fa-solid fa-hand-scissors"></i></h3>
                    <br />
                    <h3 style="color: var(--snow);"><input type="radio" value="spock" name="game" class="radio"> Spock <i class="fa-solid fa-hand-spock"></i></h3>
                    <br />
                    <h3 style="color: var(--snow);"><input type="radio" value="lizard" name="game" class="radio"> Lizard <i class="fa-solid fa-hand-lizard"></i></h3>
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <br />
                </form>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <h2>Result</h2>
                <br />
                <?php
                    // Start the session
                    session_start();

                    // Array for the choices
                    $choices = array(
                        'rock' => 'https://cdn3.iconfinder.com/data/icons/hand-gesture-outline-1/32/44_fist_hand_gesture_rock-512.png',
                        'paper' => 'https://cdn.icon-icons.com/icons2/3194/PNG/512/hand_paper_icon_194460.png',
                        'scissors' => 'https://www.pngkit.com/png/full/37-377207_hand-scissors-icon.png',
                        'spock' => 'https://static-00.iconduck.com/assets.00/spock-hand-icon-512x512-8dkve32h.png',
                        'lizard' => 'https://cdn.icon-icons.com/icons2/3246/PNG/512/hand_lizard_icon_198389.png'
                    );

                    // Setting up error statements
                    $error = "false";
                    $errorMessage = "";

                    // Run this if the submit button is pressed
                    if ($_POST['subButton']) {
                        $playerChoice = $_POST['game'];

                        // Check if player choice is empty
                        if ($playerChoice == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must select one of the choices.</h3>";
                        }

                        if ($error == "false") {
                            // Checks if player score is set in the session, if not, set it to 0
                            if ($_SESSION['playerScore'] == "") {
                                $_SESSION['playerScore'] = 0;
                            }

                            // Checks if computer score is set in the session, if not, set it to 0
                            if ($_SESSION['computerScore'] == "") {
                                $_SESSION['computerScore'] = 0;
                            }

                            // Randomly select computer's choice
                            $computerChoice = array_rand($choices);

                            // Conditional for who wins
                            if ($playerChoice == $computerChoice) {
                                $result = "It's a Tie!";
                            } else if (
                                ($playerChoice == 'rock' AND $computerChoice == 'scissors') OR
                                ($playerChoice == 'paper' AND $computerChoice == 'rock') OR
                                ($playerChoice == 'scissors' AND $computerChoice == 'paper') OR
                                ($playerChoice == 'spock' AND $computerChoice == 'rock') OR
                                ($playerChoice == 'scissors' AND $computerChoice == 'lizard') OR
                                ($playerChoice == 'lizard' AND $computerChoice == 'paper') OR
                                ($playerChoice == 'paper' AND $computerChoice == 'spock') OR
                                ($playerChoice == 'rock' AND $computerChoice == 'lizard') OR
                                ($playerChoice == 'lizard' AND $computerChoice == 'spock') OR
                                ($playerChoice == 'spock' AND $computerChoice == 'scissors')
                            ) {
                                $result = "You Win!";
                                $_SESSION['playerScore']++;
                            } else {
                                $result = "Computer Wins!";
                                $_SESSION['computerScore']++;
                            }

                            // General outputs
                            echo "<div class='output-container'>
                                    <div class='card2'>
                                        <p>You</p><img class='icon' src='{$choices[$playerChoice]}'>
                                    </div>
                                    <div class='card2'>
                                        <p>Computer</p><img class='icon' src='{$choices[$computerChoice]}'>
                                    </div>
                                 </div>
                                 <p class='result' style='color: var(--denim);'>$result</p>
                                 <div class='score-container'>
                                    <div class='score-item'>
                                        <p>Player Score: {$_SESSION['playerScore']}</p>
                                        <p>Computer Score: {$_SESSION['computerScore']}</p>
                                    </div>
                                 </div>
                                 ";

                            // Condition to end game
                            if ($_SESSION['playerScore'] >= 4 OR $_SESSION['computerScore'] >= 4) {
                                if ($_SESSION['playerScore'] > $_SESSION['computerScore']) {
                                    echo "<p>You Won the Game!</p>";
                                } else {
                                    echo "<p>Computer Won the Game!</p>";
                                }

                                echo "<h3>Play Again!</h3>";

                                // Reset the game-specific session variables
                                $_SESSION['playerScore'] = 0;
                                $_SESSION['computerScore'] = 0;
                            }
                        } else {
                            echo $errorMessage;
                        }
                    }
                ?>
            </div>
        </div>
    </div>

	<!-- end main content -->
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
