<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Train Filling - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Train Filling - FPT">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Train Filling - FPT"; ?>

	<style>
		body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        img {
            height: 50%;
            width: 100%;
            border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .card2 {
            position: relative;
            width: 70%;
            height: 250px;
            padding: 5%;
            background: var(--navy);
            border-radius: 0.5em;
            display: inline-flex;
            box-sizing: border-box;
            align-items: center;
            justify-content: center;
            align-content: center;
            justify-items: center;
            flex-direction: column;
            margin: 2%;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
            margin: auto 0;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 250px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 300px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        /* Input box styling */
        select.frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 50px;
            width: 250px;
            text-align: center;
        }   

        select.frmInput:hover,
        select.frmInput:focus-visible {
            height: 45px;
            width: 300px;
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
        }

        select.frmInput:active {
            background: var(--denim);
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail and regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
    <h2>Introduction</h2>
    <div class="grid">
        <div class="col-span-3">
            <br />
            <br />
            <br />
            <br />
            <br />
            <img class="img" src="https://merriam-webster.com/assets/mw/images/article/art-wap-landing-mp-lg/train-3448-72edc8c66df509608c1e13f712a1436e@1x.jpg">
            <br />
        </div>
        <div class="col-span-6">
            <div class="card">
                <p>This performance task regards a problem with train cars and its passengers. There are an infinite number of trains (3 types with a maximum capacity depending on the station you choose) that can arrive at a station. The user must input how many passengers are on the platform, waiting to board, and a train station. Once the first train is filled (or partially filled) if there are people left, another random train must come get them. This takes an extra 2 minutes. Each passenger takes 2 seconds to board the train and each person takes 1% longer to board. The task is to calculate the total number of trains required and the total time to load the trains.</p>
            </div>
        </div>
        <div class="col-span-3">
            <br />
            <br />
            <br />
            <br />
            <br />
            <img class="img" src="https://www.on-sitemag.com/wp-content/uploads/2019/05/Canada_Infrastructure_Bank_Canada_Infrastructure_Bank_Announces.jpg">
            <br />
        </div>
    </div>
    <br />

    <h2>Train Filling Problem</h2>
    <br />
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h2>Select</h2>
                <form name="functionsUserInput" action="perftasktrain.php" method="post">
                    <h3>Number of Passengers</h3>
                    <input type="number" name="num" class="frmInput"></input>
                    <br />
                    <br />
                    <h3>Station</h3>
                    <select name="station" class="frmInput">
                        <option value="Grand Central Terminal, New York">Grand Central Terminal, New York</option>
                        <option value="Gare du Nord, Paris">Gare du Nord, Paris</option>
                        <option value="St Pancras, London">St Pancras, London</option>
                        <option value="Berlin Hauptbahnhof, Berlin">Berlin Hauptbahnhof, Berlin</option>
                        <option value="Victoria Terminus, Mumbai">Victoria Terminus, Mumbai</option>
                    </select>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <br />
                </form>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <?php
                    if ($_POST['subButton']) {

                        // Set variables
                        $passengers = $_POST['num'];
                        $selectedStation = $_POST['station'];

                        // Set error statements
                        $error = "false";
                        $errorMessage = "";

                        if ($passengers == "" OR $selectedStation == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must fill out the boxes.</h3>";
                        }

                        // Set array to store train stations and its train capacities
                        $trainStations = array(
                            ["name" => "Grand Central Terminal, New York", "capacities" => [10, 20, 30]],
                            ["name" => "Gare du Nord, Paris", "capacities" => [15, 30, 45]],
                            ["name" => "St Pancras, London", "capacities" => [12, 24, 36]],
                            ["name" => "Berlin Hauptbahnhof, Berlin", "capacities" => [18, 36, 54]],
                            ["name" => "Victoria Terminus, Mumbai", "capacities" => [25, 50, 75]],
                        );

                        // Find the selected station in the train stations array
                        $selectedStationInfo = false;
                        foreach ($trainStations as $station) {
                            if ($station["name"] == $selectedStation) {
                                $selectedStationInfo = $station;
                                break;
                            }
                        }

                        // Set variables to track the total number of trains, total time, and the previous boarding time
                        $totalTrains = 0;
                        $totalTime = 0;
                        $previousBoardingTime = 0;

                        if ($error == "false") {

                            // Echo initial statements
                            echo "
                                <h2>" . $selectedStationInfo['name'] . "</h2>
                                <h3>Total Passengers: $passengers</h3>
                            ";

                            // Loop until all passengers are boarded
                            while ($passengers > 0) {
                                $capacities = $selectedStationInfo["capacities"];
                                $trainCapacity = $capacities[rand(0, count($capacities) - 1)];
                                $boardingPassengers = min($passengers, $trainCapacity);
                                $boardingTime = $boardingPassengers * (2 + ($previousBoardingTime * 0.01)); // Increase time by 1% for each new person
                                $previousBoardingTime = $boardingTime;

                                if ($totalTrains == 0) {
                                    $delay = 0; // No delay for the first train
                                } else {
                                    $delay = 120;
                                }

                                $totalTime += $boardingTime + $delay;
                                $passengers -= $boardingPassengers;
                                $totalTrains++;
                                $occupancyPercentage = round(($boardingPassengers / $trainCapacity) * 100);

                                // Convert the time to the format "__:__"
                                $formattedTime = gmdate("i:s", $totalTime);

                                // Output train details
                                echo "
                                    <div class='card2'>
                                        <h3>Train #$totalTrains → Size: $trainCapacity</h3>
                                        <p>Occupancy: $occupancyPercentage% ($boardingPassengers people boarded)</p>
                                        <p>Number Left: $passengers</p>
                                        <p>Total Time: $formattedTime</p>
                                        </ br>
                                    </div>
                                ";
                            }

                            // Convert the total time to the format "__:__"
                            $formattedTotalTime = gmdate("i:s", $totalTime);

                            // Output the final results
                            if ($totalTrains == 1) {
                                echo "<br>";
                                echo "<h3>It took $totalTrains train and a total time of $formattedTotalTime.</h3>";
                            } else {
                                echo "<br>";
                            echo "<h3>It took $totalTrains trains and a total time of $formattedTotalTime.</h3>";
                            }
                        } else {
                            echo $errorMessage;
                        }
                    }
                ?>
            </div>
        </div>
    </div>

	<!-- end main content -->
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
