<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Flowcharts & Algorithms - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Flowcharts & Algorithms - FPT">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Flowcharts & Algorithms - FPT"; ?>

	<style>
		body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        img, iframe {
            height: 65%;
            width: 80%;
            border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
            margin: auto 0;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 250px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 300px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        /* Input box styling */
        select.frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 50px;
            width: 250px;
            text-align: center;
        }   

        select.frmInput:hover,
        select.frmInput:focus-visible {
            height: 45px;
            width: 300px;
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
        }

        select.frmInput:active {
            background: var(--denim);
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail and regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
    <h2>Introduction</h2>
    <div class="grid">
        <div class="col-span-4">
            <div class="card">
                <br />
                <h3>Flowchart</h3>
                <br />
                <img class="img" src="https://icsprogramming.ca/examples/flow-chart-challenge-coding-problem.png">
                <br />
            </div>
        </div>
        <div class="col-span-4">
            <div class="card">
                <br />
                <h3>Task Overview</h3>
                <br />
                <p>Flowchart reasoning and graphical interpretation are integral to computer science. The S-P Flowchart Algorithm demonstrates how flowcharts aid programmers in outlining control flow and decision trees. By inputting a value below, you can see the algorithm in action. Flowcharts visually represent program logic, facilitating understanding of complex processes. The S-P Flowchart Algorithm follows interconnected symbols and shapes, guiding programmers through steps of problem-solving. Decisions based on predefined conditions lead to different outcomes. While various algorithms exist, flowcharts are widely used due to their simplicity and effectiveness. Experience the S-P Flowchart Algorithm by inputting a value and witnessing its power in computer science.</p>
            </div>
        </div>
        <div class="col-span-4">
            <div class="card">
                <br />
                <h3>Video Explanation</h3>
                <br />
                <iframe width="560" height="315" src="https://www.youtube.com/embed/B-QRCRURtPo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <br />
            </div>
        </div>
    </div>
    <br />

    <h2>S-P Flowchart & Algorithm Problem</h2>
    <br />
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h2>Select</h2>
                <form name="calculations" action="s-p-flowchart-algorithm.php" method="post">
                    <input class="frmInput" type="number" name="p" autocomplete="off" value="<?php echo $_POST['p']; ?>"></input>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                </form>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <?php
                    function checkPrime($n) {
                        for ($x = 2; $x <= $n / 2; $x++) {
                            if ($n % $x == 0) {
                                return false;
                            }
                        }
                        return true;
                    }

                    function isEven($n) {
                        return $n % 2 == 0;
                    }

                    function isGreaterThanFive($n) {
                        return $n > 5;
                    }

                    function isZero($n) {
                        return $n == 0;
                    }

                    if ($_POST['subButton']) {
                        $p = $_POST['p'];

                        if ($p < 1) {
                            echo "<h4>Error: The number must be greater than or equal to 1</h4>";
                        } else {
                            $s = 12;
                            $iterations = 0;

                            if (isEven($p)) {
                                $p++;
                            }

                            echo "<table>";
                            echo "<tr><th>P</th><th>S</th></tr>";

                            while (!checkPrime($p)) {
                                echo "<tr><td>$p</td><td>$s</td></tr>";
                                $p += 2;
                                $iterations++;
                            }

                            while ($s > 0) {
                                echo "<tr><td>$p</td><td>$s</td></tr>";

                                if ($p < $s) {
                                    $s -= $p;
                                } else {
                                    $s--;
                                }

                                $iterations++;

                                if (isZero($s)) {
                                    break;
                                }

                                $p += 2;

                                while (!checkPrime($p)) {
                                    echo "<tr><td>$p</td><td>$s</td></tr>";
                                    $p += 2;
                                    $iterations++;
                                }
                            }

                            echo "<tr><td>$p</td><td>$s</td></tr>";
                            echo "</table>";
                            echo "<br />";
                            echo "<h3>It took $iterations iterations to get p's final value of $p.</h3>";
                        }
                    }
                ?>
            </div>
        </div>
    </div>

	<!-- end main content -->
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
