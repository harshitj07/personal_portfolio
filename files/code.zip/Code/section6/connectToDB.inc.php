<?php
	// database configurations
	$db_servername = "localhost";
	$db_username = "icspr265_jain330c2";
	$db_password = "jain330c2_577";
	$db_databasename = "icspr265_jain330c2";

	//************************************************************************
	// Connect to MySQL Database
	//************************************************************************
	$db = new mysqli($db_servername,$db_username,$db_password,$db_databasename);
	if (!$db) {
	   echo "<p>Could not connect to database: " . mysqli_connect_error() . "</p>";
	} else {
		// echo "<p>Successfully connected - comment out this line once it works.</p>";
	}
?>
