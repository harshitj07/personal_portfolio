<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Calculations with PHP - Harshit Jain") ?></title>	

	<meta name="description" content="This page works with calculations using PHP">
	<meta name="author" content="Harshit Jain">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Calculations with PHP"; ?>

	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			/* http://lea.verou.me/css3patterns/ */
			background: var(--midnight); 
			color: var(--snow);
			text-align: left;
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
		}

		.main {
			margin: 20px;
			text-align: center;
		}

		hr {
			width: 35%;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: #333333;
			text-align: center;
			color: var(--snow);
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.submit {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;
		}

		.submit:hover,
		.submit:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.submit:active {
		    background: var(--color);
		    color: #fff;
		}

		/* Input box styling */
		.input {
			border: 3px solid var(--denim);
			border-radius: 5px;
		}	

		.input:hover,
		.input:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: var(--snow);
		}

		.input:active {
		    background: var(--denim);
		    color: var(--snow);
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />

	<div class="main">

		<!-- main content -->

		<!-- Perimeter for Rectangle -->
		<h2 style="color: var(--denim);">Perimeter | Rectangle</h2>
		<form name="calculations" action="activity-2-2.php" method="post">
			<h3>Length</h3>
			<input type="number" name="length" onkeypress="return onlyNumbers(event)" placeholder="0" autocomplete="off" value="" class="input"></input>
			<br />
			<h3>Width</h3>
			<input type="number" name="width" onkeypress="return onlyNumbers(event)" placeholder="0" autocomplete="off" value="" class="input"></input>
			<br />
			<br />
			<input type="submit" value="Calculate" name="submit1" class="submit"></input>
			<br />
		</form>
		<?php
			$numOne1 = $_POST['length'];
			$numTwo1 = $_POST[ 'width'];
			$result1 = (2 * $numOne1) + (2 * $numTwo1);
			if ($_POST['submit1']) {echo "<br />If a rectangle has a length of $numOne1, and a width of $numTwo1, then it has a perimeter of $result1.<br />";}
		?>
		<br />
		<hr />

		<!-- Area of Triangle -->
		<h2 style="color: var(--denim);">Area | Triangle</h2>
		<form name="calculations" action="activity-2-2.php" method="post">
			<h3>Base</h3>
			<input type="number" name="base" autocomplete="off" onkeypress="return onlyNumbers(event)" placeholder="0" value="" class="input"></input>
			<br />
			<h3>Height</h3>
			<input type="number" name="height" autocomplete="off" onkeypress="return onlyNumbers(event)" placeholder="0" value="" class="input"></input>
			<br />
			<br />
			<input type="submit" value="Calculate" name="submit2" class="submit"></input>
			<br />
		</form>
		<?php
			$numOne2 = $_POST['base'];
			$numTwo2 = $_POST[ 'height'];
			$result2 = ($numOne2 * $numTwo2) / 2;
			if ($_POST['submit2']) {echo "<br />If a triangle has a base of $numOne2, and a height of $numTwo2, then it has an area of $result2.<br />";}
		?>
		<br />
		<hr>

		<!-- Speed of Sound -->
		<h2 style="color: var(--denim);">Speed of Sound</h2>
		<form name="calculations" action="activity-2-2.php" method="post">
			<h3>Air Temperature (Celcius)</h3>
				<select name="speed" class="input">
					<option value="-10">-10</option>
					<option value="0">0</option>
					<option value="10">10</option>
					<option value="20">20</option>
					<option value="30">30</option>
				</select>
				<br />
				<br />
				<input type="submit" value="Calculate" name="submit3" class="submit"></input>
				<br />
		</form>
		<?php
			$numOne3 = $_POST['speed'];
			$result3 = ($numOne3 * 0.6) + 332;
			if ($_POST['submit3']) {echo "<br />If the temperature is $numOne3, the speed of sound is $result3.<br />";}
		?>
		<br />
		<hr>

		<h2 style="color: var(--denim);">Magic Number</h2>
		<form name="calculations" action="activity-2-2.php" method="post">
			<form name="calculations" action="calculations-with-php-2-2.php" method="post">
				<h3>Number</h3>
				<input type="number" name="numbermagic" autocomplete="off" onkeypress="return onlyNumbers(event)" placeholder="0" value="" class="input"></input>
				<br />
				<br />
				<input type="submit" value="Calculate" name="submit4" class="submit"></input>
				<br />
		</form>
		<?php
			$numOne4 = $_POST['numbermagic'];
			$result4 = ((($numOne4 + 2) * 3) - 6) * 3;
			if ($_POST['submit4']) {echo "<br />Your magic number is $result4.<br />";}
		?>
		<br />
	</div>
	<!-- end main content -->

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>