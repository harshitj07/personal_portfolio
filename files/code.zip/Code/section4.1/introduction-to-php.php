<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Intro to PHP - Harshit Jain") ?></title>	

	<meta http-equiv="content-type" content="text/html;charset=utf-8" />

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Intro to PHP"; ?>

	<style type="text/css">
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: #333333;  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: left;
		}

		.body {
			margin: 20px;
			color: var(--snow);
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: #333333;
			text-align: left;
			color: var(--snow);
		}

		.fancyInput {
			border: 1px solid #d35400;
			outline: none;
			font-size: 1.5em;
		}

		.fancyInput:hover {
			border: 1px solid #2980b9;
		}	

		.subButton {
			font-size: 1.2em;
			border: 1px solid #d35400;
			padding: 5px;
		}

		.subButton:hover {
			border: 1px solid #2980b9;
			cursor: pointer;
			color: #2980b9;
		}	

		p.output {
			padding: 10px;
			background: var(--snow);
			font-size: 1.2em;
			color: #333333;
			border-radius: 10px;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />

	<div class="body">
		<!-- PHP -->
		<?
			echo "<h2>What is PHP?</h2>
			<p><b>PHP</b> (recursive acronym for <b>P</b>HP: <b>H</b>ypertext <b>P</b>reprocessor) is a widely-used open source general-purpose scripting language that is especially suited for web development and can be embedded into HTML.</p>";
		?>

		<h2>Simple Form Validation with PHP</h2>

		<?
			/* the if statement below makes the code inside of it
			only show up if the button in the form named 'submitBtn' is clicked.
			You can have multiple submit buttons, but they must have different names.*/
			if ($_POST['submitBtn1']) {
				// set the variables...
				$theName = $_POST['theName'];
				$theEmail = $_POST['theEmail'];
				$socksColour = $_POST['socksColour'];
				$hatColour = $_POST['hatColour'];
				$truth = $_POST['truth'];
				
				// print out the message
				echo 
				"<p class='output'>
					The name that was entered into the form was: <b style='background: var(--denim);'>" . $theName . "</b>
					<br /><br />
					The name that was entered into the form was: <b style='background: var(--denim);;'>" . $theName . "</b>
					<br /><br />
					The colour socks chosen was: <b style='background: var(--denim);'>" . $socksColour . "</b>
					<br /><br />
					The colour hat chosen was: <b style='background: var(--denim);'>" . $hatColour . "</b>
					<br /><br />
					The option chosen was: <b style='background: var(--denim);'>" . $truth . "</b>
					<br />
				</p>";
			}
		?>

		<h2>The Form</h2>
		<p>Complete the form below and press submit.  Notice how the values are now output (echoed) to the page based and the <b>variable name</b> assigned in the form.</p>
		<h3>Form Attributes</h3>
		<ul>
			<li> "name" is the unique name of the form</li>
			<li> "get" method shows the variables and values in the address bar of your browser</li>
			<li> "post" method hides the type variables and values - the information is posted to the server</li>
			<li> "action" is the URL that the form will direct to once the submit button is pressed</li>
		</ul>

		<form name="form1" action="introduction-to-php.php" method="post">
			<b>Name:</b><br />
			<input type="text" name="theName" value="" class="fancyInput"></input><br />
			<br />
			<b>Email:</b><br />
			<input type="text" name="theEmail" value="" class="fancyInput"></input><br />
			<br />
			<b>Colour of Socks:</b><br />
			<select name="socksColour" class="fancyInput">
				<option value=""></option>
				<option value="blue">Blue Socks</option>
				<option value="green">Green Socks</option>
				<option value="red">Red Socks</option>
			</select>
			<br />
			<br />
			<b>Colour of Hat:</b><br />
			<select name="hatColour" class="fancyInput">
				<option value=""></option>
				<option value="white">White Hat</option>
				<option value="brown">Brown Hat</option>
				<option value="orange">Orange Hat</option>
			</select>
			<br />
			<br />
			<b>Are you speaking the truth?</b><br />
			<input type="radio" name="truth" value="yes" checked> Yes</input><br />
			<input type="radio" name="truth" value="no"> No</input><br />
			<br />
			<input type="submit" value="SUBMIT" name="submitBtn1" class="subButton"></input>
		</form>
	</div>
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
