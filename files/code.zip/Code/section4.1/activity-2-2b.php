<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Working with Variables: Parsing URLs - Harshit Jain") ?></title>	

	<meta name="description" content="Working with variables">
	<meta name="author" content="Harshit Jain">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Working with Variables: Parsing URLs"; ?>

	<!-- CSS Styling -->
	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: #333333;  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: #333333;
			text-align: center;
			color: var(--snow);
		}

		.body {
			margin: 20px;
			color: snow;
		}

		table, th, td {
			text-align: center;
			color: var(--snow);
			margin: auto;
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.submit {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;
		}

		.submit:hover,
		.submit:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.submit:active {
		    background: var(--color);
		    color: #fff;
		}

		/* Input box styling */
		.input {
			border: 3px solid var(--denim);
			border-radius: 5px;
			margin: 10px;
		}	

		.input:hover,
		.input:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: black;
		}

		.input:active {
		    background: var(--denim);
		    color: black;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>

<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<div class="body">
		<?php
			if ($_GET['subButton']) {
				// Defining variables
				$x = $_GET['x'];
				$y = $_GET['y'];
				$z = $_GET['z'];
				$title = $_GET['title'];
				$border = $_GET['border'];
				$cellpadding = $_GET['cellpadding'];
				$bgdclr = $_GET['bgdclr'];

				// learning to parse variables from URLs
				echo "The value of x is " . $_GET['x'] . ".<br />We are learning how to parse variables from URLs.  The value of x is " . $_GET['x'] . ", the value of y is " . $_GET['y'] . ", the value of z is " . $_GET['z'] . " and the title is " . $_GET['title'] . ".";
			}
		?>
		<!-- Table title -->
		<h2>
			<? echo $_GET['title'] ?>
		</h2>

		<!-- Table -->
		<table cellpadding="<? echo $cellpadding; ?>px" cellspacing="0" border="<? echo $border; ?>px solid #333333" class="table" method="get" style="background: <? echo $bgdclr; ?>;">
			<tr>
				<td><b>Mathematical Operation</b></td>
				<td><b>Result</b></td>
			</tr>
			<tr>
				<td>
					<p>x + y - 2 * z</p>
				</td>
				<td>
					<? $result1 = ($x + $y) - (2 * $z); echo "$result1"; ?>
				</td>
			</tr>
			<tr>
				<td>
					<p>2x - 4y + (3z - 80)</p>
				</td>
				<td>
					<? $result2 = (2 * $x - 4 * $y) + (3 * $z - 80); echo "$result2"; ?>
				</td>
			</tr>
			<tr>
				<td>
					<p>Result of (row2,col2) + Result of (row3,col2)</p>
				</td>
				<td>
					<? $result3 = $result1 + $result2; echo "$result3"; ?>
				</td>
			</tr>
		</table>

		<h3>Inputs:</h3>

		<!-- Form for inputs -->
		<form name="form" method="get">
			X-Value: <input type="text" name="x" value="<? echo "$x"; ?>" class="input"></input><br  />
			Y-Value: <input type="text" name="y" value="<? echo "$y"; ?>" class="input"></input><br  />
			Z-Value: <input type="text" name="z" value="<? echo "$y"; ?>" class="input"></input><br  />
			Title: <input type="text" name="title" value="<? echo "$title"; ?>" class="input"></input><br  />
			Table Border: <input type="text" name="border" value="<? echo "$border"; ?>" class="input"></input><br  />
			Table Padding: <input type="text" name="cellpadding" value="<? echo "$cellpadding"; ?>" class="input"></input><br  />
			Background Colour: <input type="color" name="bgdclr" value="<? echo "$bgdclr"; ?>" class="input"></input><br  />
			<br />
			<input name="subButton" type="submit" value="Show Now!" class="submit"></input>
		</form>
	</div>
	<br />
	<br />
	<!-- end main content -->

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
