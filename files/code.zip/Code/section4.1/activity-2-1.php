<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "PHP Basics: Syntax - Harshit Jain") ?></title>	

	<meta http-equiv="content-type" content="text/html;charset=utf-8" />

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "PHP Basics: Syntax"; ?>

	<style type="text/css">
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: left;
		}

		.main {
			margin: 20px;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />

	<!-- main content -->

	<div class="main">
		<!-- PHP -->
		<?
			// This is my first PHP document.
			echo "<p>This is my first PHP document. The text in this paragraph was displayed using the echo command. This is pretty cool.</p>";
			
			echo "This sentence would not " . " be complete unless I learn how to properly " . " append strings.";
		?>
		<br />
		<br />
	</div>
	<!-- end main content -->

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
