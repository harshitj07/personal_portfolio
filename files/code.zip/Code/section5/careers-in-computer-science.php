<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
    <meta charset="utf-8">

    <!-- Title changes depending on the website -->
    <title><?php echo($siteName . "Careers - Harshit Jain") ?></title>  

    <!-- Description -->
    <meta name="description" content="Careers in Computer Science">
    <meta name="author" content="Harshit Jain">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

    <!-- link to animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <!-- Grid Styles -->
    <link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

    <!-- Navbar title changes depending on the website -->
    <?php $siteName = "Careers in Computer Science"; ?>


    <style>
        body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        img {
            height: 40%;
            width: 40%;
            border-radius: 10px;
        }

        img.inst {
            height: 80%;
            width: 90%;
            border-radius: 10px; 
            margin: 5%;
            opacity: 0.5;
        }

        img.inst:hover {
            height: 80%;
            width: 90%;
            border-radius: 10px; 
            margin: 5%;
            opacity: 1;
            transition-duration: 0.5s;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        iframe {
            border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 2%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
            margin: auto 0;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }

        /*
        W3 Schools Image Slideshow
        Source: https://www.w3schools.com/howto/howto_js_slideshow.asp
        */
        * {box-sizing: border-box}
        .mySlides {display: none}
        img {vertical-align: middle;}

        /* Slideshow container */
        .slideshow-container {
          max-width: 500px;
          position: relative;
          margin: auto;
        }

        /* Next & previous buttons */
        .prev, .next {
          cursor: pointer;
          position: absolute;
          top: 50%;
          width: auto;
          padding: 16px;
          margin-top: -22px;
          color: white;
          font-weight: bold;
          font-size: 18px;
          transition: 0.6s ease;
          border-radius: 0 3px 3px 0;
          user-select: none;
          position: absolute;
        }

        /* Position the "next button" to the right */
        .next {
          right: 0;
          border-radius: 3px 0 0 3px;
        }

        /* Position the "next button" to the right */
        .prev {
          left: 0;
          border-radius: 3px 0 0 3px;
        }

        /* On hover, add a black background color with a little bit see-through */
        .prev:hover, .next:hover {
          background-color: rgba(0,0,0,0.8);
        }

        /* Caption text */
        .text {
          color: #f2f2f2;
          font-size: 15px;
          padding: 8px 12px;
          position: absolute;
          bottom: 8px;
          width: 90%;
          text-align: center;
          background-color: rgba(0,0,0,0.6);
          border-radius: 10px;
          justify-content: center;
          left: 50%;
          transform: translateX(-50%);
        }

        /* Number text (1/3 etc) */
        .numbertext {
          color: #f2f2f2;
          font-size: 12px;
          padding: 8px 12px;
          position: absolute;
          top: 0;
        }

        /* The dots/bullets/indicators */
        .dot {
          cursor: pointer;
          height: 15px;
          width: 15px;
          margin: 0 2px;
          background-color: #bbb;
          border-radius: 50%;
          display: inline-block;
          transition: background-color 0.6s ease;
        }

        .active, .dot:hover {
          background-color: #717171;
        }

        /* Fading animation */
        .fade {
          animation-name: fade;
          animation-duration: 1.5s;
        }

        @keyframes fade {
          from {opacity: .4} 
          to {opacity: 1}
        }

        /* On smaller screens, decrease text size */
        @media only screen and (max-width: 300px) {
          .prev, .next,.text {font-size: 11px}
        }
    </style>
</head>
<body>
    <!-- Navbar Element -->
    <?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
    <br />
    <br />

    <!-- main content -->
    
    <h2>Introduction</h2>
    <br />
    <div class="card" style="max-width: 580px; justify-content: center; margin: 0 auto;">
        <p>Learn about diverse career opportunities in the field of computer science here! Browse through the list to discover different jobs and gain insights into what a typical day in each role might entail. If you're considering a career in computer science, explore the post-secondary institutions listed below to find out about the educational opportunities they offer for aspiring computer scientists.</p>
    </div>
    <br />
    <br />

    <h2>Careers in the Field of Computer Programming</h2>
    <br />
    <div class="slideshow-container">
        <div class="mySlides fade">
          <div class="numbertext">1 / 10</div>
          <img src="https://graduate.northeastern.edu/resources/wp-content/uploads/sites/4/2020/09/how-to-become-a-cloud-engineer.jpg" style="width:100%">
          <div class="text">Cloud Engineer: A cloud engineer is responsible for designing, deploying, and maintaining cloud-based infrastructure and services. They are experts in cloud computing technologies and use their knowledge to develop and implement scalable, reliable, and secure cloud-based solutions.</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">2 / 10</div>
          <img src="https://res.cloudinary.com/grand-canyon-university/image/fetch/w_750,h_564,c_fill,g_faces,q_auto/https://www.gcu.edu/sites/default/files/2020-09/programming.jpg" style="width:100%">
          <div class="text">Computer Programmer: A computer programmer is responsible for writing, testing, and maintaining computer software programs using programming languages like Java, Python, C++, and others. They work closely with software developers to translate designs into functional code.</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">3 / 10</div>
          <img src="https://online.engineering.arizona.edu/wp-content/themes/eng/images/blog/top-skills-software-and-computer-engineering.jpg" style="width:100%">
          <div class="text">Computer Software Engineer: A computer software engineer is responsible for developing, designing, and testing software programs. They use programming languages, tools, and frameworks to create software applications that meet client requirements.</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">4 / 10</div>
          <img src="https://www.simplilearn.com/ice9/free_resources_article_thumb/how_to_become_a_data_scientist.jpg" style="width:100%">
          <div class="text">Data Scientist: A data scientist is responsible for analyzing and interpreting complex data to extract meaningful insights that can be used to inform business decisions. They use statistical and machine learning techniques to create predictive models and data visualizations.</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">5 / 10</div>
          <img src="https://www.simplilearn.com/ice9/free_resources_article_thumb/Database_Administrator_Salary.jpg" style="width:100%">
          <div class="text">Database Administrator: A database administrator is responsible for managing and maintaining databases that store important business data. They are responsible for ensuring data security, backing up data, and ensuring the availability of data when needed.</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">6 / 10</div>
          <img src="https://www.roberthalf.com/sites/default/files/2019-03/machine-learning-fow-rh.jpg" style="width:100%">
          <div class="text">Deep Learning Engineer: A deep learning engineer is responsible for developing and implementing deep learning models that can analyze complex data and make accurate predictions. They use algorithms and techniques such as neural networks to design models that can learn from data and make predictions.</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">7 / 10</div>
          <img src="https://optymize.io/wp-content/uploads/2022/03/Java-Devlopers.png" style="width:100%">
          <div class="text">Java Developer: A Java developer is responsible for designing, developing, and testing Java-based software applications. They work on various platforms and projects, ranging from web applications to mobile applications.</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">8 / 10</div>
          <img src="https://www.simplilearn.com/ice9/free_resources_article_thumb/Skills_Required_to_Become_an_iOS_Developer.jpg" style="width:100%">
          <div class="text">iOS Developer: An iOS developer is responsible for designing, developing, and testing applications for Apple's iOS operating system. They use programming languages such as Swift and Objective-C to create applications that run on iPhones, iPads, and other Apple devices.</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">9 / 10</div>
          <img src="https://www.gqrgm.com/wp-content/uploads/2018/10/How-To-Become-A-Machine-Learning-Engineer.jpg" style="width:100%">
          <div class="text">Machine Learning Engineer: A machine learning engineer is responsible for designing and developing algorithms and models that can learn from data and make predictions. They work on projects such as image recognition, natural language processing, and recommendation systems.</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">10 / 10</div>
          <img src="https://www.jobstreet.com.sg/career-resources/wp-content/uploads/sites/3/2021/03/5-Skills-to-Make-You-a-Better-Mobile-App-Developer-scaled.jpg" style="width:100%">
          <div class="text">Mobile Application Developer: A mobile application developer is responsible for designing, developing, and testing mobile applications for various platforms such as Android and iOS. They use programming languages and tools such as Java, Swift, and React Native to create applications that run on mobile devices.</div>
        </div>

        <a class="prev" onclick="plusSlides(-1)">❮</a>
        <a class="next" onclick="plusSlides(1)">❯</a>
    </div>
    <br>

    <div style="text-align:center">
      <span class="dot" onclick="currentSlide(1)"></span> 
      <span class="dot" onclick="currentSlide(2)"></span> 
      <span class="dot" onclick="currentSlide(3)"></span> 
      <span class="dot" onclick="currentSlide(4)"></span> 
      <span class="dot" onclick="currentSlide(5)"></span> 
      <span class="dot" onclick="currentSlide(6)"></span> 
      <span class="dot" onclick="currentSlide(7"></span> 
      <span class="dot" onclick="currentSlide(8)"></span> 
      <span class="dot" onclick="currentSlide(9)"></span> 
      <span class="dot" onclick="currentSlide(10)"></span> 
    </div>

    <script>
        let slideIndex = 1;
        showSlides(slideIndex);

        function plusSlides(n) {
            showSlides(slideIndex += n);
        }

        function currentSlide(n) {
            showSlides(slideIndex = n);
        }

        function showSlides(n) {
            let i;
            let slides = document.getElementsByClassName("mySlides");
            let dots = document.getElementsByClassName("dot");
            if (n > slides.length) {
                slideIndex = 1
            }    
            if (n < 1) {
                slideIndex = slides.length
            }
            
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";  
            }
          
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
          
            slides[slideIndex-1].style.display = "block";  
            dots[slideIndex-1].className += " active";
        }
    </script>

    <br />
    <h2>My High School Plan</h2>
    <br />
    <img src="../images/courses.png">
    <br />
    <br />
    <div class="card" style="max-width: 580px; justify-content: center; margin: 0 auto;">
        <p>Taking a look at my courses at the moment, I am on track to enter the field of engineering and technology and pursue a variety of different paths. Some include, computer science, aerospace engineering, and architectural engineering. Along with that, there are additional programs such as accounting, applied mathematics, and art history that I am compatible with. I think that acheiving good grades and having lots of extra-curricular experience will ensure my placement in a fine insititution such as the University of Toronto or University of Waterloo.</p>
    </div>
    <br />

    <br />
    <h2>Computer Programming Programs</h2>
    <br />
    <div class="grid">
        <div class="col-span-3">
            <div class="card">
                <a href="https://uwaterloo.ca/future-students/programs/computer-science"><img class="inst" src="https://uwaterloo.ca/brand/sites/ca.brand/files/universityofwaterloo_logo_horiz_rev_rgb.png"></a>
            </div>
        </div>
        <div class="col-span-3">
            <div class="card">
                <a href="https://future.utoronto.ca/undergraduate-programs/computer-science/"><img class="inst" src="https://download.logo.wine/logo/University_of_Toronto/University_of_Toronto-Logo.wine.png"></a>
            </div>
        </div>
        <div class="col-span-3">
            <div class="card">
                <a href="https://www.mohawkcollege.ca/program-theme/technology/computer-science"><img class="inst" src="https://www.mohawkcollege.ca/sites/default/files/Marketing%20and%20Communications/Logos/mohawkCollegeLogo-Print-Horizontalcolour-1260x250.png"></a>
            </div>
        </div>
        <div class="col-span-3">
            <div class="card">
                <a href="https://www.senecacollege.ca/programs/fulltime/CPP.html"><img class="inst" src="https://storage-prtl-co.imgix.net/endor/organisations/17640/logos/1523366891_banner.png"></a>
            </div>
        </div>
    </div>

    <br />
    <h2>Works Cited</h2>
    <br />
    <p>“Top 15 Careers in Programming (with Salaries and Job Duties).” Indeed, 3 May 2023, ca.indeed.com/career-advice/finding-a-job/career-in-programming.</p>
    <br />
    <p>“Computer Science.” Undergraduate Programs, 22 July 2022, uwaterloo.ca/future-students/programs/computer-science.</p>
    <br />
    <p>“Computer Science.” Future Students. University of Toronto, 5 May 2023, future.utoronto.ca/undergraduate-programs/computer-science/.</p>
    <br />
    <p>“Computer Science.” Mohawk College, www.mohawkcollege.ca/program-theme/technology/computer-science. Accessed 9 May 2023.</p>
    <br />
    <p>Computer Programming - Seneca, Toronto, Canada, www.senecacollege.ca/programs/fulltime/CPP.html. Accessed 9 May 2023.</p>
    <br />
    <p>“MyBlueprint.Ca.” myBlueprint.Ca, myblueprint.ca/. Accessed 9 May 2023.</p>

    <!-- end main content -->
    <br />
    <br />

    <!-- footer -->
    <footer>
        <p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
    </footer>

    <!-- turn work in widget -->
    <?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
