<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
    <meta charset="utf-8">

    <!-- Title changes depending on the website -->
    <title><?php echo($siteName . "Trends - Harshit Jain") ?></title>  

    <!-- Description -->
    <meta name="description" content="Trends in Computer Science">
    <meta name="author" content="Harshit Jain">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

    <!-- link to animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <!-- Grid Styles -->
    <link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

    <!-- Navbar title changes depending on the website -->
    <?php $siteName = "Trends in Computer Science"; ?>


    <style>
        body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        img {
            height: 40%;
            width: 40%;
            border-radius: 10px;
        }

        img.inst {
            height: 80%;
            width: 90%;
            border-radius: 10px; 
            margin: 5%;
            opacity: 0.5;
        }

        img.inst:hover {
            height: 80%;
            width: 90%;
            border-radius: 10px; 
            margin: 5%;
            opacity: 1;
            transition-duration: 0.5s;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        iframe {
            border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 2%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .cards {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
            margin: auto 0;
        }

        .citations {
            margin-left: 10%;
            margin-right: 10%;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
    </style>
</head>
<body>
    <!-- Navbar Element -->
    <?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
    <br />
    <br />

    <!-- main content -->
    
    <h2>Introduction</h2>
    <br />
    <div class="card" style="max-width: 580px; justify-content: center; margin: 0 auto;">
        <p>Learn about various career trends in the field of computer science here! Browse through the list to discover different trends and gain insights into what the future has to offer in the field of technology. If you want to learn more, you can view the links and videos provided.</p>
    </div>
    <br />
    <br />

    <h2>Trends in the Field of Computer Programming</h2>
    <br />
    <div class="grid">
        <div class="col-span-3">
            <div class="cards">
                <br />
                <img src="https://www.vietnam-briefing.com/news/wp-content/uploads/2023/05/cybersecurity-vietnam.jpg" style="width:100%">
                <br />
                <h3><b>Cybersecurity</b></h3> 
                <p>Cybersecurity is the practice of protecting computer systems, networks, and data from unauthorized access, damage, or theft. As technology advances and our reliance on digital systems grows, cybersecurity becomes increasingly crucial to safeguard sensitive information, maintain privacy, and ensure the smooth functioning of organizations and individuals in the face of evolving cyber threats.</p> 
                <br />
                <a class="link" href="https://www.ibm.com/topics/cybersecurity">Learn More</a>
                <br />
            </div>
        </div>
        <div class="col-span-3">
            <div class="cards">
                <br />
                <img src="https://www.chitkara.edu.in/blogs/wp-content/uploads/2022/05/artificial-intellegence.jpg" style="width:100%">
                <br />
                <h3><b>Artificial Intelligence</b></h3> 
                <p>Artificial intelligence (AI) is the simulation of human intelligence in machines. Its future importance lies in revolutionizing industries by improving efficiency, automation, and innovation, enabling personalized experiences, addressing global challenges, and analyzing vast amounts of data for predictions and adaptability.</p>
                <br />
                <a class="link" href="https://www.investopedia.com/terms/a/artificial-intelligence-ai.asp">Learn More</a>
                <br />
            </div>
        </div>
        <div class="col-span-3">
            <div class="cards">
                <br />
                <img src="https://media.wired.com/photos/5cdef92d38916b321aa0c474/master/w_2560%2Cc_limit/Facebook-Robots-00.jpg" style="width:100%">
                <br />
                <h3><b>Robotics</b></h3> 
                <p>Robotics is the development of intelligent machines that can perform tasks autonomously or collaboratively with humans. Its future importance lies in revolutionizing industries by increasing efficiency, precision, and productivity, automating tasks, enhancing human capabilities, and addressing complex challenges in sectors such as manufacturing, healthcare, and transportation.</p> 
                <br />
                <a class="link" href="https://builtin.com/robotics">Learn More</a>
                <br />
            </div>
        </div>
        <div class="col-span-3">
            <div class="cards">
                <img src="https://media.wired.co.uk/photos/606da2e35b10d6006e4b21a2/1:1/w_2000,h_2000,c_limit/quantum-computing-hero.jpg" style="width:100%">
                <br />
                <h3><b>Quantum Computing</b></h3> 
                <p>Quantum computing leverages quantum mechanics to revolutionize problem-solving, cryptography, and scientific research by processing data and solving complex calculations at unprecedented speeds. Its potential to tackle intractable challenges will lead to transformative breakthroughs in various areas, shaping our future.</p> 
                <br />
                <a class="link" href="https://www.investopedia.com/terms/q/quantum-computing.asp">Learn More</a>
                <br />
            </div>
        </div>
    </div>
    <br />
    <br />

    <h2>Companies in the Field of Trends</h2>
    <br />
    <div class="grid">
        <div class="col-span-3">
            <div class="cards">
                <br />
                <h3><b>Cybersecurity</b></h3> 
                <p>Companies such as Symantec and Palo Alto Networks are working in this field and offering a variety of different solutions and products.</p>
                <br />
            </div>
        </div>
        <div class="col-span-3">
            <div class="cards">
                <br />
                <h3><b>Artificial Intelligence</b></h3> 
                <p>Companies such as Google and Amazon are extensively using AI and are trying to better its impact on the world. Google uses it for things such as language processing and Amazon uses it to power numerous aspects of its business.</p>
                <br />
            </div>
        </div>
        <div class="col-span-3">
            <div class="cards">
                <br />
                <h3><b>Robotics</b></h3> 
                <p>Companies such as Boston Dynamics and Tesla are currently using robotics for their work. Boston Dynamics is developing robots while Tesla is known for incorporating robotics within their vehicle manufacturing process.</p>
                <br />
            </div>
        </div>
        <div class="col-span-3">
            <div class="cards">
                <br />
                <h3><b>Quantum Computing</b></h3>     
                <p>Companies such as IBM and Google are utilizing quantum computers! IBM has developed a quantum computer called IBM Quantum while Google has created their very own called Sycamore.</p>
                <br />
            </div>
        </div>
    </div>
    <br />
    <br />

    <h2>Useful Videos Regarding Computer Science Trends</h2>
    <br />
    <div class="grid">
        <div class="col-span-3">
            <div class="">
                <br />
                    <iframe width="250" height="180" src="https://www.youtube.com/embed/uAHFNuDlcRw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <br />
            </div>
        </div>
        <div class="col-span-3">
            <div class="">
                <br />
                    <iframe width="250" height="180" src="https://www.youtube.com/embed/MlKLOMwC6DA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <br />
            </div>
        </div>
        <div class="col-span-3">
            <div class="">
                <br />
                    <iframe width="250" height="180" src="https://www.youtube.com/embed/yuXk0p00hJk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <br />
            </div>
        </div>
        <div class="col-span-3">
            <div class="">
                <br />
                    <iframe width="250" height="180" src="https://www.youtube.com/embed/LEslWkeY1tk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <br />
            </div>
        </div>
    </div>
    <br />
    <br />

    <div class="citations">
        <h2>Works Cited</h2>
        <br />
        <p>Team, Great Learning. “Latest Technologies in Computer Science in 2022.” Great Learning Blog: Free Resources What Matters to Shape Your Career!, 20 Oct. 2022, www.mygreatlearning.com/blog/latest-technologies-in-computer-science/.</p>
        <br />
        <p>“Computer Science Trends.” Code a New Career | ComputerScience.Org, 12 Sept. 2022, www.computerscience.org/resources/computer-science-trends/#:~:text=Frequently Asked Questions About Trends in Computer Science&amp;text=The latest computer science trends,developments in robotics and cybersecurity.</p>
        <br />
        <p>“What Is Cybersecurity?” IBM, www.ibm.com/topics/cybersecurity. Accessed 10 May 2023.</p>
        <br />
        <p>Frankenfield, Jake. “Artificial Intelligence: What It Is and How It Is Used.” Investopedia, 1 May 2023, www.investopedia.com/terms/a/artificial-intelligence-ai.asp.</p>
        <br />
        <p>“Robotics.” BuiltIn, builtin.com/robotics. Accessed 10 May 2023.</p>
        <br />
        <p>Frankenfield, Jake. “Quantum Computing: Definition, How It’s Used, and Example.” Investopedia, 6 Apr. 2023, www.investopedia.com/terms/q/quantum-computing.asp.</p>
        <br />
        <p>“5 of the Best Cyber Security Companies to Work For.” University of San Diego Online Degrees, 18 Apr. 2023, onlinedegrees.sandiego.edu/5-best-cyber-security-companies/.</p>
        <br />
        <p>Shread, Paul. “Top 20 Cybersecurity Companies You Need to Know [2023].” eSecurityPlanet, 8 May 2023, www.esecurityplanet.com/products/top-cybersecurity-companies/.</p>
        <br />
        <p>Bowman, Jeremy. “5 Best AI Stocks for 2023: Artificial Intelligence Investing.” The Motley Fool, www.fool.com/investing/stock-market/market-sectors/information-technology/ai-stocks/. Accessed 10 May 2023.</p>
        <br />
        <p>Artificial Intelligence Stocks: The 10 Best AI Companies, money.usnews.com/investing/stock-market-news/slideshows/artificial-intelligence-stocks-the-10-best-ai-companies. Accessed 10 May 2023.</p>
        <br />
        <p>“Tesla as the World’s Biggest Robot Company.” Supply Chain Today - Training, Research and News., 11 July 2022, www.supplychaintoday.com/tesla-as-the-worlds-biggest-robot-company/.</p>
        <br />
        <p>Wolfel, Emily. “Boston Dynamics: The Company Making Earth’s Most Terrifying Robots.” History, 6 Dec. 2022, history-computer.com/boston-dynamics-guide/.</p>
        <br />
        <p>Cheguri, Preethi. “Top 10 Quantum Computing Companies to Watch out for in 2023.” Analytics Insight, 27 Jan. 2023, www.analyticsinsight.net/top-10-quantum-computing-companies-to-watch-out-for-in-2023/#:~:text=Some of the main businesses,Computing%2C and Cambridge Quantum Computing.</p>
    </div>

    <!-- end main content -->
    <br />
    <br />

    <!-- footer -->
    <footer>
        <p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
    </footer>

    <!-- turn work in widget -->
    <?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
