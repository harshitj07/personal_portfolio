<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.7a - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.7a">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.7a - Train Array"; ?>


	<style>
		body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        img {
            height: 50%;
            width: 50%;
            border-radius: 10px;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        iframe {
        	border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 150px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

    <!-- main content -->
    <h2>Introduction</h2>
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h3>Overview</h3>
                <br />
                <p>In this activity, the PHP script utilizes arrays to represent train cars, each containing an object. The script will output the object found in a specific train car or all 8 objects along with the train numbers if the user selects the "show all" option. An additional feature is the random selection of one of the eight train cars.</p>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <h3>Train Cars</h3>
                <br />
                <img class="formula" src="../images/trainimg.png">
            </div>
        </div>
    </div>
    <br />

    <h2>Train Array Program</h2>
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h2>Fill in the Following</h2>
                <form name="functionsUserInput" action="activity-2-7-arrays-a.php" method="post"> 
                    <h3>Train Car Number</h3>
                    <input type="number" name="car" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <input type="submit" value="Randomize" name="randButton" class="submit"></input>
                    <input type="submit" value="Show All" name="showButton" class="submit"></input>
                    <br />
                </form>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <?php

                    // Define Variable
                    $car = $_POST['car'];

                    // Incorporating Arrays
                    $trainCar = array("Train Car 0", "Train Car 1", "Train Car 2", "Train Car 3", "Train Car 4", "Train Car 5", "Train Car 6", "Train Car 7");
                    
                    $trainCarContent = array("Bedsheets", "Assorted Dice", "Colourful Paintbrushes", "Crisp New Books", "Old Shoes", "Volcanic Ash", "Unreleased iPhones", "Brand-New Microscopes");

                    $imageUrls = array(
                    
                        // Bedsheets
                        "https://www.thespruce.com/thmb/56pvtccQolhO9OCWa2JeDMXGr-Q=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/GettyImages-1216412654-bbf8bb2e38a74b24b33a636fb9f3fd8d.jpg",

                        // Assorted Dice
                        "https://q5r8i2t3.rocketcdn.me/wp-content/uploads/2021/02/Assorted-Dice-by-Koplow.jpeg",
                        
                        // Colourful Paintbrushes
                        "https://previews.123rf.com/images/delcreations/delcreations1509/delcreations150900004/44555282-used-paint-brushes-on-a-colorful-painter-palette.jpg",

                        // Crisp New Books
                        "https://s2982.pcdn.co/wp-content/uploads/2020/11/person-holding-a-stack-of-books.jpg.optimal.jpg",

                        // Old Shoes
                        "https://everydayrecycler.com/wp-content/uploads/2020/09/Old-Shoes.jpg",
                        
                        // Volcanic Ash
                        "https://www.techexplorist.com/wp-content/uploads/2021/03/volcano.jpg",

                        // Unreleased iPhones
                        "https://images.macrumors.com/article-new/2023/02/iPhone-15-Cyan-and-Magenta-Feature-2.jpg",
                        
                        // Brand-New Microscopes
                        "https://m.media-amazon.com/images/I/61anJsWC0TL._AC_SL1200_.jpg"
                    );

                    // Error Statements
                    $error = "false";

                    // Checks if the number is greater than or equal to 0
                    if ($car < "0" OR $car > "7") {
                        $error = "true";
                        $errorMessage = "<h3>Error: You must enter a number between 0 and 7.</h3>";
                    }

                    // Output Messages

                    // Checks if submit button is clicked
                    if($_POST['subButton']){
                        if ($error == "false") {
                            $car = $_POST['car'];
                            $content = $trainCarContent[$car];
                            $imageUrl = $imageUrls[$car];
                            echo "<h3>Object in Train Car " . $car . ": " . $content . "</h3><br />";
                            echo "<img src='" . $imageUrl . "' alt='" . $content . "'>";
                        } else {
                            echo $errorMessage; 
                        }  
                    }

                    // Checks if random button is clicked
                    else if($_POST['randButton']){
                        $randomCarNumber = rand(0, 7);
                        $content = $trainCarContent[$randomCarNumber];
                        $imageUrl = $imageUrls[$randomCarNumber];
                        echo "<h3>Object in Train Car " . $randomCarNumber . ": " . $content . "</h3><br />";
                        echo "<img src='" . $imageUrl . "' alt='" . $content . "'>";
                    } 

                    // Checks if show all button is clicked
                    else if($_POST['showButton']){
                        for ($i = 0; $i < count($trainCar); $i++) {
                            echo "<p>" . $trainCar[$i] . ": " . $trainCarContent[$i] . "</p>";
                        }
                    }
                ?>
            </div>
        </div>
    </div>

	<!-- end main content -->
	<br />
	<br />

    <!-- footer -->
    <footer>
        <p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
    </footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
