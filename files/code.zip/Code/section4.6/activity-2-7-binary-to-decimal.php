<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.7c - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.7c">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.7c - Binary to Decimal"; ?>


	<style>
		body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        img {
            height: 70%;
            width: 80%;
            border-radius: 10px;
        }
        
        img.planet {
            height: 100px;
            width: 100px;
            border-radius: 10px;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        iframe {
        	border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

    <!-- main content -->
    <h2>Introduction</h2>
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h3>Overview</h3>
                <br />
                <p>This activity focuses on understanding the number systems used in computing, specifically the binary and hexadecimal number systems. The program uses PHP's str_split() function to break apart a binary-encoded number and convert it to decimal using a loop. Binary is a base-2 system, represented by 1s and 0s, while decimal is a base-10 system. The program is further extended to convert the binary number into a hexadecimal code, which is a base-16 system that uses digits 0-9 and letters A-F to represent numbers.</p>
                <p>Read more here: <a class="link" href="https://www.techtarget.com/whatis/definition/binary">techtarget.com</a></p>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <h3>Video</h3>
                <br />
                <iframe width="350" height="200" src="https://www.youtube.com/embed/LpuPe81bc2w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
        </div>
    </div>
    <br />

    <h2>Coversion Program</h2>
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h2>Fill in the Following</h2>
                <form name="functionsUserInput" action="activity-2-7-binary-to-decimal.php" method="post"> 
                    <h3>Binary Number</h3>
                    <input type="number" name="binary" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <br />
                    <input type="submit" value="Convert" name="convButton" class="submit"></input>
                    <br />
                </form>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <?php
                    // Checks if submit button is clicked
                    if (isset($_POST['convButton'])) {
                        // Define Variables
                        $binary = $_POST['binary'];
                        $decimal = "";
                    
                        $error = "false";

                        // Error checking

                        // Checks if the input is empty
                        if ($binary == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: Please enter a binary number to convert.</h3>";
                        }

                        // Checks if the binary number entered is valid
                        if (!preg_match("/^[01]+$/", $binary)) {
                            $error = "true";
                            $errorMessage = "<h3>Error: Invalid binary number entered.</h3>";
                        } 

                        // Runs if there is no error
                        if ($error == "false") {
                            // Split binary number into an array of individual digits
                            $binaryArray = str_split($binary);

                            // Loop through the binary array and calculate decimal value
                            $binaryArray = array_reverse($binaryArray);
                            $calculation = "";

                            for ($i = 0; $i < sizeof($binaryArray); $i++) {
                                $calculation .= "$binaryArray[$i] x 2<sup>$i</sup> + ";
                                $decimal += $binaryArray[$i] * pow(2, $i);
                            }

                            $calculation = substr($calculation, 0, -3);

                            echo "<h3>The decimal equivalent of $binary is $decimal.</h3>";
                            echo "<p>$calculation = $decimal</p><br />";

                            echo "<hr style='width: 300px;'><br />";

                            // Convert decimal to hexadecimal code
                            $hex = strtoupper(dechex($decimal));
                            echo "<h3>The hexadecimal equivalent of $binary is $hex.</h3>";
                            echo "<p>This value has been obtained through the use of a PHP Function.</p>";
                        } else {
                            echo $errorMessage;
                        }
                    }
                ?>
            </div>
        </div>
    </div>

	<!-- end main content -->
	<br />
	<br />

    <!-- footer -->
    <footer>
        <p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
    </footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
