<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.7d - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.7d">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.7d - Superheros"; ?>


	<style>
		body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        img {
            height: 70%;
            width: 70%;
            border-radius: 10px;
        }

        img.img {
            height: 300px;
            width: 500px;
            border-radius: 10px;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        iframe {
        	border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .card2 {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: #4c71c7;
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
            border: 5px solid #354f8c;
        }

        .card3 {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: #d13b3b;
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
            border: 5px solid #992b2b;
        }

        .card4 {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: #e6dd39;
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
            border: 5px solid #aba42b;
        }

        .card5 {
            width: 270px;
            height: 50px; 
            padding: 2%; 
            margin: 2%;
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
            margin: auto 0;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

    <!-- main content -->
    <h2>Introduction</h2>
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h3>Overview</h3>
                <br />
                <p>This activity centers on the use of multidimensional arrays and their functionality. The activity features characters from the Marvel and DC universe engaged in an epic battle, providing an engaging and interactive way to understand the use of multidimensional arrays in practical programming scenarios. Try out the program!</p>
                <p>Read more about superheroes here: <a class="link" href="https://www.gamesradar.com/whats-the-difference-between-marvel-and-dc/">gamesradar.com</a></p>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <img class="img" src="https://www.comicbasics.com/wp-content/uploads/2020/08/The-Top-10-Greatest-Superheroes-Without-Superpowers-In-Comics-Today.jpg">
            </div>
        </div>
    </div>
    <br />

    <h2>Let's Battle!</h2>
    <form name="functionsUserInput" action="activity-2-7-super-heros.php" method="post"> 
        <input type="submit" value="Battle" name="subButton" class="submit"></input>
    </form>
    <br />
    <?php
        // Checks if submit button is clicked
        if (isset($_POST['subButton'])) {

            // Dimensional Associative Array 
            $team1 = array(
                "Superman" => array( 
                    "name" => "Superman",
                    "image" => "https://www.freeiconspng.com/thumbs/superman-png/superman-png-11.png", 
                    "skill" => 80,
                    "intelligence" => 80, 
                    "strength" => 100, 
                ),       

                "Batman" => array(    
                    "name" => "Batman", 
                    "image" => "https://www.freeiconspng.com/thumbs/batman-png/batman-png-32.png", 
                    "skill" => 90, 
                    "intelligence" => 100, 
                    "strength" => 70, 
                ),

                "Wonder Woman" => array(    
                    "name" => "Wonder Woman",
                    "image" => "https://pngimg.com/d/wonder_woman_PNG5.png", 
                    "skill" => 90, 
                    "intelligence" => 85, 
                    "strength" => 100, 
                ),

                "The Flash" => array(    
                    "name" => "The Flash",
                    "image" => "https://cdn.shopify.com/s/files/1/0696/2849/4111/files/s8_the_flash___transparent__by_speedcam_det283a_480x480.png", 
                    "skill" => 100, 
                    "intelligence" => 100, 
                    "strength" => 100, 
                ),

                "Green Arrow" => array(    
                    "name" => "Green Arrow",
                    "image" => "https://i.pinimg.com/originals/6d/92/43/6d92430cd991e9a8b21d994bb17ad97b.png", 
                    "skill" => 95, 
                    "intelligence" => 85, 
                    "strength" => 85, 
                ),

                "Green Lantern" => array(    
                    "name" => "Green Lantern",
                    "image" => "https://www.pngmart.com/files/22/Green-Lantern-PNG.png", 
                    "skill" => 100, 
                    "intelligence" => 90, 
                    "strength" => 75, 
                )
            );

            $team2 = array(
                "Iron Man" => array(
                    "name" => "Iron Man",
                    "image" => "https://www.pngplay.com/wp-content/uploads/9/Iron-Man-Transparent-PNG.png",
                    "skill" => 90,
                    "intelligence" => 100,
                    "strength" => 75,
                ),

                "Captain America" => array(
                    "name" => "Captain America",
                    "image" => "https://pngimg.com/uploads/captain_america/captain_america_PNG35.png",
                    "skill" => 90,
                    "intelligence" => 90,
                    "strength" => 100,
                ),

                "Hulk" => array(
                    "name" => "The Hulk",
                    "image" => "https://www.pngarts.com/files/2/Animated-Hulk-PNG-Transparent-Image.png",
                    "skill" => 80,
                    "intelligence" => 75,
                    "strength" => 100,
                ),

                "Thor" => array(
                    "name" => "Thor",
                    "image" => "https://i.pinimg.com/originals/43/31/28/43312819a5838b9ec92e88f2211d0c3d.png",
                    "skill" => 85,
                    "intelligence" => 85,
                    "strength" => 100,
                ),

                "Doctor Strange" => array(
                    "name" => "Doctor Strange",
                    "image" => "https://www.pngarts.com/files/11/Marvel-Doctor-Strange-PNG-Photo.png",
                    "skill" => 95,
                    "intelligence" => 90,
                    "strength" => 70,
                ),

                "Spiderman" => array(
                    "name" => "Spiderman",
                    "image" => "https://www.pngarts.com/files/3/Spider-Man-Cartoon-Transparent-Background-PNG.png",
                    "skill" => 100,
                    "intelligence" => 100,
                    "strength" => 100,
                )
            );

            // Randomly select a superhero from team 1 and team 2
            $selected1 = array_rand($team1);
            $selected2 = array_rand($team2);

            // Get the names of the selected heroes
            $selectedName1 = $team1[$selected1]["name"];
            $selectedName2 = $team2[$selected2]["name"];

            // Team 1
            echo "<div class='grid'>";
            foreach ($team1 as $hero) {
                echo "<div class='col-span-2'>";
                if ($selectedName1 == $hero["name"]) {
                    echo "<div class='card4'>";
                } else {
                    echo "<div class='card2'>";
                }
                echo "<img src='" . $hero["image"] . "' alt='" . $hero["name"] . "'>";
                echo "<h3 style='color: var(--snow);'>" . $hero["name"] . "</h3>";
                echo "</div>";
                echo "</div>";
            }
            echo "</div>";

            echo "<h1 style='color: var(--snow);'>VS</h1>";

            // Team 2
            echo "<div class='grid'>";
            foreach ($team2 as $hero) {
                echo "<div class='col-span-2'>";
                if ($selectedName2 == $hero["name"]) {
                    echo "<div class='card4'>";
                } else {
                    echo "<div class='card3'>";
                }
                echo "<img src='" . $hero["image"] . "' alt='" . $hero["name"] . "'>";
                echo "<h3 style='color: var(--snow);'>" . $hero["name"] . "</h3>";
                echo "</div>";
                echo "</div>";
            }
            echo "</div>";

            // Display final message
            echo "<div class='card5'>";
                // Determine the winner based on skill, intelligence, and strength
                $team1Score = $team1[$selected1]["skill"] + $team1[$selected1]["intelligence"] + $team1[$selected1]["strength"];
                $team2Score = $team2[$selected2]["skill"] + $team2[$selected2]["intelligence"] + $team2[$selected2]["strength"];

                echo "<br /><br /><h3 style='color: var(--snow)'>DC's Power: " . " $team1Score " . "   Marvel's Power: " . " $team2Score " . " </h3>";

                if ($team1Score > $team2Score) {
                    echo "<h3> DC Wins!!</h3>";
                } else if ($team1Score == $team2Score) {
                    echo "<h3> Tie!! Both Win!!</h3>";
                } else {
                    echo "<h3> Marvel Wins!!</h3>";
                }
            echo "</div>";  
        }
    ?>

	<!-- end main content -->
	<br />
	<br />

    <!-- footer -->
    <footer>
        <p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
    </footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
