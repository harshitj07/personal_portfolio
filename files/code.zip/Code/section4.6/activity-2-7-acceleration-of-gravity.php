<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.7b - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.7b">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.7b - Acceleration of Gravity"; ?>


	<style>
		body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        img {
            height: 70%;
            width: 80%;
            border-radius: 10px;
        }
        
        img.planet {
            height: 100px;
            width: 100px;
            border-radius: 10px;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        iframe {
        	border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;

            margin: 15px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

    <!-- main content -->
    <h2>Introduction</h2>
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h3>Overview</h3>
                <br />
                <p>This is an activity that involves creating two arrays in PHP. One will hold the acceleration of gravity on each planet in the solar system and the other will hold images of the planets. The arrays will be used to display the acceleration and image of each planet through the use of a form. The user will input a range of acceleration values and when submitted, only the planets whose accelerations fall within that range are displayed. This program uses the "foreach" loop to iterate through the arrays and display the planets and their corresponding acceleration and images.</p>
                <p>Read more here: <a class="link" href="http://planetaryfacts.blogspot.com/2012/04/g-planets-of-solar-system.html">planetaryfacts.blogspot.com</a></p>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <h3>Solar System</h3>
                <br />
                <img src="https://www.farmersalmanac.com/wp-content/uploads/2020/11/pluto2.jpg">
            </div>
        </div>
    </div>
    <br />

    <h2>Acceleration of Gravity Program</h2>
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h2>Fill in the Following</h2>
                <form name="functionsUserInput" action="activity-2-7-acceleration-of-gravity.php" method="post"> 
                    <h3>Starting Acceleration (m/s²)</h3>
                    <input type="number" name="start" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <h3>Ending Acceleration (m/s²)</h3>
                    <input type="number" name="end" autocomplete="off" value="" class="frmInput"></input>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <input type="submit" value="Show All" name="allButton" class="submit"></input>
                    <br />
                </form>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <?php

                    // Define Variables
                    $start = $_POST['start'];
                    $end = $_POST['end'];

                    // Define acceleration and image arrays
                    $acceleration = array(
                        'Mercury' => 3.76,
                        'Venus' => 9.04,
                        'Earth' => 9.8,
                        'Mars' => 3.77,
                        'Jupiter' => 23.6,
                        'Saturn' => 10.06,
                        'Uranus' => 8.87,
                        'Neptune' => 11.23,
                        'Pluto' => 0.62
                    );

                    $planet_image = array(
                        'Mercury' => 'https://cdn.britannica.com/05/110305-050-42CA686B/Mercury-Wide-Angle-Messenger-probe-hemisphere-image-Jan-14-2008.jpg',
                        'Venus' => 'https://upload.wikimedia.org/wikipedia/commons/b/b2/Venus_2_Approach_Image.jpg',
                        'Earth' => 'https://upload.wikimedia.org/wikipedia/commons/c/cb/The_Blue_Marble_%28remastered%29.jpg',
                        'Mars' => 'https://upload.wikimedia.org/wikipedia/commons/0/0e/Tharsis_and_Valles_Marineris_-_Mars_Orbiter_Mission_%2830055660701%29.png',
                        'Jupiter' => 'https://upload.wikimedia.org/wikipedia/commons/c/c1/Jupiter_New_Horizons.jpg',
                        'Saturn' => 'https://images.news18.com/ibnlive/uploads/2021/10/saturn.png',
                        'Uranus' => 'https://upload.wikimedia.org/wikipedia/commons/c/c9/Uranus_as_seen_by_NASA%27s_Voyager_2_%28remastered%29_-_JPEG_converted.jpg',
                        'Neptune' => 'https://upload.wikimedia.org/wikipedia/commons/6/63/Neptune_-_Voyager_2_%2829347980845%29_flatten_crop.jpg',
                        'Pluto' => 'https://upload.wikimedia.org/wikipedia/commons/e/ef/Pluto_in_True_Color_-_High-Res.jpg'
                    );

                    // Error Statements
                    $error = "false";

                    // Checks if the inputs are empty
                    if ($start == "" OR $end == "") {
                        $error = "true";
                        $errorMessage = "<h3>Error: You must fill each of the input boxes.</h3>";
                    }

                    // Checks if the starting number is greater than the ending number
                    if ($start > $end) {
                        $error = "true";
                        $errorMessage = "<h3>Error: Your starting number must be smaller than your ending number.</h3>";
                    }

                    // Checks if the start value is greater than 23.6 and the end value is smaller than 0.62
                    if ($start > "23.6" OR $end < "0.62") {
                        $error = "true";
                        $errorMessage = "<h3>Error: You must make sure that your starting value is smaller than 23.6 and your ending value is bigger than 0.62.</h3>";
                    }

                    // Checks if submit button is clicked
                    if ($_POST['subButton']){
                        if ($error == "false") {

                            // Display the planets that have accelerations within the range
                            foreach ($acceleration as $planet => $accel) {
                                if ($accel >= $start AND $accel <= $end) {
                                    echo "<h2>{$planet}</h2>";
                                    echo "<p>Acceleration of gravity: {$accel} m/s<sup>2</sup></p>";
                                    echo "<img class='planet' src='{$planet_image[$planet]}'><br/>";
                                }
                            }
                        } else {
                            echo $errorMessage; 
                        }   
                    }

                    // Checks if show all button is clicked
                    else if ($_POST['allButton']){

                        // Display all the planets with their accelerations and images
                        foreach ($acceleration as $planet => $accel) {
                            echo "<h2>{$planet}</h2>";
                            echo "<p>Acceleration of gravity: {$accel} m/s<sup>2</sup></p>";
                            echo "<img class='planet' src='{$planet_image[$planet]}'><br/>";
                        }
                    }
                ?>
            </div>
        </div>
    </div>

	<!-- end main content -->
	<br />
	<br />

    <!-- footer -->
    <footer>
        <p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
    </footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
