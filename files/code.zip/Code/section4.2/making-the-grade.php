<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "User Input & Conditional Statements Lesson - Harshit Jain") ?></title>	

	<meta name="description" content="Working with user input and conditional statements">
	<meta name="author" content="Harshit Jain">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "User Input & Conditional Statements Lesson"; ?>

	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: #333333;
			text-align: center;
			color: var(--snow);
		}

		h1 {
		font-style: italics;
		}

		.error {
			color: #ff0000;
		}

		#reportContainer {
			position: relative;
			margin-left: auto;
			margin-right: auto;
			width: 80%; 
			padding: 2%; 
			margin-top: 100px;
			background: rgba(0,0,0,0.4);
			border-radius: 0.5em; 
			display: inline-block;
			box-sizing: border-box;
		}

		input {
			font-size: 1.3em; 
			Padding: 10px;
		}

		/* Changes text styling for certain parts of the form*/
		::placeholder {
	        font-family: 'Nunito', sans-serif;
	        text-align: center;
	        font-size: 14px;
		}

		select, input, textarea {
			font-family: 'Nunito', sans-serif;
			text-align: center;
			font-size: 14px;
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.submit {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;
		}

		.submit:hover,
		.submit:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.submit:active {
		    background: var(--color);
		    color: #fff;
		}

		/* Input box styling */
		.input {
			border: 3px solid var(--denim);
			border-radius: 5px;
			margin: 10px;
		}	

		.input:hover,
		.input:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: black;
		}

		.input:active {
		    background: var(--denim);
		    color: black;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
			
	<!-- PHP Code -->
	<?
		// Using if statements to automatically set the grade and comment
		if ($_POST['subBtn']) {
			// Store the posted values from the form in variables
			$stu_name = $_POST['theName'];
			$stu_mark = $_POST['theMark'];
			
			if ($stu_name == "" OR $stu_mark == "") {
				// Show error statement if fields are left empty (simple error checking)
				echo "<p class='error'>You must include a name and mark!</p>";
			} else  {	
				// Conditions for displaying grade and comment
				if ($stu_mark <= 100 AND $stu_mark > 90) {
					$letter_grade = "A+";
					$comment = "Great work, keep it up!";
					$special_comment = "Exceptional Work! Continue to work at this level and you may end the course with 100%!";
				} else if ($stu_mark == 90) {
					$letter_grade = "A";
					$comment = "Good efforts.";
				} else if ($stu_mark <= 90 AND $stu_mark > 80) {
					$letter_grade = "A-";
					$comment = "Good efforts.";
				} else if ($stu_mark <= 80 AND $stu_mark > 75) {
					$letter_grade = "B+";
					$comment = "Good efforts.";
				} else if ($stu_mark == 75) {
					$letter_grade = "B";
					$comment = "Good efforts.";
				} else if ($stu_mark <= 75 AND $stu_mark > 70) {
					$letter_grade = "B-";
					$comment = "Good efforts.";
				} else if ($stu_mark <= 70 AND $stu_mark > 65) {
					$letter_grade = "C+";
					$comment = "Good efforts.";
				} else if ($stu_mark == 65) {
					$letter_grade = "C";
					$comment = "Good efforts.";
				} else if ($stu_mark <= 65 AND $stu_mark > 60) {
					$letter_grade = "C-";
					$comment = "Good efforts.";
				} else if ($stu_mark <= 60 AND $stu_mark > 55) {
					$letter_grade = "D+";
					$comment = "Good efforts.";
				} else if ($stu_mark == 55) {
					$letter_grade = "D";
					$comment = "Good efforts.";
				} else if ($stu_mark <= 55 AND $stu_mark > 50) {
					$letter_grade = "D-";
					$comment = "Good efforts.";
				} else if ($stu_mark <= 50 AND $stu_mark > 0) {
					$letter_grade = "Unsuccessful";
					$comment = "Good efforts.";
				} else {
					$letter_grade = "<p class='error'>Invalid mark entered - must be between 0 and 100.</p>";
				}
			}
		}
	?>

	<!-- User Input Form -->
	<div class="grid">
		<div id="reportContainer" class="col-span-6">
			<h1>"Making the Grade!"</h1>
			<p>This is a mock student report.<br />	
			<form action="making-the-grade.php" method="post">
				Name:<br />
				<input type="" name="theName" value="" class="input"><br /><br />
				Mark (%):<br />
				<input type="" name="theMark" value="" class="input"><br /><br />
				<input name="subBtn" type="submit" value="Show Now!" class="submit"></input><br /><br />
			</form>
		</div>

		<div id="reportContainer" class="col-span-6" style="padding: 120px;">
			Student's Name: </b> <? echo $stu_name; ?><br /><br />
			Student's Mark: </b> <? echo $stu_mark ?><br /><br />
			Letter Grade: </b> <? echo $letter_grade; ?><br /><br />
			Comment: </b> <? echo $comment; ?><br /><br />
			Special Comment: </b> <? echo $special_comment; ?></p>
		</div>
	</div>
	<br />
	<br />
	<br />
	<br />

	<!-- end main content -->

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
