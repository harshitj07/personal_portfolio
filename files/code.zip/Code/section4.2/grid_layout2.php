<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Grid Layout & Responsive Design - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Template Page & Grid Layout & Responsive Design">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Link to Font-Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" />

	<link rel="stylesheet" href="grid_styles2.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Grid Layout & Responsive Design"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: left;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: #333333;
			text-align: left;
			color: var(--denim);
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->

	<!-- main content -->
	<div class="container">

		<!-- 2 columns -->
		<div class="fluid2col clear">
			<h2>1/2 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>
		<div class="fluid2col">
			<h2>1/2 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>

		<!-- 3 columns -->
		<div class="fluid3col clear">
			<h2>1/3 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>
		<div class="fluid3col">
			<h2>1/3 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>
		<div class="fluid3col">
			<h2>1/3 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>

		<!-- 1/3 and 2/3 columns -->
		<div class="fluid3col clear">
			<h2>1/3 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>
		<div class="fluid23col">
			<h2>2/3 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>	

		<!-- 3/4 and 1/4 columns -->
		<div class="fluid34col clear">
			<h2>3/4 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>
		<div class="fluid4col">
			<h2>1/4 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>

		<!-- 1/5 columns -->
		<div class="fluid5col">
			<h2>1/5 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>
		<div class="fluid5col">
			<h2>1/5 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>	
		<div class="fluid5col">
			<h2>1/5 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>
		<div class="fluid5col">
			<h2>1/5 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>
		<div class="fluid5col">
			<h2>1/5 Columns</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras consequat elit at maximus malesuada. Praesent accumsan porta est, et pulvinar dui hendrerit vel.</p>
		</div>							

	</div>

	<!-- end main content -->

	<!-- PHP -->

	<!-- Javascript-->
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
