<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "C.Y.O.A. - Harshit Jain") ?></title>	

	<meta name="description" content="This activity demonstrates the usage of condition statements.">
	<meta name="author" content="Harshit Jain">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Choose Your Own Adventure"; ?>

	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--denim);
			text-align: center;
		}

		img {
			border-radius: 5px;
			width: 400px;
			height: 250px;
		}

		#container {
			position: relative;
			margin-left: auto;
			margin-right: auto;
			width: 750px; 
			height: 520px; 
			padding: 2%; 
			background: rgba(0,0,0,0.4);
			border-radius: 0.5em; 
			display: inline-block;
			box-sizing: border-box;
		}

		/* 
		Button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.button {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;

		    margin: 25px;
		    padding: 20px;

		    width: 125px;
		    height: 55px;

		    text-decoration: none;
		}

		.button:hover,
		.button:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.button:active {
		    background: var(--color);
		    color: black;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<p>Choose Wisely!</p>
	<hr style="color: var(--snow); width: 200px;">
	<br />
	<br />
	
	<div id="container">
		<?
			$option = $_GET['option'];
			
			if ($option == "") {
				echo "
					<img src='https://i.pinimg.com/originals/fe/9d/a5/fe9da5d6ebc8200d2be6fb369b6d2625.jpg'>
					<br />
					<br />
					<br />
					<h3>You find yourself lost in a dense jungle and must find your way back to civilization.
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php?option=ea2b2676c28c0db26d39331a336c6b92' class='button'>Begin</a>
					<br />
					<br />
					</h3>"
				;
			} else if ($option == "ea2b2676c28c0db26d39331a336c6b92") {
				echo "
					<img src='https://image1.masterfile.com/getImage/NjAwLTA4MzUzNTI1ZW4uMDAwMDAwMDA=AMkIJ2/600-08353525en_Masterfile.jpg'>
					<br />
					<br />
					<br />
					<p>You come to a fork in the path. Do you want to:
					<br />
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php?option=c4ca4238a0b923820dcc509a6f75849b' class='button'>Take the Left Path</a>
					<a href='choose-your-adventure.php?option=c81e728d9d4c2f636f067f89cc14862c' class='button'>Take the Right Path</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "c4ca4238a0b923820dcc509a6f75849b") {
				echo "
					<img src='https://cdn.britannica.com/34/146034-050-F9FF07BC/Innoko-River-National-Wildlife-Refuge-Alaska.jpg'>
					<br />
					<br />
					<br />
					<p>You come to a wide river. Do you want to:
					<br />
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php?option=eccbc87e4b5ce2fe28308fd9f2a7baf3' class='button'>Follow the River Downstream</a>
					<a href='choose-your-adventure.php?option=a87ff679a2f3e71d9181a67b7542122c' class='button'>Try to Cross the River</a>
					<br />
					<br />
					<br />
					</p>"
				;
			} else if ($option == "eccbc87e4b5ce2fe28308fd9f2a7baf3") {
				echo "
					<img src='https://cdn.pixabay.com/photo/2020/05/04/16/05/mckenzie-river-5129717__480.jpg'>
					<br />
					<br />
					<br />
					<p>You come to a section of rapids. Do you want to:
					<br />
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php?option=e4da3b7fbbce2345d7772b0674a318d5' class='button'>Brave the Rapids in a Raft</a>
					<a href='choose-your-adventure.php?option=1679091c5a880faf6fb5e6087eb1b2dc' class='button'>Look for a Way Around the Rapids</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "a87ff679a2f3e71d9181a67b7542122c") {
				echo "
					<img src='https://www.gannett-cdn.com/presto/2018/08/22/PIND/bb66f406-4809-4b06-9f51-7ad2239c0b62-GettyImages-474518327.jpg'>
					<br />
					<h3>Try Again...</h3>
					<p>You attempt to cross the river but get swept away by the current and drown.
					<br />
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php' class='button'>Try Again</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "e4da3b7fbbce2345d7772b0674a318d5") {
				echo "
					<img src='https://www.gannett-cdn.com/presto/2018/08/22/PIND/bb66f406-4809-4b06-9f51-7ad2239c0b62-GettyImages-474518327.jpg'>
					<br />
					<h3>Try Again...</h3>
					<p>Your raft gets caught in the rapids and you are thrown overboard. You try to swim to safety, but you get caught in a strong current and drown.
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php' class='button'>Try Again</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "1679091c5a880faf6fb5e6087eb1b2dc") {
				echo "
					<img src='https://i.pinimg.com/originals/04/71/8e/04718e45294613953e09ade5d1e815cd.jpg'>
					<br />
					<br />
					<p>You eventually find a shallow spot where you can safely cross the river. After crossing the river, you hear rustling in the bushes. Do you want to:
					<br />
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php?option=8f14e45fceea167a5a36dedd4bea2543' class='button'>Hide and Wait for the Predator to Pass</a>
					<a href='choose-your-adventure.php?option=c9f0f895fb98ab9159f51fd0297e236d' class='button'>Try to Fight the Predator</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "8f14e45fceea167a5a36dedd4bea2543") {
				echo "
					<img src='https://static.outsider.com/uploads/2022/07/hiker-stumbles-upon-strange-abandoned-campsite-looks-like-start-horror-movie.png'>
					<br />
					<br />
					<br />
					<p>After waiting for what seems like an eternity, you realize that the predator is no longer in the area. You continue through the jungle and come across an abandoned campsite. Do you want to:
					<br />
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php?option=45c48cce2e2d7fbdea1afc51c7c6ad26' class='button'>Search the Campsite for Supplies</a>
					<a href='choose-your-adventure.php?option=d3d9446802a44259755d38e6d163e820' class='button'>Keep Moving</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "c9f0f895fb98ab9159f51fd0297e236d") {
				echo "
					<img src='https://wwwimage-us.pplusstatic.com/base/files/zoo_eye_0.jpg'>
					<br />
					<h3>Try Again...</h3>
					<p>The predator is too powerful and you are no match for it. You are killed and never make it out of the jungle.
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php' class='button'>Try Again</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "45c48cce2e2d7fbdea1afc51c7c6ad26") {
				echo "
					<img src='https://mediaassets.airbus.com/permalinks/533356/wvs/ascent-helicopters-has-a-growing-fleet-of-h125s.jpg'>
					<br />
					<h3>Congratulations!</h3>
					<p>You find a flare gun and some signal flares. You fire a flare into the sky and shortly after, a rescue team arrives to take you back to civilization.
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php' class='button'>Try Again</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "d3d9446802a44259755d38e6d163e820") {
				echo "
					<img src='https://www.oshonews.com/wp-content/uploads/2022/09/jungle.jpg'>
					<br />
					<h3>Try Again...</h3>
					<p>You continue through the jungle and eventually come across a river that you cannot cross. You are forced to turn back and try to find another route. Unfortunately, you get even more lost and never make it out of the jungle.
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php' class='button'>Try Again</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "c81e728d9d4c2f636f067f89cc14862c") {
				echo "
					<img src='https://images.fineartamerica.com/images-medium-large-5/trees-on-steep-hill-salvatore-pappalardo.jpg'>
					<br />
					<br />
					<br />
					<p>You come to a steep hill. Do you want to:
					<br />
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php?option=6512bd43d9caa6e02c990b0a82652dca' class='button'>Climb the Hill</a>
					<a href='choose-your-adventure.php?option=c20ad4d76fe97759aa27a0c99bff6710' class='button'>Try Going Around the Hill</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "6512bd43d9caa6e02c990b0a82652dca") {
				echo "
					<img src='https://www.oshonews.com/wp-content/uploads/2022/09/jungle.jpg'>
					<br />
					<p style='color: var(--denim); font-size: 17px;'>Try Again...</p>
					<p>You successfully climb to the top of the hill but find that the path on the other side is too steep and dangerous to descend. You are forced to turn back and try to find another route. Unfortunately, you get even more lost and never make it out of the jungle.
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php' class='button'>Try Again</a>
					<br />
					<br />
					</p>"
				;
			} else if ($option == "c20ad4d76fe97759aa27a0c99bff6710") {
				echo "
					<img src='https://www.oshonews.com/wp-content/uploads/2022/09/jungle.jpg'>
					<br />
					<h3>Try Again...</h3>
					<p>You walk for miles but can't find a way around the hill. Eventually, you get even more lost and never make it out of the jungle.
					<br />
					<br />
					<br />
					<a href='choose-your-adventure.php' class='button'>Try Again</a>
					<br />
					<br />
					</p>"
				;
			} else {
				echo "<p>You have made an invalid selection!</p>";                
			}
		?>
	</div>

	<!-- end main content -->
	<br />
	<br />
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
