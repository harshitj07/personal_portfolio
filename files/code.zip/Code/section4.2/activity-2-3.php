<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.3 - Harshit Jain") ?></title>	

	<meta name="description" content="This activity shows the usuage of conditional statements. ">
	<meta name="author" content="Harshit Jain">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.3"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: #333333;
			text-align: center;
			color: var(--snow);
		}

		.error {
			color: #ff0000;
		}

		#container {
			position: relative;
			margin-left: auto;
			margin-right: auto;
			width: 450px; 
			height: 300px; 
			padding: 2%; 
			margin-top: 100px;
			background: rgba(0,0,0,0.4);
			border-radius: 0.5em; 
			display: inline-block;
			box-sizing: border-box;
		}

		/* Image styling */
		img {
			border-radius: 5px;
			width: 400px;
			height: 210px;
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.submit {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;

		    width: 125px;
		    height: 55px;
		}

		.submit:hover,
		.submit:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.submit:active {
		    background: var(--color);
		    color: #fff;
		}

		/* Input box styling */
		select.frmInput {
			border: 3px solid var(--denim);
			border-radius: 5px;
			margin: 10px;
			height: 50px;
			width: 150px;
			text-align: center;
		}	

		select.frmInput:hover,
		select.frmInput:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: black;
		}

		select.frmInput:active {
		    background: var(--denim);
		    color: black;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />

	<!-- main content -->

	<?php
		// only show the information if the button named "subButton" has been pressed
		if ($_POST['subButton']) {
			// set the variable with the submitted value
			$day = $_POST['day'];
			$img = $_POST['img'];
			$message = $_POST['message'];

			if ($day == "") {
				// Show error statement if fields are left empty (simple error checking)
				echo "<p class='error'>You must select a day!</p>";
			} else {
					if ($day == 1) {
						$message = "<p>Happy Sunday!</p>";
						$img = "<img src='../images/01.png'>";
					}
					
					if ($day == 2) {
						$message = "<p>Happy Monday!</p>";
						$img = "<img src='../images/02.png'>";
					}
					
					if ($day == 3) {
						$message = "<p>Happy Tuesday!</p>";
						$img = "<img src='../images/03.png'>";
					}
					
					if ($day == 4) {
						$message = "<p>Happy Wednesday!</p>";
						$img = "<img src='../images/04.png'>";
					}
					
					if ($day == 5) {
						$message = "<p>Happy Thursday!</p>";
						$img = "<img src='../images/05.png'>";
					}
					
					if ($day == 6) {
						$message = "<p>Happy Friday!</p>";
						$img = "<img src='../images/06.png'>";
					}
					
					if ($day == 7) {
						$message = "<p>Happy Saturday!</p>";
						$img = "<img src='../images/07.png'>";
					}
			}
		}
	?>

	<!-- there are two form methods: "get" and "post" ; "get" shows the values for the type variables and values, "post" hides the type variables and values /-->

	<div class="grid">
		<div id="container" class="col-span-6">
			<h2>What Day Is It?</h2><br />

			<form name="form1" action="activity-2-3.php" method="post">
		
				<!-- simple drop-down list -->
				<select name="day" class="frmInput">
					<option value="">Choose the Day</option>
					<option value="1" name="day" class="option">Sunday</option>
					<option value="2" name="day" class="option">Monday</option>
					<option value="3" name="day" class="option">Tuesday</option>
					<option value="4" name="day" class="option">Wednesday</option>
					<option value="5" name="day" class="option">Thursday</option>
					<option value="6" name="day" class="option">Friday</option>
					<option value="7" name="day" class="option">Saturday</option>
				</select>
				<br />
				<br />
			
				<!-- submit button //-->
				<input type="submit" name="subButton" value="Submit" class="submit"></input>
				<br />
			</form>
		</div>
		<div id="container" class="col-span-6">
			<? echo $message?>
			<? echo $img?>
		</div>
	</div>

	<!-- end main content -->
	<br />
	<br />
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
