<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	
	<title>Text-based Adventure Game</title>	
	
	<meta name="description" content="Text-based Adventure Game using PHP">
	<meta name="author" content="teacher">	
	
	<!-- styles - internal (not linked) -->
	<style>
		body {
			padding: 0;
			margin: 0;
			background: url("https://wallpaperaccess.com/full/1371521.jpg"); 
			background-repeat: no-repeat;
			background-size: cover;
			background-attachment: fixed;
			color: #333333;
			font-family: 'MedievalSharp', cursive;
		}
		h1 { 
			font-family: 'MedievalSharp', cursive; 
		}
		a.button:link, a.button:visited, a.button:active {
			position: relative;
			display: inline-block;
			padding: 10px 20px;
			text-align: center;
			background: #FF8C00;
			color: #333;
			transition: all 0.5s ease;
			text-decoration: none;
		}	
		a.button:hover {
			background: #333;
			color: #fff;
		}
		#container {
			position: relative;
			display: inline-block;
			margin-top: 50px;
			margin-left: 50%;
			transform: translateX(-50%);
			padding: 50px;
			text-align: center;
			box-sizing: border-box;
			width: 70%;
			font-size: 1.2em;
			background: rgba(255,255,255,0.8);
		}
	</style>

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=MedievalSharp&display=swap" rel="stylesheet">

</head>
<body>
	<div id="container">
		<h1>CYOA Text-based Game: Simple</h1>
		<p>Choose wisely!</p>
		
		<?
			$option = $_GET['option'];
			
			if ($option == "") {
				echo "<p>You are standing in a dark room with 2 doors.  One to the left and one to the right.<br />You must make a choice.
				<br /><a href='text-based-cyoa-example.php?option=1' class='button'>LEFT DOOR</a> | <a href='text-based-cyoa-example.php?option=2' class='button'>RIGHT DOOR</a>
				</p>";
			} else if ($option == "1") {
				echo "<p>You chose the left door.  Very wise.  The door shuts behind you and locks.  You are standing in another room.  There are two tunnels leading out of the room.<br />
				<a href='text-based-cyoa-example.php?option=3' class='button'>LEFT TUNNEL</a> | <a href='text-based-cyoa-example.php?option=4' class='button'>RIGHT TUNNEL</a>
				</p>";
			} else if ($option == "2") {
				echo "<p>You have parished. Sorry.<br /><a href='text-based-cyoa-example.php' class='button'>START AGAIN</a></p>";
			} else if ($option == "3") {
				echo "<p>You have parished. Sorry.<br /><a href='text-based-cyoa-example.php' class='button'>START AGAIN</a></p>";
			} else if ($option == "4") {
				echo "<p>You have parished. Sorry.<br /><a href='text-based-cyoa-example.php' class='button'>START AGAIN</a></p>";
			} else {
				echo "<p>You have made an invalid selection!</p>";                
			}
		?>
	</div>
</body>
</html>
