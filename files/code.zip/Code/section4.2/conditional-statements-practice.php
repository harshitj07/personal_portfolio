<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Extension Activity - Harshit Jain") ?></title>	

	<meta name="description" content="PUT YOUR PAGE DESCRIPTION HERE">
	<meta name="author" content="PUT YOUR NAME HERE">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Extension Activity"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--snow);
			text-align: center;
			color: var(--snow);
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->

	<?php
		// conditional statements (IF Statements)
		$num = $_GET['num1'];
		$num2 = $_GET['num2'];

		if ($num == "5") {
			echo "num1 (" . $num  . ") is equal to 5.";
		}

		// conditional statements (IF not equal to)
		if ($num != "5") {
			echo "num1 (" . $num  . ") is not equal to 5.";
		}
		echo "<hr size=\"1\">";

		// conditional statements (IF, ELSE IF, and ELSE)
		if ($num < "5") {
			echo "num1 (" . $num  . ") is less than 5.";
		}
		else if ($num > "5") {
			echo "num1 (" . $num  . ") is greater than 5.";
		}
		else {
			echo "num1 (" . $num  . ") is equal to 5.";
		}
		echo "<hr size=\"1\">";

		// conditional statements (comparing two variables)
		if ($num > $num2) {
			echo $num . " is greater than " . $num2;
		}
		else if ($num < $num2) {
			echo $num . " is less than " . $num2;
		}
		else {
			echo $num . " is equal to " . $num2;
		}
		echo "<hr size=\"1\">";

		// conditional statements (comparing two variables - OR and AND)
		if ($num == "5" OR $num2 == "20") {
			echo "num1 is FIVE <b>or</b> num 2 is TWENTY.";
		} else {
		            echo "num1 is not FIVE <b>or</b> num 2 is not TWENTY.";
		}

		echo "<hr size=\"1\">";
		if ($num == "5" AND ($num2 == "20" OR $num2 == "15") ) {
			echo "num1 is FIVE and num2 is TWENTY or FIFTEEN.";
		} else {
		            echo "num1 is not FIVE <b>and</b> num 2 is not TWENTY or FIFTEEN.";
		}
	?>

	<!-- end main content -->
	<br />
	<br />

	<!-- footer
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>
	 -->

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
