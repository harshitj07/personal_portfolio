<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.3b - Harshit Jain") ?></title>	

	<meta name="description" content="This activity shows the usuage of conditional statements. ">
	<meta name="author" content="Harshit Jain">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.3b"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: #333333;
			text-align: center;
			color: var(--snow);
		}

		.error {
			color: #ff0000;
		}

		#container {
			position: relative;
			margin-left: auto;
			margin-right: auto;
			width: 380px; 
			height: 380px; 
			padding: 2%; 
			background: rgba(0,0,0,0.4);
			border-radius: 0.5em; 
			display: inline-block;
			box-sizing: border-box;
		}

		table {
			height: 360px;
			width: 360px;
		}

		table, th, td {
			border: 2px solid var(--midnight);
			border-collapse: collapse;
			border-radius: 5px;
		}

		/* Image styling */
		img {
			border-radius: 5px;
			width: 400px;
			height: 210px;
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.submit {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;

		    width: 125px;
		    height: 55px;
		}

		.submit:hover,
		.submit:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.submit:active {
		    background: var(--color);
		    color: #fff;
		}

		/* Input box styling */
		select.frmInput {
			border: 3px solid var(--denim);
			border-radius: 5px;
			margin: 10px;
			height: 50px;
			width: 150px;
			text-align: center;
		}	

		select.frmInput:hover,
		select.frmInput:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: black;
		}

		select.frmInput:active {
		    background: var(--denim);
		    color: black;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />
	<br />
	<br />

	<!-- main content -->

	<?php
		// only show the information if the button named "subButton" has been pressed
		if ($_POST['subButton']) {
			// set the variable with the submitted value
			$number = $_POST['number'];
			$colour = $_POST['colour'];
			$message;

			if ($number == "" OR $colour == "") {
				// Show error statement if fields are left empty (simple error checking)
				echo "<p class='error'>Please select both options!</p><br />";
			} else {
					if ($number <= "5" AND $colour == "red") {
						$message = "<br /><p style='color: var(--denim);'>Lizard</p>";
					}
					else if ($number > "5" && ($colour == "red" OR $colour == "blue")) {
						$message = "<br /><p style='color: var(--denim);'>Spock</p>";
					}
					else if ($number >= "3" AND $number < "7" AND $colour == "green") {
						$message = "<br /><p style='color: var(--denim);'>Rock</p>";
					}
					else if ($number >= "9" AND $colour == "green") {
						$message = "<br /><p style='color: var(--denim);'>Paper</p>";
					}
					else if ($number == "1" AND $colour == "blue") {
						$message = "<br /><p style='color: var(--denim);'>Scissors</p>";
					}
					else {
						$message = "<p style='color: var(--denim);'>No conditions match!</p>";
					}
			}
		}
	?>

	<!-- there are two form methods: "get" and "post" ; "get" shows the values for the type variables and values, "post" hides the type variables and values /-->

	<div class="grid">
		<div id="container" class="col-span-4" style="padding: 10px; font-size: 13px;">
			<table>
				<tr>
					<td style="color: var(--denim);">Condition</td>
					<td style="color: var(--denim);">Output</td>
				</tr>
				<tr>
					<td>Number is less than or equal to 5 and colour is red</td>
					<td>Lizard</td>
				</tr>
				<tr>
					<td>Number is greater than 5 and colour is red or blue 
						Hint: notice use of brackets - read it like a sentence $var >= 5 AND ($var2 == "red" OR $var2 == "blue")</td>
					<td>Spock</td>
				</tr>
				<tr>
					<td>Number is greater than or equal to 3 and less than 7 and colour is green</td>
					<td>Rock</td>
				</tr>
				<tr>
					<td>Number is greater than or equal to 9 and colour is green</td>
					<td>Paper</td>
				</tr>
				<tr>
					<td>Number is equal to 1  and colour is blue</td>
					<td>Scissors</td>
				</tr>
				<tr>
					<td>Any other (default else statement) input combination...</td>
					<td>No conditions match!</td>
				</tr>
			</table>
		</div>
		<div id="container" class="col-span-4">
			<h2>Choose!</h2><br />

			<form name="form1" action="activity-2-3b.php" method="post">
		
				<!-- drop-down list -->
				<select name="number" class="frmInput">
					<option value="">Choose a Number</option>
					<option value="1" name="number" class="option">1</option>
					<option value="2" name="number" class="option">2</option>
					<option value="3" name="number" class="option">3</option>
					<option value="4" name="number" class="option">4</option>
					<option value="5" name="number" class="option">5</option>
					<option value="6" name="number" class="option">6</option>
					<option value="7" name="number" class="option">7</option>
					<option value="8" name="number" class="option">8</option>
					<option value="9" name="number" class="option">9</option>
					<option value="10" name="number" class="option">10</option>
				</select>
				<br />
				<br />

				<!-- drop-down list -->
				<select name="colour" class="frmInput">
					<option value="">Choose a Colour</option>
					<option value="red" name="colour" class="option">Red</option>
					<option value="blue" name="colour" class="option">Blue</option>
					<option value="green" name="colour" class="option">Green</option>
				</select>
				<br />
				<br />
			
				<!-- submit button //-->
				<input type="submit" name="subButton" value="Submit" class="submit"></input>
				<br />
			</form>
		</div>
		<div id="container" class="col-span-4" style="padding: 120px; font-size: 20px;">
			<?  if ($_POST['subButton']) {
					echo "You selected $number and $colour";
				}
			?>
			<br />
			<? echo $message?>
		</div>
	</div>

	<!-- end main content -->
	<br />
	<br />
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
