<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
    <meta charset="utf-8">

    <!-- Title changes depending on the website -->
    <title><?php echo($siteName . "Activity 2.5e - Harshit Jain") ?></title>    

    <!-- Description -->
    <meta name="description" content="Activity 2.5e">
    <meta name="author" content="Harshit Jain">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

    <!-- link to animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <!-- Grid Styles -->
    <link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

    <!-- Navbar title changes depending on the website -->
    <?php $siteName = "Activity 2.5e"; ?>


    <style>
        body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        img {
            height: 60%;
            width: 85%;
            border-radius: 10px;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 175px;
            height: 65px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

         /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
    </style>
</head>
<body>
    <!-- Navbar Element -->
    <?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
    <br />
    <br />

    <h2>Useful Information</h2>
    <div class="grid">
        <div class="col-span-3">
            <div class="card">
                <h3>How does it Work?</h3>
                <p>Through the use of loops, this calculator can provide you the projected population of a year, given the growth rate (%) and existing population. Try it out!</p>
                <p>Here is a link to <a class="link" href="http://www.coolmath.com/algebra/17-exponentials-logarithms/06-population-exponential-growth-01">CoolMath.com</a> which can help you learn more about this!</p>
            </div>
        </div>
        <div class="col-span-4">
            <div class="card">
                <h3>Equation</h3>
                <br />
                <img src="../images/popgrowth.png">
            </div>
        </div>
        <div class="col-span-5">
            <div class="card">
                <h3>Background Information</h3>
                <p>Exponential population growth refers to a rapid increase in the number of individuals in a population over time. This phenomenon can be observed in bacteria, which can double their numbers every 20 minutes through binary fission. Human populations have also experienced exponential growth in history due to factors such as improved healthcare and agriculture. Of course, growth can have both positive and negative impacts, such as strain on resources and environmental degradation. It is important to implement sustainable population management strategies to ensure a balanced and healthy future for our planet.</p>
            </div>
        </div>
    </div>
    <br />

    <!-- main content -->
    <h2>Population Growth Calculator</h2>
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h2>Fill in the Following</h2>
                <form name="loopsUserInput" action="activity-2-5e.php" method="post">
                    <h3>Initial Population</h3>
                    <input type="number" name="population" autocomplete="off" placeholder="7000000000" value="" class="frmInput"></input>
                    <br />
                    <h3>Start Year</h3>
                    <input type="number" name="start" autocomplete="off" placeholder="2000" value="" class="frmInput"></input>
                    <br />
                    <h3>End Year</h3>
                    <input type="number" name="end" autocomplete="off" placeholder="2005" value="" class="frmInput"></input>
                    <br />
                    <h3>Growth Rate (%)</h3>
                    <input type="float" name="rate" autocomplete="off" placeholder="2.5" value="" class="frmInput"></input>
                    <br />
                    <br />
                    <input type="submit" value="Show the Growth" name="subButton" class="submit"></input>
                    <br />
                </form>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <?php
                    if ($_POST['subButton'] == 'Show the Growth') {
                        
                        // Define Variables
                        $ipopulation = $_POST['population'];
                        $start = $_POST['start'];
                        $end = $_POST['end'];
                        $rate = $_POST['rate'];

                        // Makes sure the rate is used as a decimal
                        $rate = $rate / 100;

                        // Error Statements
                        $error = "false";

                        // Checks if any of the boxes are left empty
                        if ($ipopulation == "" OR $start == "" OR $end == "" OR $rate == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must fill out each of the boxes.</h3>";
                        }

                        // Checks if start number is bigger than end number. 
                        if ($start > $end) {
                            $error = "true";
                            $errorMessage = "<h3>Error: Your start year must be smaller than your end year</h3>";
                        }

                        // Output Message
                        if ($error == "false") {
                            // Displays in a table
                            echo "<h2>Growth over Time</h2><br/>";
                            echo "<table>";
                            echo "<tr><th>Year</th><th>Population</th></tr>";

                            // For Loop
                            for ($year = $start; $year <= $end; $year++) {
                                // Ensures that proper values will be used
                                $t = $year - $start;

                                // Main calculations
                                $p = round($ipopulation * exp($rate * $t));

                                // Output
                                echo "<tr><td>". $year ."</td><td>". $p ."</td></tr>";

                                // Data for the graph
                                $plotPoint .= "[" . $year . " , " . $p . "],";
                            }
                            echo "</table>";
                        } else {
                            echo $errorMessage;
                        }
                    }
                ?>
                <br />

                <!-- Javascript Code for Graph -->
                <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                <script type="text/javascript">
                    google.charts.load('current', {'packages':['corechart']});
                    google.charts.setOnLoadCallback(drawChart);

                    function drawChart() {
                        var data = new google.visualization.DataTable();
                        data.addColumn('number', 'x');
                        data.addColumn('number', 'Population');

                        data.addRows([
                            <?php
                                echo $plotPoint;
                            ?>
                        ]);

                        var options = {
                            hAxis: {
                                title: 'Year'
                            },
                            vAxis: {
                                title: 'Population'
                            },
                            colors: ['#2e3c73']
                        };

                        var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
                        chart.draw(data, options);
                    }
                </script>               
                <div id="chart_div" style="width: 400px; height: 250px;"></div>
            </div>
        </div>
    </div>

    <!-- end main content -->
    <br />
    <br />

    <!-- footer -->
    <footer>
        <p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
    </footer>

    <!-- turn work in widget -->
    <?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
