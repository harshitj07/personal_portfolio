<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.5a - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.5a">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.5a"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--denim);
			text-align: center;
		}

		img {
			height: 125px;
			width: 125px;
		}

		.card {
			position: relative;
			width: 100%;
			height: 100%; 
			padding: 5%; 
			background: rgba(0,0,0,0.4);
			border-radius: 0.5em; 
			display: inline-flex;
			box-sizing: border-box;
			align-items: center; 
			justify-content: center; 	
			align-content: center;
			justify-items: center;
			flex-direction: column;
		}

		.php {
			font-size: 20px; 
			align-items: center; 
			justify-content: center; 
			display: flex; 
			padding: 50px
		}

		.grid {
			padding: 0 5vw 0 5vw;
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.submit {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;

		    width: 120px;
		    height: 65px;
		}

		.submit:hover,
		.submit:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.submit:active {
		    background: var(--color);
		    color: #333;
		}

		/* Input box styling */
		.frmInput {
			border: 3px solid var(--denim);
			border-radius: 5px;
			margin: 10px;
			height: 40px;
			width: 150px;
			text-align: center;
			transition-duration: 1.5s;
		}	

		.frmInput:hover,
		.frmInput:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: black;
		  	height: 45px;
		  	width: 250px;
		  	transition-duration: 1.5s;
		}

		.frmInput:active {
		    background: #e6f1fc;
		    color: black;
		}

		::placeholder, option, textarea, input, select {
			font-family: 'Nunito', sans-serif;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<div class="grid">
		<div class="col-span-6">
			<div class="card">
				<form name="loopsUserInput" action="activity-2-5a.php" method="post">
					<h3>Starting Number</h3>
					<input type="number" name="startNum" autocomplete="off" placeholder="Starting #" value="" class="frmInput"></input>
					<br />
					<h3>Ending Number</h3>
					<input type="number" name="endNum" autocomplete="off" placeholder="Ending #" value="" class="frmInput"></input>
					<br />
					<br />
					<input type="submit" value="Run Code" name="subButton" class="submit"></input>
					<br />
				</form>
			</div>
		</div>
		<div class="col-span-6">
			<div class="card">
				<?php
					if ($_POST['subButton'] == 'Run Code') {
						
						// Define Variables
						$startNum = $_POST['startNum'];
						$endNum = $_POST['endNum'];

						// Error Statements
						$error = "false";

						if ($startNum == "" OR $endNum == "") {
							$error = "true";
							$errorMessage = "<h3>Error: You must have a starting and ending number.</h3>";
						}

						if ($startNum > "3") {
							$error = "true";
							$errorMessage = "<h3>Error: Minimum value must be less than or equal to 3.</h3>";
						}

						if ($endNum < "7") {
							$error = "true";
							$errorMessage = "<h3>Error: Maximum value must be more than or equal to 7.</h3>";
						}

						if ($endNum < $startNum) {
							$error = "true";
							$errorMessage = "<h3>Error: Your starting number must be lower than your ending number.</h3>";
						}

						// Output message
						if ($error == "false") {
							while ($startNum <= $endNum) {
								echo $startNum;
								echo "<br />";
								$startNum++;

								if ($startNum == "3") {
									echo "3 - yay, this is number three!";
									echo "<br />";
									$startNum++;
								}

								if ($startNum == "7") {
									echo "7 - lucky number seven!";
									echo "<br />";
									$startNum++;
								}
							}
						} else {
							echo $errorMessage;
						}
					}
				?>
			</div>
		</div>
	</div>

	<!-- end main content -->
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
