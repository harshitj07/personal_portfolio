<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 2.5b - Harshit Jain") ?></title>	

	<!-- Description -->
	<meta name="description" content="Activity 2.5b">
	<meta name="author" content="Harshit Jain">

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

	<!-- Grid Styles -->
	<link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 2.5b"; ?>


	<style>
		body, html {
		    margin: 0;
		    padding: 0;
		}

		body {
			background: var(--midnight); /* background colour */
			color: var(--snow);  /* font colour */
			font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
			text-align: center;
		}

		h1 {
			font-family: 'Nunito', sans-serif;
			color: #fffefa;
			text-align: center;
			font-size: 35px;
			color: var(--snow);
		}

		h2, h3 {
			font-family: 'Nunito', sans-serif;
			color: var(--denim);
			text-align: center;
		}

		img {
			height: 25px;
			width: 25px;
		}

		.card {
			position: relative;
			width: 100%;
			height: 100%; 
			padding: 5%; 
			background: rgba(0,0,0,0.4);
			border-radius: 0.5em; 
			display: inline-flex;
			box-sizing: border-box;
			align-items: center; 
			justify-content: center; 	
			align-content: center;
			justify-items: center;
			flex-direction: column;
		}

		.php {
			font-size: 20px; 
			align-items: center; 
			justify-content: center; 
			display: flex; 
			padding: 50px
		}

		.grid {
			padding: 0 5vw 0 5vw;
		}

		/* 
		Submit button styling 
		Source: https://getcssscan.com/css-buttons-examples
		*/
		.submit {
		    --b: 3px;   /* border thickness */
		    --s: .45em; /* size of the corner */
		    --color: var(--snow);
		  
		    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
		    color: var(--color);
		    --_p: var(--s);
		    background:
		        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
		        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
		    transition: .3s linear, color 0s, background-color 0s;
		    outline: var(--b) solid #0000;
		    outline-offset: .6em;
		    font-size: 16px;

		    border: 0;

		    user-select: none;
		    -webkit-user-select: none;
		    touch-action: manipulation;

		    width: 120px;
		    height: 65px;
		}

		.submit:hover,
		.submit:focus-visible {
		    --_p: 0px;
		    outline-color: var(--color);
		    outline-offset: .05em;
		}

		.submit:active {
		    background: var(--color);
		    color: #333;
		}

		/* Input box styling */
		.frmInput {
			border: 3px solid var(--denim);
			border-radius: 5px;
			margin: 10px;
			height: 40px;
			width: 150px;
			text-align: center;
			transition-duration: 1.5s;
		}	

		.frmInput:hover,
		.frmInput:focus-visible {
		    border: 5px solid var(--navy);
		    outline-offset: .1em;
		    background-color: #e6f1fc;
		  	color: black;
		  	height: 45px;
		  	width: 250px;
		  	transition-duration: 1.5s;
		}

		.frmInput:active {
		    background: #e6f1fc;
		    color: black;
		}

		::placeholder, option, textarea, input, select {
			font-family: 'Nunito', sans-serif;
		}

		/* 
		Hover animation on mail link
		Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
		*/

		a.mail {
	  		background-image: linear-gradient(
	    		to right,
	    		#4c79b5,
	    		#4c79b5 50%,
	    		#ffffff 50%
	  		);
	  		background-size: 200% 100%;
	  		background-position: -100%;
	  		-webkit-background-clip: text;
	  		-webkit-text-fill-color: transparent;
	  		transition: all 0.7s ease-in-out;
		}

		a.mail:before {
		  	content: '';
		  	background: #4c79b5;
		  	display: block;
		  	position: absolute;
		  	bottom: -3px;
		  	left: 0;
		  	width: 0;
		  	height: 3px;
		}

		a.mail:hover {
	 		background-position: 0;
		}

		/* Footer */
		footer {
			background-color: var(--navy);
			text-align: center;
			color: var(--snow);
			padding: 50px;
		}

		footer p{
			margin: 0;
		}
	</style>
</head>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
	<br />
	<br />

	<!-- main content -->
	<div class="grid">
		<div class="col-span-6">
			<div class="card">
				<form name="loopsUserInput" action="activity-2-5b.php" method="post">
					<h3>Starting Value</h3>
					<input type="number" name="startNum" autocomplete="off" placeholder="Starting #" value="" class="frmInput"></input>
					<br />
					<h3>Ending Value</h3>
					<input type="number" name="endNum" autocomplete="off" placeholder="Ending #" value="" class="frmInput"></input>
					<br />
					<h3>Increment Value</h3>
					<input type="number" name="incNum" autocomplete="off" placeholder="Increment #" value="" class="frmInput"></input>
					<br />
					<h3>Ghost Placement</h3>
					<input type="number" name="ghostNum" autocomplete="off" placeholder="Ghost #" value="" class="frmInput"></input>
					<br />
					<br />
					<input type="submit" value="Run Code" name="subButton" class="submit"></input>
					<br />
				</form>
			</div>
		</div>
		<div class="col-span-6">
			<div class="card">
				<?php
					if ($_POST['subButton'] == 'Run Code') {
						
						// Define Variables
						$startNum = $_POST['startNum'];
						$endNum = $_POST['endNum'];
						$incNum = $_POST['incNum'];
						$ghostNum = $_POST['ghostNum'];

						// Error Statements
						$error = "false";

						// Checks if any of the boxes are left empty
						if ($startNum == "" OR $endNum == "" OR $incNum == "" OR $ghostNum == "") {
							$error = "true";
							$errorMessage = "<h3>Error: You must fill out each of the boxes.</h3>";
						}


						// Checks if startNum is bigger than endNum
						if ($endNum < $startNum) {
							$error = "true";
							$errorMessage = "<h3>Error: Your starting number must be lower than your ending number.</h3>";
						}

						// Checks if ghostNum is between startNum and endNum
						if ($ghostNum < $startNum OR $ghostNum > $endNum) {
							$error = "true";
							$errorMessage = "<h3>Error: Your Ghost must be between the starting and ending numbers.</h3>";
						}

						// Checks if ghostNum is between startNum and endNum
						if ($incNum > ($endNum - $startNum)) {
							$error = "true";
							$errorMessage = "<h3>Error: Your increment value must be smaller than the difference of your start and end number. </h3>";
						}

						// Output message
						if ($error == "false") {
						    $foundGhost = false; // Variable to track if ghost number is found
						    for ($startNum; $startNum <= $endNum; $startNum = $startNum + $incNum) {
						        if ($startNum != $ghostNum) {
						            echo $startNum;
						            echo "<br />";
						        } else {
						            echo "<br />";
						            echo $ghostNum;
						            echo "<img src=\"../images/ghost.png\" alt=\"Die Image\" class=\"animate__animated animate__rotateIn\">";
						            echo "<br />";

						            // Set the variable to true when ghost number is found
						            $foundGhost = true;
						        }
						    }
						    // If ghost number is not found
						    if (!$foundGhost) {
						    	echo "<br/>";
						        echo "<p style='color: var(--denim);'>The ghost was not found in the set of numbers.</p>";
						    }
						} else {
						    echo $errorMessage;
						}
					} 
				?>
			</div>
		</div>
	</div>

	<!-- end main content -->
	<br />
	<br />

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
