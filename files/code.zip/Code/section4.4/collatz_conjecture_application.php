<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
   
<html lang="en">
<head>
    <meta charset="utf-8">

    <!-- Title changes depending on the website -->
    <title><?php echo($siteName . "Collatz Conjecture - Harshit Jain") ?></title>    

    <!-- Description -->
    <meta name="description" content="Activity 2.5f - Collatz Conjecture">
    <meta name="author" content="Harshit Jain">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

    <!-- link to animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <!-- Grid Styles -->
    <link rel="stylesheet" href="https://icsprogramming.ca/2022-2023/jain330c2/section4.2/grid_styles.css">

    <!-- Navbar title changes depending on the website -->
    <?php $siteName = "Activity 2.5f - Collatz Conjecture"; ?>


    <style>
        body, html {
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--midnight); /* background colour */
            color: var(--snow);  /* font colour */
            font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
            text-align: center;
        }

        h1 {
            font-family: 'Nunito', sans-serif;
            color: #fffefa;
            text-align: center;
            font-size: 35px;
            color: var(--snow);
        }

        h2, h3 {
            font-family: 'Nunito', sans-serif;
            color: var(--denim);
            text-align: center;
        }

        img {
            height: 60%;
            width: 85%;
            border-radius: 10px;
        }

        table, th, td {
            border: 2px solid var(--midnight);
            border-collapse: collapse;
            border-radius: 5px;
            padding: 10px;
            width: 400px;
        }

        iframe {
        	border-radius: 10px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%; 
            padding: 5%; 
            background: rgba(0,0,0,0.4);
            border-radius: 0.5em; 
            display: inline-flex;
            box-sizing: border-box;
            align-items: center; 
            justify-content: center;    
            align-content: center;
            justify-items: center;
            flex-direction: column;
        }

        .php {
            font-size: 20px; 
            align-items: center; 
            justify-content: center; 
            display: flex; 
            padding: 50px
        }

        .grid {
            padding: 0 5vw 0 5vw;
        }

        /* 
        Submit button styling 
        Source: https://getcssscan.com/css-buttons-examples
        */
        .submit {
            --b: 3px;   /* border thickness */
            --s: .45em; /* size of the corner */
            --color: var(--snow);
          
            padding: calc(.5em + var(--s)) calc(.9em + var(--s));
            color: var(--color);
            --_p: var(--s);
            background:
                conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
                var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
            transition: .3s linear, color 0s, background-color 0s;
            outline: var(--b) solid #0000;
            outline-offset: .6em;
            font-size: 16px;

            border: 0;

            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;

            width: 125px;
            height: 65px;
        }

        .submit:hover,
        .submit:focus-visible {
            --_p: 0px;
            outline-color: var(--color);
            outline-offset: .05em;
        }

        .submit:active {
            background: var(--color);
            color: #333;
        }

        /* Input box styling */
        .frmInput {
            border: 3px solid var(--denim);
            border-radius: 5px;
            margin: 10px;
            height: 40px;
            width: 150px;
            text-align: center;
            transition-duration: 1.5s;
        }   

        .frmInput:hover,
        .frmInput:focus-visible {
            border: 5px solid var(--navy);
            outline-offset: .1em;
            background-color: #e6f1fc;
            color: black;
            height: 45px;
            width: 250px;
            transition-duration: 1.5s;
        }

        .frmInput:active {
            background: #e6f1fc;
            color: black;
        }

        ::placeholder, option, textarea, input, select {
            font-family: 'Nunito', sans-serif;
        }

        /* 
        Hover animation on mail link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.mail {
            background-image: linear-gradient(
                to right,
                #4c79b5,
                #4c79b5 50%,
                #ffffff 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.mail:before {
            content: '';
            background: #4c79b5;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.mail:hover {
            background-position: 0;
        }

        /* 
        Hover animation on regular link
        Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
        */

        a.link {
            background-image: linear-gradient(
                to right,
                #ffffff,
                #ffffff 50%,
                #4c79b5 50%
            );
            background-size: 200% 100%;
            background-position: -100%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.7s ease-in-out;
        }

        a.link:before {
            content: '';
            background: #ffffff;
            display: block;
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 0;
            height: 3px;
        }

        a.link:hover {
            background-position: 0;
        }

        /* Footer */
        footer {
            background-color: var(--navy);
            text-align: center;
            color: var(--snow);
            padding: 50px;
        }

        footer p{
            margin: 0;
        }
    </style>
</head>
<body>
    <!-- Navbar Element -->
    <?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>
    <br />
    <br />

    <h2>Useful Information</h2>
    <div class="grid">
        <div class="col-span-4">
            <div class="card">
                <h3>Introduction</h3>
                <p>The Collatz Conjecture, also known as the 3n + 1 problem, is an unsolved mathematical problem. The conjecture proposes the idea that if you take any positive integer and if it is even, divide it by 2, if it is odd, multiply it by 3 and add 1, and repeat this process, eventually, you will always end up at the number 1. Although there is extensive computational evidence, no one has been able to prove or disprove this conjecture, making it one of the most famous unsolved problems in mathematics. The Collatz Conjecture has applications in a wide variety of fields such as computer science, cryptography, and number theory.</p>
                <p>To use my form, you simply need to enter in a singular value which outputs the number sequence for the Collatz Conjecture.</p>
                <p>Here is a link to <a class="link" href="https://en.wikipedia.org/wiki/Collatz_conjecture">Wikipedia.com</a> which can help you learn more about this!</p>
            </div>
        </div>
        <div class="col-span-4">
            <div class="card">
                <h3>Equation</h3>
                <br />
                <img src="../images/ccformula.png">
            </div>
        </div>
        <div class="col-span-4">
            <div class="card">
                <h3>Videos</h3>
                <iframe width="350" height="200" src="https://www.youtube.com/embed/5mFpVDpKX70" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <br />
                <iframe width="350" height="200" src="https://www.youtube.com/embed/094y1Z2wpJg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
        </div>
    </div>
    <br />

    <!-- main content -->
    <h2>Collatz Conjecture Calculator</h2>
    <div class="grid">
        <div class="col-span-6">
            <div class="card">
                <h2>Fill in the Following</h2>
                <form name="loopsUserInput" action="collatz_conjecture_application.php" method="post">
                    <h3>Pick a Number</h3>
                    <input type="number" name="number" autocomplete="off" placeholder="7" value="" class="frmInput"></input>
                    <br />
                    <br />
                    <input type="submit" value="Submit" name="subButton" class="submit"></input>
                    <br />
                </form>
            </div>
        </div>
        <div class="col-span-6">
            <div class="card">
                <?php
                    if ($_POST['subButton'] == 'Submit') {
                        
                        // Define Variable
                        $number = $_POST['number'];

                        // Error Statements
                        $error = "false";

                        // Checks if any of the boxes are left empty
                        if ($number == "") {
                            $error = "true";
                            $errorMessage = "<h3>Error: You must fill out the required components.</h3>";
                        }

                        // Checks if the number is greater than or equal to 0
                        if ($number <= "0") {
                            $error = "true";
                            $errorMessage = "<h3>Error: Your number must be greater than 0.</h3>";
                        }

                        // Output Message
                        if ($error == "false") {
                            echo "<h2>Output</h2>";
					        
					        // While Loop
					        while ($number > 1) {
					        	
					        	// Run this conditional statement if the number is even
					            if ($number % 2 == 0) {
					            	echo "<p style='color: var(--denim); background: white; padding: 5px;'>$number</p>";
					            	$number /= 2;
					            
					            // Run this conditional statement if the number is odd
					            } else {
					                echo "<p style='color: var(--snow); background: var(--denim); padding: 5px;'>$number</p>";
					                $number = $number * 3 + 1;
					            }
					        }

					        // Output the number 1 separately once the while loop is broken. 
    						echo "<p style='color: #f7d734;'>$number</p>";
					    } else {
		                    echo $errorMessage;
	                    }
                    }
                ?>
            </div>
        </div>
    </div>

    <!-- end main content -->
    <br />
    <br />

    <!-- footer -->
    <footer>
        <p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
    </footer>

    <!-- turn work in widget -->
    <?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
