<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Activity 1-2 - Harshit Jain</title>	
	
	<meta name="description" content="Activity 1-2 - Computer Programming">
	<meta name="author" content="Harshit Jain">	
	
	<!-- styles - internal (not linked) -->
	<style>
		body {
			padding: 20px 20px 20px 20px;
			color: #333333;  /* font color */
			font-family: "Century Gothic", CenturyGothic, AppleGothic, sans-serif;
		}
		
		h1 {
			color: #440088;
		}

		table {
			width: calc(98vw - 20px);
			align-items: center;
			align-content: center;
			text-align: center;
			vertical-align: middle;
		}
	</style>
</head>
<body>
	<!-- main content -->

	<h1>Manipulating Images</h1>
	<h2>Creating Algorithms: Flowcharts</h2>
	<p>A flowchart is a diagram that represents a set of instructions. Flowcharts use symbols to represent different types of instructions. These symbols are used to then show a step-by-step solution to the problem.</p>
	<img src="https://icsprogramming.ca/test/images/flowchart_symbols.jpg" alt="flowchart-symbols" title="Flowchart Symbols" style="width: 400px;" />

	<!-- your table and images go below this comment line -->
	
	<table cellpadding= '0' cellspacing='0' border='1'>
		<tbody>
			<tr>
				<th><img alt=”flowchart-example” title="Flowchart Example" src="https://icsprogramming.ca/images/flowchart_example.png" /><h3><b>This is the original image.</b></h3></th>
				<th><img alt=”flowchart-example” title="Flowchart Example" src="https://icsprogramming.ca/images/flowchart_example.png" style="width:100px; height: 100px;" /><h3><b>This image is 100px by 100px.</b></h3></th>
			</tr>
			<tr>
				<td><img alt=”flowchart-example” title="Flowchart Example" src="https://icsprogramming.ca/images/flowchart_example.png" style="width: 100px;" /><h3><b>This image is scaled to have a fixed width of 100px.</b></h3></td>
				<td><img alt=”flowchart-example” title="Flowchart Example" src="https://icsprogramming.ca/images/flowchart_example.png" style="height: 100px;" /><h3><b>This image is scaled to have a fixed height of 100px.</b></h3></td> 
			</tr>
			<tr>
				<td><img alt="london-bridge" title="London Bridge" src="images/tower_bridge.jpeg" style="height: 270px; width: 480px;" /><h3><b>This photo has a width of 480px and a height of 270px.</b></h3></td>
				<td><img alt="sunflower" title="Sunflower" src="images/sunflower.png" style="height: 270px; width: 480px;" /><h3><b><a src="http://www.google.com/">This photo has a width of 480px and a height of 270px.</a></b></h3></td>
			</tr>
		</tbody>
	</table>
	<!-- end main content -->

	<!-- turn work in widget -->

	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
