<!DOCTYPE html>
<html lang="en">
<head>
	<title>Lesson - HTML Forms</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />

	<!-- styles can go below -->
	<style type="text/css">
	body {
		padding: 0;
		margin: 30px;
		font-family: Arial, Verdana;
		font-size: 1.0em;
		width: 100%;
		background: url("https://icsprogramming.ca/test/ferrari.jpg");
		background-size: cover;
		background-attachment: fixed;
		text-align: center;
	}

	form {
		position: relative;
		padding: 20px;
		margin: 30px;
		margin-left: auto;
		margin-right: auto;
		width: 50%;
		background: rgba(255,255,255,0.9);
		text-align: left;
		border-radius: 10px;
		border: 2px solid black;
	}

	.frmInput {
		font-size: 1.4em;
		border: 1px solid #999999;
		padding: 5px;
		border-radius: 0.2em;
		outline: none;
		margin: 5px;
		width: 90%;
		box-sizing: border-box;
	}

	.output {
		position: relative;
		padding: 20px;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 20px;
		width: 50%;
		background: rgba(255,255,255,0.9);
		text-align: left;
		border: 2px solid #000;
		border-radius: 0.5em;
	}

	.normSubBtn {
		position: relative;
		display: inline-block;
		background: #ff00ff;
		border-radius: 0.4em;
		color: #fff;
		outline: none;
		padding: 10px 30px;
		font-size: 1.1em;
		transition: all 0.5s ease;
	}
	
	.normSubBtn:hover {
		background: #ccc;
		color: #333;
		cursor: pointer;
	}
</style>

</head>
<body>
<!-- PHP extension code goes below this -->

<?php
	// only show the information if the button named "subButton" has been pressed
	if ($_POST['subButton']) {
		// set the variable with the submitted value
		$firstName = $_POST['fname'];
		$password = $_POST['pwd'];
		$sex = $_POST['sex'];
		$fruit1 = $_POST['fruit1'];
		$fruit2 = $_POST['fruit2'];
		$car = $_POST['car'];
		$info = $_POST['info'];
		$hideme = $_POST['hideme'];

		// display the user inputs to the screen
		echo "<div class='output'>";
		echo "<p>Your first name is <b>" . $firstName . "</b>.</p>";
		echo "<p>Your password is <b>"  . $password . "</b>.</p>";
		echo "<p>Your sex is <b>"  . $sex . "</b>.</p>";
		if (isset($fruit1)) {
			echo "<p>You have a <b>"  . $fruit1 . "</b>.</p>";
		}
		if (isset($fruit2)) {
			echo "<p>You have a <b>"  . $fruit2 . "</b>.</p>";
		}
		echo "<p>Your car is <b>"  . $car . "</b>.</p>";
		echo "<p>Additional Information: <b>"  . $info . "</b>.</p>";
		echo "<p>The answer to the universe is (hidden variable): <b>" . $hideme . "</b>.</p>";
		echo "</div>";
	}
?>


<!-- there are two form methods: "get" and "post" ; "get" shows the values for the type variables and values, "post" hides the type variables and values /-->

<form name="form1" action="activity-1-9.php" method="post">
	<h2>Test Form</h2>
	<!-- text input //-->
	First Name<br  /><input type="text" name="fname" value="" placeholder="FIRST NAME" class="frmInput"></input>
	<hr size="1" />
	
	<!-- password input //-->
	Password<br  /><input type="password" name="pwd" value="" class="frmInput"></input>
	<hr size="1" />
	
	<!-- radio input //-->
	<input type="radio" name="sex" value="male" checked> Male</input><br />
	<input type="radio" name="sex" value="female"> Female</input>
	<hr size="1" />
	
	<!-- checkbox input //-->
	<input type="checkbox" name="fruit1" value="Pear"> I have a pear</input><br />
	<input type="checkbox" name="fruit2" value="Apple"> I have an apple</input>
	<hr size="1" />
	
	<!-- simple drop-down list //-->
	<select name="car" class="frmInput">
		<option value="">- Choose a Car -</option>
		<option value="Volvo">Volvo</option>
		<option value="Echo">Echo</option>
		<option value="Ferrari">Ferrari</option>
		<option value="Audi">Audi R8</option>
		<option value="Ford">Ford Truck</option>
	</select>
	<hr size="1" />
	
	<!-- textarea input //-->
	<textarea name="info" rows="5" cols="50" class="frmInput"></textarea>
	<hr size="1" />
	
	<!-- hidden input -->
	<input type="hidden" name="hideme" value="42"></input>
	
	<!-- submit button //-->
	<input type="submit" name="subButton" value="SUBMIT" class=”normSubBtn”></input>
</form>
</body>
</html>
