<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">	
	<title>Activity 1-3 - Harshit Jain</title>	
	
	<meta name="description" content="Activity 1-3 - Computer Programming">
	<meta name="author" content="Harshit Jain">	
	
	<link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body style="background-color: #34495e; color: #ffffff; padding: 30px; font-family: 'Calibri', sans-serif;">
	<!-- main content -->
	<h1>Activity 1.3 - HTML Fonts & Styling</h1>
	<hr>
	</hr>

	<!-- Box - White and Purple -->
	<p style="background: #ffffff; font-family: 'Avant Garde', sans-serif; padding: 10px; color: #8e44ad;">In this paragraph the font has been set to <i>Avant Garde, sans-serif</i>; and has a padding of 10px and the font color is #8e44ad and the background color is #ffffff.</p>

	<!-- Box - Blue and Orange -->
	<h2 style="background: #2980b9; padding: 30px; color: #f39c12;">This is a size 2 heading with a <i>#2980b9</i> color background and padding of 30px and a font color of #f39c12</h2>

	<!-- Box - Grey and White -->
	<h3 style="background: #888888; font-family: 'Comic Sans MS', 'Comic Sans', cursive; color: #ffffff; padding: 5px; width: 700px;">This is a size 3 heading (not a paragraph) with #888888 background color and comic sans ms font that is white (#ffffff) and a padding of 5px and the width is only 700px.</h3>

	<!-- Box - White and Red -->
	<p style="font-size: 2em; color: #d35400; background: #ffffff; font-family: 'Courier'">In this paragraph the font has been set to a size of <i>2.0em</i>, color of <i>#d35400</i> and <i>courier</i> font style.</p>
	
	<!-- Box - Green and White -->
	<p style="background: #1abc9c; color: #ffffff; padding: 5px;">This paragraph has a background color of <i>#1abc9c</i> and font color <i>#ffffff</i> and the paragraph is padded by 5px. Let's step this up a notch and look at styling tables. Below we are going to create a <i>3 column, 1 row table</i> with a border size of <i>2</i>, cellpadding of <i>30</i> and cellspacing of <i>0</i></p>

	<!-- Columns - White, Black and Orange -->
	<table cellpadding= '30' cellspacing='0' border='2'>
		<td style="background: #ffffff; color: #000000">#ffffff background and #000000 font color</td>
		<td style="background: #000000; color: #ffffff">#000000 background and #ffffff font color</td>
		<td style="background: #f39c12; color: #333333">#f39c12 background and #333333 font color</td>
	</table>

	<!-- end main content -->

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
