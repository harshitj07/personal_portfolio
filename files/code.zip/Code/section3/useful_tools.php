<!DOCTYPE html>
<html>
<head>
	<title>Useful Tools: Font-Awesome & Google Fonts</title>
	<meta name="description" content="How to itegrate font-awesome and google-fonts into your applications">
	<meta name="author" content="Harshit Jain">

	<style>
		body {
			padding: 0;
			margin: 0;
			width: 100%;
			height: 100%;
			font-family: 'Quicksand', sans-serif;
		}
		#container {
			position: relative;
			display: inline-block;
			left: 50%;
			transform: translateX(-50%);
			margin-top: 20px;
			width: 70%;
			background: #ccdfff;
			border: 3px solid #04214f;
			border-radius: 25px;
			padding: 20px;
			box-sizing: border-box;
		}
		h1 {
			color: #ff0099;
			font-family: 'Permanent Marker', cursive;
			font-weight: 300;
		}
		.blue {
			color: blue;
		}
		.font1 {
			font-family: 'Permanent Marker', cursive;
			color: #fff;
		}
	</style>

	<!-- Link to Font-Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed:wght@300;400;500;900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;1,100;1,300;1,400&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">

</head>
<body>
	<div id="container">	
		<h1><i class="fa-solid fa-city blue"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h1>
		<h2><i class="fa-solid fa-mug-saucer blue"></i> Lorem ipsum dolor sit amet</h2>
		<p class="font1">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque id lectus tortor. Duis sed eleifend dui, nec egestas tortor. Nam vitae ex sit amet orci ornare vulputate a sed nibh. Morbi fermentum lectus et nunc euismod condimentum. Duis egestas risus in hendrerit imperdiet.
		</p>
		<p class="font2">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque id lectus tortor. Duis sed eleifend dui, nec egestas tortor. Nam vitae ex sit amet orci ornare vulputate a sed nibh. Morbi fermentum lectus et nunc euismod condimentum. Duis egestas risus in hendrerit imperdiet.
		</p>
	</div>
</body>
</html>
