<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
<html>
<html lang="en">
	<meta charset="utf-8">
	
	<title>Activity 1-4 - Harshit Jain</title>	
	
	<meta name="description" content="Big Mac Attack! Table Formatting">
	<meta name="author" content="Harshit Jain">	
	
	<link rel="shortcut icon" href="http://bit.ly/14jpviZ" />
	
	<!-- styles - internal (not linked) -->
	<style>
		body {
			padding: 20px 20px 20px 20px;
			Background: url("https://apiwp.thelocal.com/cdn-cgi/image/format=webp,width=855,quality=75/https://apiwp.thelocal.com/wp-content/uploads/2019/12/e0aad1500b6ddb1a862af1ee1954721f4815728d35cc9510fa5e2fc4f16203d0.jpg");
			background-size: cover;
			background-attachment: fixed;			
			color: #ffffff;  /* font color */
			font-family: "Century Gothic", CenturyGothic, AppleGothic, sans-serif; /* font family */
		}		
		#wrapper {
			position: relative;
			margin-left: auto;
			margin-right: auto;
			width: 700px;
			padding: 20px;
			background: rgba(0,0,0,0.4);
			text-align: center; /* options are: left, center, right, justify */
		}
	</style>

</head>
<body>
	<!-- main content -->
	<div id="wrapper">
		<h1>Big Mac Attack!</h1>
		<h2>Table Formatting Activity</h2>
		<table border="1" cellspacing="0" cellpadding="0" width="600" height="500" align="center">

			<!-- rows and columns -->
			<tr>
				<td align="left" valign="center" bgcolor="#3498db">
					<img src="https://icsprogramming.ca/test/images/big-mac.png" />
				</td>
				<td align="right" valign="top" bgcolor="#c0392b" width = "150">
					<img src="https://icsprogramming.ca/test/images/big-mac.png" />
				</td>
				<td align="center" valign="bottom" bgcolor = "#f1c40f">
					<img src="https://icsprogramming.ca/test/images/big-mac.png" />
				</td>
			</tr>
			<tr>
				<td align="center" valign="center" colspan="3" bgcolor="#95a5a6">
					<img src="https://icsprogramming.ca/test/images/big-mac.png" />
				</td>
			</tr>
			<tr>
				<td align="left" valign="bottom" bgcolor="#f39c12">
					<img src="https://icsprogramming.ca/test/images/big-mac.png" />
				</td>
				<td align="right" valign="top" bgcolor="#2c3e50" colspan="2">
					<img src="https://icsprogramming.ca/test/images/big-mac.png" />
				</td>
			</tr>
		</table>
	</div>
	<!-- end of main content -->

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
	
</body>
</html>
