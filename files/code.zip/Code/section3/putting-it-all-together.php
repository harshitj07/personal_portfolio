<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">

	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "P.I.A.T. - Harshit Jain") ?></title>	
	
	<meta name="description" content="This page covers all of our activities">
	<meta name="author" content="Harshit Jain">	
	
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@100&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=GFS+Didot&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Putting It All Together"; ?>

	<!-- link to animate.css -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
</head>
<style>
	body, html {
	    margin: 0;
	    padding: 0;
	}

	body {
		background-image: url("https://www.wallpaperflare.com/static/747/304/34/space-dark-matter-blue-black-wallpaper.jpg");
		background-size: cover;
		background-attachment: fixed;	
		color: #333333;  /* font colour */
		font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
	}

	h1 {
		font-family: 'Nunito', sans-serif;
		color: #fffefa;
		text-align: center;
		font-size: 35px;
	}

	h2, h3 {
		font-family: 'Nunito', sans-serif;
		color: #fffefa;
		text-align: center;
	}

	p {
		padding: 10px;
	}

	/* The Course Section */
	p.fancy1 {
		margin: 10px;
		position: relative;
		display: inline-block;
		width: 50%;
		box-sizing: border-box;
		background: var(--snow); 
		padding: 20px;
		font-size: 1.05em;  /* 105% of default font size */
		font-family: 'Nunito', sans-serif;
		border-radius: 10px 10px 10px 10px;
		text-align: center;
	}

	/* Default link styles */
	a:link, a:visited, a:active {
		position: relative;
		display: inline-block;
		color: #333333;
		padding: 5px;
		text-decoration: none;
		transition: all 0.5s ease; /* ease the hover transition */
		font-family: 'Nunito', sans-serif;
		font-size: 20px;
	}

	a.back:link, a.back:visited, a.back:active {
		position: relative;
		display: inline-block;
		color: var(--snow);
		padding: 5px;
		text-decoration: none;
		transition: all 0.5s ease; /* ease the hover transition */
		font-family: 'Nunito', sans-serif;
		margin: 30px;
		font-size: 20px;
	}

	/* Link on hover */
	a:hover {
		color: var(--denim);
		text-decoration: none;
		font-family: 'Nunito', sans-serif;
	}

	/* 
	Hover animation on back link
	Source: https://www.sliderrevolution.com/resources/css-button-hover-effects/ -> Nav Hovers
	*/

	.back {
		position: relative;	
	}

	.back:after {
		position: absolute;
		bottom: 0;
		left: 0;
		right: 0;
		margin: auto;
		width: 0%;
		content: '.';
		color: transparent;
		background: var(--denim);
		height: 1px;
	}

	.back {
		transition: all 2s;
	}

	.back:after {
		text-align: left;
		content: '.';
		margin: 0;
		opacity: 0;
	}

	.back:hover {
		color: var(--snow);
		z-index: 1;
	}

	.back:hover:after {
		z-index: -10;
		animation: fill 1s forwards;
		-webkit-animation: fill 1s forwards;
		-moz-animation: fill 1s forwards;
		opacity: 1;
	}

	/* Keyframes for hover animation */
	@-webkit-keyframes fill {
		0% {
			width: 0%;
			height: 1px;
		}

		50% {
			width: 100%;
			height: 1px;
		}

		100% {
			width: 100%;
			height: 100%;
			background: #4c79b5;
			border-radius: 5px;
		}
	}

	/* 
	Hover animation on links and mail link
	Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
	*/

	a.link {
  		background-image: linear-gradient(
    		to right,
    		#4c79b5,
    		#4c79b5 50%,
    		#000 50%
  		);
  		background-size: 200% 100%;
  		background-position: -100%;
  		-webkit-background-clip: text;
  		-webkit-text-fill-color: transparent;
  		transition: all 0.7s ease-in-out;
	}

	a.mail {
		font-size: 16.5px;
  		background-image: linear-gradient(
    		to right,
    		#4c79b5,
    		#4c79b5 50%,
    		#ffffff 50%
  		);
  		background-size: 200% 100%;
  		background-position: -100%;
  		-webkit-background-clip: text;
  		-webkit-text-fill-color: transparent;
  		transition: all 0.7s ease-in-out;
	}

	a.link:before, a.mail:before {
	  	content: '';
	  	background: #4c79b5;
	  	display: block;
	  	position: absolute;
	  	bottom: -3px;
	  	left: 0;
	  	width: 0;
	  	height: 3px;
	}

	a.link:hover, a.mail:hover {
 		background-position: 0;
	}

	a.link:hover::before, a.mail:hover::before {
  		width: 100%;
	}

	/* Table Styling */
	.table {
		display: flex;
		justify-content: center;
		text-align: center;
	}

	/* Styling on the table */
	table, th, td {
		border: 2px solid var(--midnight);
		border-collapse: collapse;
		width: 900px;
		border-radius: 5px;
	}

	/* Embedding Things */
	iframe {
		margin: 10px;
		border-radius: 15px;
	}

	iframe.border {
		margin: 10px;
		border-radius: 15px;
		border: 3px solid black;
	}

	/* Footer */
	footer {
		background-color: var(--navy);
		text-align: center;
		color: var(--snow);
		padding: 50px;
	}

	footer p{
		margin: 0;
	}
</style>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>

	<!-- main content -->
	<!-- Back Button -->
	<a href="../" class="back">Back</a>

	<!-- Table -->
	<div class="table">
		<table>
			<!-- Title Cell -->
			<tr>
				<td valign="top" colspan = "2" style="background: var(--navy);"><h2 class="animate__animated animate__bounceInLeft" >What We've Learned So Far</h2></td>
			</tr>

			<tr>
				<!-- Assembly, Operating, Language, Application Diagram -->
				<td valign="top" style="background: white;">
					<h3 class="animate__animated animate__flash" style="color: #333333;">Assembly, Operating, Language, Application Diagram</h3>
					<img src="http://icsprogramming.ca/examples/images/assembly-operating-language-application.jpg" alt="Assemble operating language"/>
					<p>The application, programming language, operating system, and assembly code all play a significant role when you use your devices. Applications are known to be written and run through the use of programming languages such as Java, Swift, or Dart. These applications allow a user to interact with the machine through outputs and inputs. The programming language (high-level language) is the way a developer designs an application for their targeted audience. This language directs the use of the application and how it may react or respond to certain instances. The operating system dictates the way a computer or machine processes data from an application. It alters the distinct characteristics of the programming language into assembly code that can be utilized in the future for the computer to process data. Lastly, the assembly code is low-level code that relies on a relationship between instructions using the programming language and how a machine interprets the instructions within the code.  This layer preforms all the heavy translating and processes the data to the hardware. All in all, each of these processes have a very distinct but critical function in every day computer tasks.</p>
				</td>

				<!-- Machine Code & Interpreters vs. Compliers -->
				<td valign="top" style="background: white;">
					<h3 class="animate__animated animate__flash" style="color: #333333;">Machine Code/Interpreters & Compilers</h3>
					<iframe class="border" width="386" height="217.2" src="https://www.youtube.com/embed/1OukpDfsuXE" title="Machine Code and High level Languages Using Interpreters and Compilers" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					<p>Programming languages are split into high and low level languages and are designed to direct the use of the application and how it may react to a certain situation. Assembly level languages let users write various programs by making the use of alphanumeric codes for instructions instead of numeric codes. These languages are intended to communicate directly with a computer’s hardware and are readable by humans unlike the machine language which consists of binary and hexadecimal characters. High level languages are independent and let users write various programs in a fashion that resembles English words and mathematical symbols. This allows the user to effortlessly comprehend the program with minimal difficulty. These languages also come with easy maintenance, simplicity, manageability, and versatility. C, Java, C++, and Python and examples of High Level languages. These languages are known to have low efficiency of memory meaning that it consumes more memory than low-level languages. Finally, Low Level languages are called machine-level languages since they work far closer to the hardware and lots of effort is put into making the machine understand the language. Debugging these languages are very difficult since they aren’t easy to understand. That are also hard to maintain and aren’t portable. All in all, this shows how each of the languages work and the differences that they have between them. </p>
					<p>The majority of programs that we know are generally written in High Level languages such as C, Perl, or Java. Just as a human language makes it simple for people to communicate with each other, computer languages make it easy to tell the computer what it needs to do. However since computers only understand numbers, conversing with one is equivalent to conversing with one whom you do not share a language with. To properly communicate, you need a translator like interpreters and compilers. Compilers translate High Level languages before the process is executed, referred to as the source code. Interpreters on the other hand simulates a computer and processes code line-by-line during the runtime. Both have their advantages, as compiled languages keep the source code hidden, allowing developers to keep their technology to themselves and interpreted languages allow for quick development and iteration. In general, both have their different use-cases which make them both useful tools when deploying software.</p>
				</td>
			</tr>
			
			<tr>
				<!-- Programming Languages -->
				<td valign="top" style="background: white;">
					<h3 class="animate__animated animate__flash" style="color: #333333;">Programming Languages</h3>
					<ul>
						<a class="link" href="https://www.w3schools.com/php/php_intro.asp"><li>PHP</li></a><br />
						<a class="link" href="https://www.w3schools.com/python/python_intro.asp"><li>Python</li></a><br />
						<a class="link" href="https://www.w3schools.com/java/java_intro.asp"><li>Java</li></a><br />
						<a class="link" href="https://www.w3schools.com/cs/cs_intro.php"><li>C#</li></a><br />
						<a class="link" href="https://www.w3schools.com/cpp/cpp_intro.asp"><li>C++</li></a>
					</ul>
					<p>Learn more about these programming languages by using the links above! Each have their varying characteristics and have different purposes.</p>
				</td>

				<!-- My Favourite Place -->
				<td valign="top" style="background: white;">
					<h3 class="animate__animated animate__flash" style="color: #333333;">My Favourite Place</h3>
					<iframe class="border" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d754.6677844657287!2d-123.13285969147609!3d49.28990378954154!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54867187eac006d7%3A0x6d3cb1e116f91298!2sRobson%20Place!5e0!3m2!1sen!2sca!4v1676847164295!5m2!1sen!2sca" width="400" height="250" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
					<p>Although one might put a place that they have never been to as their favourite place on Earth, I find that my favourite place is a place I lived for 2+ years. Robson’s Place is a condominium situated on Robson's Street in Vancouver, British Columbia. This place has a very dear place in my heart since it was the first condo that my family resided within when we moved to Canada from India in the December of 2010. We resided within this condo for a little over 2 years and this time period was a very joyous time for our family. Our family welcomed a new member to our family, a baby sister who was born little over 1 year in. This new addition to our family was very heartwarming and we were also visited by my grandparents around a similar time which was great! During this time, we also had lots of fun living in a new country with different weather, infrastructure, and people. A few distinct memories from my time living in the city is seeing snowfall for the first time in the cold winter months, witnessing the rainy days that Vancouver is well known for, biking on tandem bicycles in Stanley Park with my visiting cousins in 2012, and walking down the busy and lively Robson’s Street which is well known for its commercial buildings.</p>
				</td>
			</tr>

			<!-- Additional Cell - Music -->
			<tr>
				<td valign="top" colspan = "2" style="background: white">
					<h3 class="animate__animated animate__flash" style="color: #333333;">My Favourite Music</h3>
					<p>The following is some of the music I listen to!</p>
					<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/1zi7xx7UVEFkmKfv06H8x0?utm_source=generator&theme=0" width="250" height="200" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
					<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/2LSsSV7V33wM9EKQA2xjGS?utm_source=generator&theme=0" width="250" height="200" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
					<iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/5XJWEh8huqG0l9RgRyArtv?utm_source=generator&theme=0" width="250" height="200" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
				</td>
			</tr>
		</table>
	</div>
	</br>
	</br>
	<!-- end main content -->

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
