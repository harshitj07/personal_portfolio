<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	
	<title>Activity 1-5 - Harshit Jain</title>	
	
	<meta name="description" content="More about CSS">
	<meta name="author" content="Harshit Jain">	

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=GFS+Didot&display=swap" rel="stylesheet">
	
	<!-- styles - internal (not linked) -->
	<style>
		body {
			padding: 20px 20px 20px 20px;
			color: #333333;  /* font color */
			font-family: 'GFS Didot', serif;
			/* css backgrounds...http://lea.verou.me/css3patterns/ */
			background-color: gray;
			background-image: linear-gradient(90deg, transparent 50%, rgba(255,255,255,.5) 50%);
			background-size: 50px 50px;
		}	

		/* Teacher Button */

		a.teacher-button:link, a.teacher-button:visited , a.teacher-button:active {
			position: relative;
			display: inline-block;
			padding: 1%;
			margin: 2%; /* 2px around the outside of the link */
			background-image: linear-gradient(to top right, #f06d06, #ffffff);
			color: #333333;	
			font-size: 2.1em; /* 210% of normal size */
			text-decoration: none;  /* underline or none */
			font-family: 'GFS Didot', serif;
			border-radius: 0 0.2em 0 0.2em; /*Top/Right/Botton/Left */
			-moz-border-radius: 0.3em 0.3em 0.3em 0.3em; 
			-webkit-border-radius: 0.3em 0.3em 0.3em 0.3em; 			
		}

		a.teacher-button:hover {
			background: #ffffff;
			color: #f06d06;
			box-shadow: 5px 5px 5px #222222;
			-webkit-box-shadow: 5px 5px 5px #222222;
			-moz-box-shadow: 5px 5px 5px #222222;
		}
		
		/* style the paragraph */
		p.norm {
			position: relative;
			display: inline-block;
			padding: 5px;
			background: rgba(0,0,0,0.7);
			color: #ffffff;
		}
		
		/* your button styles */

		/* Useful Links:
		       https://www.w3schools.com/howto/howto_css_animate_buttons.asp
		       https://dev.to/webdeasy/top-20-css-buttons-animations-f41
		       https://freefrontend.com/css-buttons/
		       https://webdeasy.de/en/top-css-buttons-en/
		       https://www.cssscript.com/cool-animated-button-templates/
		 */

		/* Button 1 */

		a.my-button1:link, a.my-button1:visited , a.my-button1:active {
			backface-visibility: hidden;
			position: relative;
			cursor: pointer;
			display: inline-block;
			white-space: nowrap;
			background: #fff;
			border-radius: 100px;
			border: 4px solid #154e0a;
			border-width: 4px;
			padding: 30px 15px 30px 15px;
			color: #154e0a;
			font-size: 16px;
			font-family: 'GFS Didot', serif;
			font-weight: 900;
			font-style: normal
		}

		a.my-button1:hover {
			background: #154e0a;
			color: #ffffff;
			box-shadow: 5px 5px 5px #ffffff;
			-webkit-box-shadow: 5px 5px 5px #ffffff;
			-moz-box-shadow: 5px 5px 5px #ffffff;
		}

		/* Button 2 */

		.btn-two {
			color: #FFF;
		    transition: all 0.3s;
		    position: relative;
		    width: 10.5%;
		    text-align: center;
		    padding: 20px;
		    font-size: 18px;
		}

		.btn-two span {
		    transition: all 0.3s;
		}

		.btn-two:before {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 100%;
			z-index: 1;
			opacity: 0;
			transition: all 0.3s;
			border-top-width: 1px;
			border-bottom-width: 1px;
			border-top-style: solid;
			border-bottom-style: solid;
			border-top-color: rgba(255,255,255,0.5);
			border-bottom-color: rgba(255,255,255,0.5);
			transform: scale(0.1, 1);
		}

		.btn-two:hover span {
		    letter-spacing: 2px;
		}

		.btn-two:hover:before {
		    opacity: 1; 
		    transform: scale(1, 1); 
		}

		.btn-two:after {
			content: '';
			position: absolute;
		 	bottom: 0;
			left: 0;
			width: 100%;
			height: 100%;
			z-index: 1;
			transition: all 0.3s;
			background-color: rgba(255,255,255,0.1);
		}

		.btn-two:hover:after {
			opacity: 0; 
			transform: scale(0.1, 1);
		}

		/* Button 3 */

		.glow-on-hover {
		    width: 220px;
		    height: 50px;
		    border: none;
		    outline: none;
		    color: #fff;
		    background: #111;
		    cursor: pointer;
		    position: relative;
		    z-index: 0;
		    border-radius: 10px;
		}

		.glow-on-hover:before {
		    content: '';
		    background: linear-gradient(45deg, #ff0000, #ff7300, #fffb00, #48ff00, #00ffd5, #002bff, #7a00ff, #ff00c8, #ff0000);
		    position: absolute;
		    top: -2px;
		    left:-2px;
		    background-size: 400%;
		    z-index: -1;
		    filter: blur(5px);
		    width: calc(100% + 4px);
		    height: calc(100% + 4px);
		    animation: glowing 20s linear infinite;
		    opacity: 0;
		    transition: opacity .3s ease-in-out;
		    border-radius: 10px;
		}

		.glow-on-hover:active {
  		    color: #000
		}

		.glow-on-hover:active:after {
		    background: transparent;
		}

		.glow-on-hover:hover:before {
		    opacity: 1;
		}

		.glow-on-hover:after {
		    z-index: -1;
		    content: '';
		    position: absolute;
		    width: 100%;
		    height: 100%;
		    background: #111;
		    left: 0;
		    top: 0;
		    border-radius: 10px;
		}

		@keyframes glowing {
		    0% { background-position: 0 0; }
		    50% { background-position: 400% 0; }
		    100% { background-position: 0 0; }
		}

		/* Button 4 */

		.button{
  			position:relative;
  			display:inline-block;
  			margin:20px;
		}

		.button a{
		  	color:white;
		  	font-family:Helvetica, sans-serif;
		  	font-weight:bold;
		  	font-size:36px;
		  	text-align: center;
		  	text-decoration:none;
		  	background-color:#FFA12B;
		  	display:block;
		  	position:relative;
		  	padding:20px 40px;
		  
		  	-webkit-tap-highlight-color: rgba(0, 0, 0, 0);
		  	text-shadow: 0px 1px 0px #000;
		  	filter: dropshadow(color=#000, offx=0px, offy=1px);
		  
		  	-webkit-box-shadow:inset 0 1px 0 #FFE5C4, 0 10px 0 #915100;
		 	-moz-box-shadow:inset 0 1px 0 #FFE5C4, 0 10px 0 #915100;
		 	box-shadow:inset 0 1px 0 #FFE5C4, 0 10px 0 #915100;
		  
		  	-webkit-border-radius: 5px;
		  	-moz-border-radius: 5px;
		  	border-radius: 5px;
		}

		.button a:active{
		  	top:10px;
		  	background-color:#F78900;
		  
		  	-webkit-box-shadow:inset 0 1px 0 #FFE5C4, inset 0 -3px 0 #915100;
		  	-moz-box-shadow:inset 0 1px 0 #FFE5C4, inset 0 -3pxpx 0 #915100;
		  	box-shadow:inset 0 1px 0 #FFE5C4, inset 0 -3px 0 #915100;
		}

		.button:after{
		  	content:"";
		  	height:100%;
		  	width:100%;
		  	padding:4px;
		  	position: absolute;
		  	bottom:-15px;
		  	left:-4px;
		  	z-index:-1;
		  	background-color:#2B1800;
		  	-webkit-border-radius: 5px;
		  	-moz-border-radius: 5px;
		  	border-radius: 5px;
		}
</style>
</head>
<body>
	<!-- main content -->
	<h1>Styling Links &amp; Other Cool Stuff</h1>
	<p class="norm">In this activity you will create at least one other link style with a defined class.  From this point forward all of your links on your activities must be styled.  You may want to research other css properties to further understand the cool styles you can add.</p>
	<h2>Teacher's Link</h2>
	<a href="#" class="teacher-button">TEACHER'S LINK</a><br />
	<h2>My Links</h2>
	<a href="#" class="my-button1">Button Style 1</a> 
	<br />
	<br />
  	<div href="#"class="btn btn-two"><span>Button Style 2</span></div>
	<br />
	<br />
	<button href="#" class="glow-on-hover" type="button">Button Style 3</button>
	<br />
	<br />
  	<div class="button"><a href="#">Button Style 4</a></div>
	<!-- /main content -->
	
	<!-- load jquery -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>