<?php if (!isset($_SESSION)) { session_start(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">	
	
	<!-- Title changes depending on the website -->
	<title><?php echo($siteName . "Activity 1.9b - Harshit Jain") ?></title>	
	
	<meta name="description" content="This page covers making forms">
	<meta name="author" content="Harshit Jain">	
	
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">

	<!-- Navbar title changes depending on the website -->
	<?php $siteName = "Activity 1.9b"; ?>
</head>
<style>
	body, html {
	    margin: 0;
	    padding: 0;
	}

	body {
		background: var(--midnight); /* background colour */
		color: #333333;  /* font colour */
		font-family: 'Nunito', sans-serif; /* https://fonts.google.com/ */
		text-align: center;
	}

	h1 {
		font-family: 'Nunito', sans-serif;
		color: #fffefa;
		text-align: center;
		font-size: 35px;
	}

	h2, h3 {
		font-family: 'Nunito', sans-serif;
		color: #333333;
		text-align: center;
	}

	/* Default link styles */
	a:link, a:visited, a:active {
		position: relative;
		display: inline-block;
		color: #333333;
		padding: 5px;
		text-decoration: none;
		transition: all 0.5s ease; /* ease the hover transition */
		font-family: 'Nunito', sans-serif;
	}

	/* Link on hover */
	a:hover {
		color: var(--denim);
		text-decoration: none;
		font-family: 'Nunito', sans-serif;
	}

	/* 
	Hover animation on mail link
	Source: https://css-tricks.com/css-link-hover-effects/ -> The Right-to-Left Color Swap Link Hover Effect
	*/

	a.mail {
  		background-image: linear-gradient(
    		to right,
    		#4c79b5,
    		#4c79b5 50%,
    		#ffffff 50%
  		);
  		background-size: 200% 100%;
  		background-position: -100%;
  		-webkit-background-clip: text;
  		-webkit-text-fill-color: transparent;
  		transition: all 0.7s ease-in-out;
	}

	a.mail:before {
	  	content: '';
	  	background: #4c79b5;
	  	display: block;
	  	position: absolute;
	  	bottom: -3px;
	  	left: 0;
	  	width: 0;
	  	height: 3px;
	}

	a.mail:hover {
 		background-position: 0;
	}

	a.mail:hover::before {
  		width: 100%;
	}

	/* Form styling */
	form {
		font-family: 'Nunito', sans-serif;
		position: relative;
		padding: 20px;
		margin-left: auto;
		margin-right: auto;
		width: 50%;
		background: rgba(255,255,255);
		text-align: center;
		border-radius: 10px;
		border: 2px solid black;
	}

	.frmInput {
		font-size: 16px;
		border: 1px solid #999999;
		padding: 5px;
		border-radius: 0.2em;
		outline: none;
		margin: 5px;
		width: 99%;
		box-sizing: border-box;
	}

	.output {
		position: relative;
		padding: 20px;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 20px;
		width: 50%;
		background: rgba(255,255,255);
		text-align: left;
		border: 2px solid #000;
		border-radius: 0.5em;
	}

	/* 
	Submit button styling 
	Source: https://getcssscan.com/css-buttons-examples
	*/
	.normSubBtn {
	    --b: 3px;   /* border thickness */
	    --s: .45em; /* size of the corner */
	    --color: #373B44;
	  
	    padding: calc(.5em + var(--s)) calc(.9em + var(--s));
	    color: var(--color);
	    --_p: var(--s);
	    background:
	        conic-gradient(from 90deg at var(--b) var(--b),#0000 90deg,var(--color) 0)
	        var(--_p) var(--_p)/calc(100% - var(--b) - 2*var(--_p)) calc(100% - var(--b) - 2*var(--_p));
	    transition: .3s linear, color 0s, background-color 0s;
	    outline: var(--b) solid #0000;
	    outline-offset: .6em;
	    font-size: 16px;

	    border: 0;

	    user-select: none;
	    -webkit-user-select: none;
	    touch-action: manipulation;
	}

	.normSubBtn:hover,
	.normSubBtn:focus-visible {
	    --_p: 0px;
	    outline-color: var(--color);
	    outline-offset: .05em;
	}

	.normSubBtn:active {
	    background: var(--color);
	    color: #fff;
	}

	/* Changes text styling for certain parts of the form*/
	::placeholder {
        font-family: 'Nunito', sans-serif;
        text-align: center;
        font-size: 14px;
	}

	select, input, textarea {
		font-family: 'Nunito', sans-serif;
		text-align: center;
		font-size: 14px;
	}

	/* Footer */
	footer {
		background-color: var(--navy);
		text-align: center;
		color: var(--snow);
		padding: 50px;
	}

	footer p{
		margin: 0;
	}
</style>
<body>
	<!-- Navbar Element -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/2022-2023/jain330c2/nav.php";?>

	<!-- main content -->
	</br>
	</br>

	<!-- PHP code-->
	<?php
		// only show the information if the button named "subButton" has been pressed
		if ($_POST['subButton']) {
			// set the variable with the submitted value
			$firstName = $_POST['fname'];
			$lastName = $_POST['lname'];
			$email = $_POST['email'];
			$password = $_POST['pwd'];
			$sex = $_POST['sex'];
			$gr1 = $_POST['gr1'];
			$gr2 = $_POST['gr2'];
			$gr3 = $_POST['gr3'];
			$gr4 = $_POST['gr4'];
			$age = $_POST['age'];
			$location = $_POST['location'];
			$info = $_POST['info'];
			$hideme = $_POST['hideme'];

			// display the user inputs to the screen
			echo "<div class='output'>";
			echo "<p>Your first name is <b>" . $firstName . "</b>.</p>";
			echo "<p>Your last name is <b>" . $lastName . "</b>.</p>";
			echo "<p>Your email is <b>" . $email. "</b>.</p>";
			echo "<p>Your password is <b>"  . $password . "</b>.</p>";
			echo "<p>Your sex is <b>"  . $sex . "</b>.</p>";
			if (isset($gr1)) {
				echo "<p>You are in Gr.<b>"  . $gr1 . "</b>.</p>";
			}
			if (isset($gr2)) {
				echo "<p>You are in Gr.<b>"  . $gr2 . "</b>.</p>";
			}
			if (isset($gr3)) {
				echo "<p>You are in Gr.<b>"  . $gr3 . "</b>.</p>";
			}
			if (isset($gr4)) {
				echo "<p>You are in Gr.<b>"  . $gr4 . "</b>.</p>";
			}
			echo "<p>Your age is <b>"  . $age . "</b>.</p>";
			echo "<p>Your location is <b>"  . $location . "</b>.</p>";
			echo "<p>Additional Information: <b>"  . $info . "</b>.</p>";
			echo "<p>The answer to the universe is (hidden variable): <b>" . $hideme . "</b>.</p>";
			echo "</div>";
		}
	?>

	<!-- there are two form methods: "get" and "post" ; "get" shows the values for the type variables and values, "post" hides the type variables and values /-->

	<form name="form1" action="activity-1-9b.php" method="post">
		<h2>General Form</h2>

		<!-- text input //-->
		First Name<br  /><input type="text" name="fname" value="" placeholder="John" class="frmInput"></input>
		<hr size="1" />

		Last Name<br  /><input type="text" name="lname" value="" placeholder="Doe" class="frmInput"></input>
		<hr size="1" />

		Email<br  /><input type="text" name="email" value="" placeholder="example@example.com" class="frmInput"></input>
		<hr size="1" />
		
		<!-- password input //-->
		Password<br  /><input type="password" name="pwd" value="" placeholder="password" class="frmInput"></input>
		<hr size="1" />
		
		<!-- radio input //-->
		<input type="radio" name="sex" value="male" checked> Male</input><br />
		<input type="radio" name="sex" value="female"> Female</input><br />
		<input type="radio" name="sex" value="prefer not to say"> Prefer Not To Say</input>
		<hr size="1" />
		
		<!-- checkbox input //-->
		<input type="checkbox" name="gr1" value="9" checked> I am in Gr. 9</input><br />
		<input type="checkbox" name="gr2" value="10"> I am in Gr. 10</input><br />
		<input type="checkbox" name="gr3" value="11"> I am in Gr. 11</input><br />
		<input type="checkbox" name="gr4" value="12"> I am in Gr. 12</input><br />
		<hr size="1" />
		
		<!-- simple drop-down list //-->
		<select name="age" class="frmInput">
			<option value="">Choose your Age</option>
			<option value="14">14</option>
			<option value="15">15</option>
			<option value="16">16</option>
			<option value="17">17</option>
			<option value="18">18</option>
		</select>
		<hr size="1" />

		<select name="location" class="frmInput">
			<option value="">Choose your Location</option>
			<option value="Burlington">Burlington</option>
			<option value="Oakville">Oakville</option>
			<option value="Milton">Milton</option>
			<option value="Hamilton">Hamilton</option>
		</select>
		<hr size="1" />
		
		<!-- textarea input //-->
		<textarea name="info" rows="5" cols="50" class="frmInput"></textarea>
		<hr size="1" />
		
		<!-- hidden input -->
		<input type="hidden" name="hideme" value="42"></input>
		<br />
		
		<!-- submit button //-->
		<input type="submit" name="subButton" value="Submit" class="normSubBtn"></input>
		<br />
	</form>

	</br>
	</br>
	<!-- end main content -->

	<!-- footer -->
	<footer>
		<p>This site was created for ICS3UO-02. You can contact me at <a class="mail" href="mailto:1jainhar@hdsb.ca">1jainhar@hdsb.ca</a> or 905-802-2902.</p>
	</footer>

	<!-- turn work in widget -->
	<?php include $_SERVER['DOCUMENT_ROOT'] . "/marking-rubric/turn-work-in.inc.php"; ?>
</body>
</html>
